To install and use SFML with your favorite compiler, go to the tutorials web page:

http://www.sfml-dev.org/tutorials/
