/*
	Este ejemplo muestra como controlar el arrastre de un objeto en 2D de forma ABSOLUTA
	A LA POSICION DEL MOUSE. Otra alternativa seria darle la posicion a tener de forma relativa
	al movimiento del mouse.
*/

////////////////////////////////////////////////////////////
// Librer�as
////////////////////////////////////////////////////////////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>

////////////////////////////////////////////////////////////
/// Variables
////////////////////////////////////////////////////////////
sf::Image icircle;
sf::Sprite c1;
sf::Sprite c2;
sf::Sprite c3;
sf::Sprite c4;
//ancho y alto de la imagen cargada
int iancho,ialto;
//ancho y alto de la ventana
int wancho, walto;

//Esta funcion nos dice si el mouse esta dentro de un sprite. Utiliza el rectangulo del
//sprite para hacer la comprobacion.
//
//Par�metros:
//posicionMouse es la posicion del mouse
//sprite        es el sprite que se desea saber si el mouse esta adentro
//
//return Si esta adentro devuelve true, sino false
bool isAdentro(sf::Vector2f posicionMouse, const sf::Sprite& sprite)
{
	float anchoSprite = sprite.GetSize().x;
	float xmaximo = sprite.GetPosition().x+anchoSprite/2.0f;
	float xminimo = sprite.GetPosition().x-anchoSprite/2.0f;

	
	if( posicionMouse.x < xmaximo && posicionMouse.x > xminimo )
	{
		float altoSprite = sprite.GetSize().y;
		float ymaximo = sprite.GetPosition().y+altoSprite/2.0f;
		float yminimo = sprite.GetPosition().y-altoSprite/2.0f;
		if( posicionMouse.y < ymaximo && posicionMouse.y > yminimo )
			return true;
	}
	return false;
}

//Funcion auxiliar que calcula la norma(2 o euclidea) de un vector.
//Esta es una metrica que nos dice que tan largo es el vector.
//Devuelve un valor flotante. Para mas informacion ver: http://es.wikipedia.org/wiki/Norma_vectorial
float norma(sf::Vector2f vec)
{
	return sqrtf(vec.x*vec.x+vec.y*vec.y);
}

////////////////////////////////////////////////////////////
/// Punto de entrada a la aplicaci�n
////////////////////////////////////////////////////////////
int main(){

	//Cargamos la imagen del archivo
	icircle.LoadFromFile("..\\..\\imgs\\rcircle.png");
		

	iancho=icircle.GetWidth();
	ialto=icircle.GetHeight();
	wancho=800;
	walto=600;

	//Seteamos la imagen a usar por los sprites
	c1.SetImage(icircle);
	c2.SetImage(icircle);
	c3.SetImage(icircle);
	c4.SetImage(icircle);


	//Le diremos al sprite que en vez de tenerlo "agarrado" de la esquina superior izquierda
	//como es por defecto, que lo "agarraremos" del centro del circulo(sprite). Es decir que si
	//ahora le seteamos la posicion el punto que estableceremos sera donde esta el centro del circulo.
	c1.SetCenter(c1.GetSize().x/2.0f, c1.GetSize().y/2.0f);
	//seteamos las posiciones de los sprites
	//c1 ira a la esquina superior izquierda. La posicion en x es
	//iancho/2 ya que dijimos que ahora tenemos "agarrado" al sprite del centro del circulo,
	//de dejarle 0 tendriamos la mitad del circulo fuera de la pantalla. Igualmente para la posicion
	//y hacemos lo mismo pero con ialto/2.
	c1.SetPosition(iancho/2.0f,ialto/2.0f);
	
	//esquina superior derecha
	c2.SetPosition(wancho-iancho/2.0f,ialto/2.0f);
	c2.SetCenter(c2.GetSize().x/2.0f, c2.GetSize().y/2.0f);
	//esquina inferior izquierda
	c3.SetPosition(iancho/2.0f,walto-ialto/2.0f);
	c3.SetCenter(c3.GetSize().x/2.0f, c3.GetSize().y/2.0f);
	//esquina inferior derecha
	c4.SetPosition(wancho-iancho/2.0f,walto-ialto/2.0f);
	c4.SetCenter(c4.GetSize().x/2.0f, c4.GetSize().y/2.0f);
 
	//Creamos la ventana de la aplicacion
	sf::RenderWindow App(sf::VideoMode(wancho, walto, 32), "Arrastre absoluto a la posicion del mouse");

	sf::Event Evento;
	int dragging = 0;
	//la variable fromMouseToSprite va a tener la distancia desde la posicion del mouse al sprite
	//el cual se esta arrastrando al momento del empezar a arrastrar, se va a usar para que cuando
	//se mueva el mouse el sprite se desplaze considerando la distancia que separaba el mouse del 
	//centro de los sprites al momento de hacer click.
	sf::Vector2f fromMouseToSprite(0.0f, 0.0f);
	
	//Loop principal
	while (App.IsOpened()){

		while( App.GetEvent(Evento) )//Loop de eventos, si no hay eventos saldra del bucle
		{
			switch(Evento.Type)
			{
			case sf::Event::EventType::Closed://Si se cierra la ventana
				App.Close();
				break;
			case sf::Event::EventType::MouseButtonPressed://Si se presiona le mouse para arrastrar circulos
				{
				
				//Instanciar tantas variables aca no es una buena idea para el performance
				//seria mas convenente instanciarlas afuera del loop principal y usarlas aca
				sf::Vector2f pos((float)App.GetInput().GetMouseX(), (float)App.GetInput().GetMouseY());
				sf::Vector2f diff1 = c1.GetPosition()-pos;
				sf::Vector2f diff2 = c2.GetPosition()-pos;
				sf::Vector2f diff3 = c3.GetPosition()-pos;
				sf::Vector2f diff4 = c4.GetPosition()-pos;
				//Una mejora seria que en vez de elegir el circulo en el orden c1, c2, c3 y c4
				//seria elegir el que esta mas cerca del mouse, entonces cuando hay 2 o mas circulos
				//sobrelapados sera mas facil elegir el circulo que se desea

				//Elegimos algun circulo si es que el mouse esta adentro de este
				if( norma(diff1) < ialto/2.0f)
				{
					dragging = 1;
					fromMouseToSprite = diff1;
				}else if( norma(diff2) < ialto/2.0f)
				{
					dragging = 2;
					fromMouseToSprite = diff2;
				}else if( norma(diff3) < ialto/2.0f)
				{
					dragging = 3;
					fromMouseToSprite = diff3;
				}else if( norma(diff4) < ialto/2.0f)
				{
					dragging = 4;
					fromMouseToSprite = diff4;
				}

				//Por otro lado si usaramos el rectangulo del sprite usariamos la funcion isAdentro
				/*if( isAdentro(pos,c1) )
					dragging = 1;
				else if( isAdentro(pos,c2) )
					dragging = 2;
				else if( isAdentro(pos,c3) )
					dragging = 3;
				else if( isAdentro(pos,c4) )
					dragging = 4;
				}*/

				}
				break;
			case sf::Event::EventType::MouseButtonReleased://Si se suelta el mouse se deja de arrastrar
					dragging = 0;
				break;
			case sf::Event::EventType::LostFocus://Si pierde el foco de la ventana se deja de arrastrar
					dragging = 0;
				break;
			case sf::Event::EventType::MouseLeft://Si el mouse se salio de la ventana se deja de arrastrar
					dragging = 0;
				break;
			case sf::Event::EventType::MouseMoved://Si se mueve el mouse
				{
				//Establecemos la posicion de los sprites de forma absoluta con la posicion del mouse
				if( dragging != 0 )
					{
						switch(dragging)
						{
							case 1:
								c1.SetPosition(Evento.MouseMove.X+fromMouseToSprite.x, Evento.MouseMove.Y+fromMouseToSprite.y);
								break;
							case 2:
								c2.SetPosition(Evento.MouseMove.X+fromMouseToSprite.x, Evento.MouseMove.Y+fromMouseToSprite.y);
								break;
							case 3:
								c3.SetPosition(Evento.MouseMove.X+fromMouseToSprite.x, Evento.MouseMove.Y+fromMouseToSprite.y);
								break;
							case 4:
								c4.SetPosition(Evento.MouseMove.X+fromMouseToSprite.x, Evento.MouseMove.Y+fromMouseToSprite.y);
								break;
						}
					}
				}
				break;
			}
		}

		App.Clear();

	    App.Draw(c1);
		App.Draw(c2);
		App.Draw(c3);
		App.Draw(c4);


		App.Display();
 }
 return EXIT_SUCCESS;
}