#include "AdministradorSecuencia.h"

#include <iostream>

AdministradorSecuencia::AdministradorSecuencia(sf::Key::Code* secuenciaTeclas, int cantTeclas, float deltaTiempoCritico): 
					m_cantTeclas(cantTeclas), m_deltaTiempoCritico(deltaTiempoCritico), m_teclaActual(0), m_deltaActual(0.0f)
{
	//copiamos el arreglo de teclas
	m_secuenciaTeclas = new sf::Key::Code[m_cantTeclas];
	for(int k=0; k < m_cantTeclas ; ++k)
		m_secuenciaTeclas[k] = secuenciaTeclas[k];
}

AdministradorSecuencia::~AdministradorSecuencia()
{
	// liberamos el arreglo de teclas
	delete[] m_secuenciaTeclas;
}

float AdministradorSecuencia::GetTiempoCritico()
{
	return m_deltaTiempoCritico;
}

void AdministradorSecuencia::ProcesarEvento(const sf::Event & Evento)
{
	// si ya termino exitosamente la secuencia no procesamos proximos eventos este frame
	// (esto es mejorable)
	if( m_teclaActual == m_cantTeclas )
		return;

	if( Evento.Type == sf::Event::EventType::KeyReleased )// si el evento es una  presion de tecla
	{
		if( Evento.Key.Code == m_secuenciaTeclas[m_teclaActual] )// si es la tecla correcta
		{
			std::cout<<"BIEN"<<std::endl;
			++m_teclaActual; //avanza la secuencia
			m_deltaActual = 0.0f;
		}else// si es una tecla incorrrecta
		{
			std::cout<<"MAL"<<std::endl;
			m_deltaActual = 0.0f;// re-iniciamos la secuencia
			m_teclaActual = 0;
		}
	}
}

bool AdministradorSecuencia::ActualizarSecuencia(float dt)
{
	// si todavia no presionamos la primer secuencia no tomar el tiempo
	if( m_teclaActual > 0 )
		m_deltaActual += dt;

	// si nos pasamos del tiempo critico re-iniciar la secuencia
	if( m_deltaActual > m_deltaTiempoCritico )
	{
		std::cout<<"LENTO!!!"<<std::endl;
		m_deltaActual = 0.0f;
		m_teclaActual = 0;
	}

	if( m_teclaActual == m_cantTeclas )// si terminamos correctamente la secuencia
	{
		m_deltaActual = 0.0f;
		m_teclaActual = 0;
		return true; // secuencia correctamente ejecutada
	}else
		return false; // no se ejecuto correctamente todavia...
}