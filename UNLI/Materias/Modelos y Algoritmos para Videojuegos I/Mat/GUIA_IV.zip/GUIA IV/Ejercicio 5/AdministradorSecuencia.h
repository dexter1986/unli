#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

// Administra la ejecucion de una secuencia de teclas
// Se le especifica cual es al secuencia y el limite de tiempo para presionar cada proxima tecla
// Cada evento nuevo se le envia
// Informa si ya termino la secuencia
class AdministradorSecuencia
{
private:

	// arreglo de teclas de la secuencia
	sf::Key::Code* m_secuenciaTeclas;

	// cantidad de teclas en el arreglo de la secuencia
	unsigned int m_cantTeclas;

	// lapso de tiempo maximo permitido entre dos teclas de la secuencia en segundos
	float m_deltaTiempoCritico;


	// el tiempo desde la ultima presion exitosa de tecla (si es > a m_deltaTiempoCritico falla)
	float m_deltaActual;
	// la proxima tecla de la secuencia que debe presionar el usuario
	unsigned int m_teclaActual;

public:

	AdministradorSecuencia(sf::Key::Code* secuenciaTeclas, int cantTeclas, float deltaTiempoCritico);

	~AdministradorSecuencia();

	// Podemos obtener cual era el tiempo critico que el dimos a la secuencia
	float GetTiempoCritico();

	// Le pasamos un evento para que procese el avance de la secuencia
	// Debe llamarse una vez por cada evento
	void ProcesarEvento(const sf::Event & Evento);

	// Devuelve true si la secuencia se completo correctamente o false si no fue asi
	// Debe llamarse una vez por frame
	bool ActualizarSecuencia(float dt);

};