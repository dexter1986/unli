/*
	Este ejemplo muestra una posible forma para controlar la ejecucion de una secuencia de teclas.
	Ante un error en la secuencia se vuelve a comenzar. Si se demora mucho en presionar la proxima tecla se vuelve a comenzar.

	Mensajes de consola:
		BIEN = tecla correcta presionada
		MAL = tecla incorrecta presionada
		LENTO = el limite de tiempo paso y se vuelve a comenzar la secuencia
		Secuencia completada!!! = terminaste la secuencia correctamente :D

	La secuancia configurada por defecto es: Derecha(flecha), Izquierda(flecha), A, S
*/

////////////////////////////////////////////////////////////
// Librer�as
////////////////////////////////////////////////////////////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>

// Clase que maneja las secuencias de teclas
#include "AdministradorSecuencia.h"


////////////////////////////////////////////////////////////
/// Punto de entrada a la aplicaci�n
////////////////////////////////////////////////////////////
int main()
{
	int wancho=800;
	int walto=600;
 
	//Creamos la ventana de la aplicacion
	sf::RenderWindow App(sf::VideoMode(wancho, walto, 32), "Arrastre absoluto a la posicion del mouse");

	sf::Event Evento;

	//Configuramos la secuencia que queremos detectar
	sf::Key::Code secuenciaTeclas[] = {sf::Key::Code::Right, sf::Key::Code::Left, sf::Key::Code::A, sf::Key::Code::S}; 

	//Creamos una instancia de la clase que administra una secuencia de teclas
	AdministradorSecuencia secuendia(secuenciaTeclas, 4/*4 teclas en la secuencia*/, 1.0f/*limite de tiempo de 1 seg para presionar la proxima tecla*/);
	
	//Loop principal
	while (App.IsOpened()){

		while( App.GetEvent(Evento) )//Loop de eventos, si no hay eventos saldra del bucle
		{
			//le pasamos el evento nuevo al objeto para que reaccione si es la tecla correcta o incorrecta
			secuendia.ProcesarEvento(Evento);

			switch(Evento.Type)
			{
			case sf::Event::EventType::Closed://Si se cierra la ventana
				App.Close();
				break;
			}
		}

		//termino la secuencia? sino adelantamos el tiempo
		if( secuendia.ActualizarSecuencia( App.GetFrameTime() ) )
			std::cout<<"Secuencia completada!!!"<<std::endl;

		App.Clear();

		// No hay nada que dibujar...

		App.Display();
 }
 return EXIT_SUCCESS;
}