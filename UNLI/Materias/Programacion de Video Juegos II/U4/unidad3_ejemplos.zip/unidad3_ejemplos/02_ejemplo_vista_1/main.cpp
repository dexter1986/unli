#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

int main(int argc, char *argv[]) {
	// creamos un sprite
	sf::Image i;
	i.LoadFromFile("../mario.png");
	sf::Sprite s;
	s.SetImage(i);
	
	// creamos tres ventanas diferentes
	sf::RenderWindow ventana1(sf::VideoMode(300,300),"Vista 1");
	sf::RenderWindow ventana2(sf::VideoMode(300,300),"Vista 2");
	sf::RenderWindow ventana3(sf::VideoMode(300,300),"Vista 3");

	// creamos una vista diferente para cada ventana
	sf::View vista1(sf::FloatRect(0,0,224,224));
	sf::View vista2(sf::Vector2f(128,128), sf::Vector2f(64,64));
	sf::View vista3(sf::FloatRect(0,128,224,224));
	
	// asignamos las vistas a las ventanas
	ventana1.SetView(vista1);
	ventana2.SetView(vista2);
	ventana3.SetView(vista3);
	
	
	sf::Event e;
	bool salir=false;
	while(!salir){
		while(	ventana1.GetEvent(e) ||
			    ventana2.GetEvent(e) ||
				ventana3.GetEvent(e)){
			// si alguna ventana se cerro, salimos
			if(e.Type == e.Closed) salir=true;	
		}
		
		// limpiamos las 3 ventanas
		ventana1.Clear(sf::Color(0,0,0));
		ventana2.Clear(sf::Color(0,0,0));
		ventana3.Clear(sf::Color(0,0,0));
		
		// dibujamos en las 3 ventanas
		ventana1.Draw(s);
		ventana2.Draw(s);
		ventana3.Draw(s);
		
		// acualizamos las 3 ventanas
		ventana1.Display();
		ventana2.Display();
		ventana3.Display();
	}
	return 0;
}

