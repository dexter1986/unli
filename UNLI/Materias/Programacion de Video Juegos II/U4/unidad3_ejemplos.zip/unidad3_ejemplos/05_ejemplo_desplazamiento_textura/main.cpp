#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

int main(int argc, char *argv[]) {
	// cargamos la imagen desde disco
	sf::Image i;
	i.LoadFromFile("../sfml.png");
	
	// creamos el sprite
	sf::Sprite s;
	s.SetImage(i);
	
	// creamos la ventana y le asignamos una vista
	sf::RenderWindow w(sf::VideoMode(i.GetWidth()*2,i.GetHeight()*2),"Desplazamiento textura");
	sf::View v(sf::FloatRect(0,0,i.GetWidth(), i.GetHeight()));
	w.SetView(v); 
	
	// variables con la velocidad del desplazamiento
	// y el desplazamiento de la capa
	float const velx=0.2;
	float desplx=0;
	
	// PASO IMPORTANTE 1: habilitamos la repeticion de textura
	// o textura ciclica en la coordenada s para la imagen
	// del sprite
	s.GetImage()->Bind();
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	
	sf::Event e;
	unsigned anchoImagen=s.GetImage()->GetWidth();
	while(w.IsOpened()) {
		// manejamos los eventos
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();	
		}
		// aumentamos la posicion de la capa, y la
		// mantenemos dentro de un rango para evitar
		// desbordes de la variable
		desplx+=velx*w.GetFrameTime();
		if(desplx>anchoImagen) desplx-=anchoImagen;
		
		w.Clear(sf::Color(0,0,0));
		
		// PASO IMPORTANTE 2: antes de dibujar, aplicamos
		// el desplazamiento a la matriz de textura de la
		// imagen del sprite, luego debemos restaurar el
		// estado anterior de la matriz
		glMatrixMode(GL_TEXTURE);
		glPushMatrix();
		
		glLoadIdentity();
		glTranslatef(desplx, 0, 0);
		w.Draw(s);
		
		glMatrixMode(GL_TEXTURE);
		glPopMatrix();
		w.Display();
	}
	return 0;
}

