#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

int main(int argc, char *argv[]) {	
	// creamos la ventana
	sf::RenderWindow w(sf::VideoMode(600,600),"Ejemplo Vista 2");
	
	// definimos la velocidad del scrolling
	float viewVelx=15, viewVely=12;
	
	// creamos un sprite con una imagen
	sf::Image i;
	i.LoadFromFile("../level1.png");
	sf::Sprite s;
	s.SetImage(i);
	
	// definimos el tamano de la vista y su ubicacion
	unsigned const tamanioVista=128;
	sf::View v;
	v.SetHalfSize(tamanioVista, tamanioVista);
	v.SetCenter(tamanioVista, tamanioVista);
	w.SetView(v);
	
	// algunas variables que vamos a utilizar
	float elapsedTime;
	sf::Vector2f viewCenter;
	
	while(w.IsOpened()) {
		sf::Event e;
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();	
		}
		
		// calculamos el tiempo que paso desde el ultimo frame
		elapsedTime=w.GetFrameTime();
		
		// movemos la vista por la imagen
		v.Move(viewVelx*elapsedTime, viewVely*elapsedTime);
		
		// si la vista se sale de la imagen, hacemos que "rebote"
		viewCenter=v.GetCenter();
		if(	viewCenter.x>i.GetWidth()-tamanioVista ||
			viewCenter.x<tamanioVista) viewVelx*=-1;
		if(	viewCenter.y>i.GetHeight()-tamanioVista ||
			viewCenter.y<tamanioVista) viewVely*=-1;
		
		// limpiamos la pantalla y dibujamos
		w.Clear(sf::Color(0,0,0));
		w.Draw(s);
		w.Display();
	}
	return 0;
}

