#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "SpriteSheetManager.h"
#include "Animation.h"
#include "Megaman.h"
#include "Disparos.h"
#include "Nivel.h"
using namespace std;


int main(int argc, char *argv[]) {
	
	int const resx=850, resy=600;
	// variables para saber si mostrar o no algunas cosas
	bool showGrid=false, showMegamanAABB=false, showHelp=true;
	
	// cargamos el nivel desde un archivo
	Nivel n("../data/Mylevel.lev");
	// creamos una vista que abarque todo el nivel
	sf::View v=n.InitLevelView(resx, resy);
	
	// creamos la ventana y le asignamos la vista del nivel
	sf::RenderWindow w(VideoMode(resx,resy),"Megaman");
	w.SetView(v);
	
	// creamos e inicializamos nuestra estructura joystick
	Joystick j;
	j.up=j.down=j.left=j.right=j.a=j.b=0;
	
	// creamos el manejador para los disparos
	ManejadorDisparos disparos;
	
	// creamos e inicializamos a Megaman con el nivel
	// y el manejador de disparos
	Megaman megaman(&disparos, &n);
	megaman.SetPosition(96,64);
	
	
	sf::Clock clk;
	sf::Event e;
	
	while(w.IsOpened()) {
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();
			
			// actualizamos el estado del joystick segun los eventos
			if (e.Type == sf::Event::KeyPressed){
				switch(e.Key.Code){
					case sf::Key::Up:		j.up=true; break; 
					case sf::Key::Down: 	j.down=true; break; 
					case sf::Key::Left: 	j.left=true; break; 
					case sf::Key::Right: 	j.right=true; break; 
					case sf::Key::A: 		j.a=true; break; 
					case sf::Key::S: 		j.b=true; break;
					case sf::Key::G: 		showGrid=!showGrid; break;
					case sf::Key::B: 		showMegamanAABB=!showMegamanAABB; break;
					case sf::Key::H: 		showHelp=!showHelp; break;
					case sf::Key::F12:		w.Capture().SaveToFile("screenshot.png");
					case sf::Key::Escape: 	exit(0); break;
					default: break;
				}
			}
			
			if (e.Type == sf::Event::KeyReleased){
				switch(e.Key.Code){
					case sf::Key::Up:		j.up=false; break; 
					case sf::Key::Down: 	j.down=false; break; 
					case sf::Key::Left: 	j.left=false; break; 
					case sf::Key::Right: 	j.right=false; break; 
					case sf::Key::A: 		j.a=false; break; 
					case sf::Key::S: 		j.b=false; break;
					default: break;
				}
			}
			
		}
		
		// actualizamos el estado de Megaman y los proyectiles
		megaman.Mover_y_Animar(j, clk.GetElapsedTime());
		disparos.MoverDisparos(clk.GetElapsedTime(), v);
		clk.Reset();
		
		// limpiamos la pantalla
		w.Clear(Color(10,10,20));
		
		// dibuja el nivel
		n.Draw(w);
		
		// dibuja la grilla alrededor de los tiles
		if(showGrid)
			n.DrawGrid(w);
		
		// dibuja los disparos
		disparos.DibujarDisparos(w);
		
		// dibuja a Megaman
		w.Draw(megaman);
		
		
		// dibuja el bounding box de Megaman
		if(showMegamanAABB){
			FloatRect bb=megaman.GetAABB();
			w.Draw(sf::Shape::Rectangle(bb.Left, bb.Top, bb.Right, bb.Bottom, sf::Color(0,0,0,0), 1, sf::Color(255,0,0)));
		}
		
		// despliega la ayuda
		if (showHelp)
			w.Draw(sf::String(" a - disparar\n s - saltar\n flechas - moverse\n g - mostrar/ocultar grilla\n b - mostrar/ocultar bbox megaman\n h - mostrar/ocultar ayuda", Font::GetDefaultFont(), 8));
		
		// actualiza la pantalla
		w.Display();
	}
	return 0;
}
