#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "ParallaxLayer.h"

int main(int argc, char *argv[]) {
	// creamos la ventana
	sf::RenderWindow w(sf::VideoMode(800,400),"Ejemplo Parallax Scrolling");

	// nombres de los archivos de capas
	char *archivosCapas[]={ "../data/parallax-1-800x200.png",
							"../data/parallax-2-800x120.png",
							"../data/parallax-3-800x200.png",
							"../data/parallax-4-800x200.png",
							"../data/parallax-5-1600x400.png"};
	
	// cargamos las imagenes de las capas
	sf::Image imgCapas[5];
	for(unsigned i=0; i<5; i++)
		imgCapas[i].LoadFromFile(archivosCapas[i]);
	
	// los offsets y velocidades de las capas
	float offsetYCapas[]={0,120,80,90,0};
	float velCapas[]={0.05, 0.09, 0.15, 0.23, 0.3};
	
	// inicializamos las capas del parallax
	ParallaxLayer *capas[5];
	for(unsigned i=0; i<5; i++)
		capas[i]=new ParallaxLayer(imgCapas[i], velCapas[i], true, 0,
												0, false, offsetYCapas[i]);

	float elapsedTime; // el tiempo transcurrido	
	while(w.IsOpened()) {
		sf::Event e;
		elapsedTime=w.GetFrameTime();
		// atendemos eventos
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();
		}
		// limpiamos la pantalla
		w.Clear(sf::Color(0,0,0));
		// movemos las capas y dibujamos
		for(unsigned i=0; i<5; i++) {
			capas[i]->Move(elapsedTime);
			capas[i]->Draw(w);
		}
		// actualizamos la panatalla
		w.Display();
	}
	return 0;
}

