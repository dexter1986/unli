#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "SpriteSheetManager.h"
#include "Animation.h"
#include "Megaman.h"
#include "Disparos.h"
#include "Nivel.h"
using namespace std;


bool showHelp=true, smoothScroll=false;

int const resx=800, resy=600;

int main(int argc, char *argv[]) {
	// creamos la ventana y definimos la porcion visible del plano
	sf::RenderWindow w(VideoMode(resx,resy),"Megaman");
	
	// cargamos el nivel desde un archivo
	Nivel n("../data/Mylevel.lev");
	
	sf::String ayuda(" a - disparar\n s - saltar\n flechas - moverse\n g - scroll normal/suavizado\n h - mostrar/ocultar ayuda", Font::GetDefaultFont(), 8);
	
	//	inicializamos la vista del nivel
	n.InitLevelView(resx, resy);
	w.SetView(n.GetView());
	
	// creamos e inicializamos nuestra estructura joystick
	Joystick j;
	j.up=j.down=j.left=j.right=j.a=j.b=false;
	
	// creamos el manejador para los disparos
	ManejadorDisparos disparos;

	// creamos e inicializamos a megaman
	Megaman megaman(&disparos, &n);
	megaman.SetPosition(96,64);
	
	
	sf::Clock clk;
	sf::Event e;
	
	while(w.IsOpened()) {
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();
			
			// actualizamos el estado del joystick segun los eventos
			if (e.Type == sf::Event::KeyPressed){
				switch(e.Key.Code){
					case sf::Key::Up:		j.up=true; break; 
					case sf::Key::Down: 	j.down=true; break; 
					case sf::Key::Left: 	j.left=true; break; 
					case sf::Key::Right: 	j.right=true; break; 
					case sf::Key::A: 		j.a=true; break; 
					case sf::Key::S: 		j.b=true; break;
					case sf::Key::H: 		showHelp=!showHelp; break;
					case sf::Key::G: 		smoothScroll=!smoothScroll; break;
					case sf::Key::F12:		w.Capture().SaveToFile("screenshot.png");
					case sf::Key::Escape: 	exit(0); break;
				}
			}
			
			if (e.Type == sf::Event::KeyReleased){
				switch(e.Key.Code){
					case sf::Key::Up:		j.up=false; break; 
					case sf::Key::Down: 	j.down=false; break; 
					case sf::Key::Left: 	j.left=false; break; 
					case sf::Key::Right: 	j.right=false; break; 
					case sf::Key::A: 		j.a=false; break; 
					case sf::Key::S: 		j.b=false; break;
				}
			}
			
		}
		
		// actualizamos el estado de Megaman y los proyectiles
		megaman.Mover_y_Animar(j, clk.GetElapsedTime());
		
		// hacemos scrolling
		if(!smoothScroll)n.SetViewCenter(megaman.GetPosition());
		else n.SetViewCenterSmooth(megaman.GetPosition(), 0.5, clk.GetElapsedTime());

		disparos.MoverDisparos(clk.GetElapsedTime(), n.GetView().GetRect());
		
		clk.Reset();
		
		// dibujamos
		w.Clear(Color(10,10,20));
		n.Draw(w);
		disparos.DibujarDisparos(w);
		w.Draw(megaman);
		
		if(showHelp){
			ayuda.SetPosition(sf::Vector2f(n.GetView().GetRect().Left, n.GetView().GetRect().Top));
			w.Draw(ayuda);
		}
		
		w.Display();
	}
	return 0;
}
