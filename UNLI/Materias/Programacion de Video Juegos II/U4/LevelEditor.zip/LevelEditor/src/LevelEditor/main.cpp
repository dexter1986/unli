#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "Nivel.h"
#include "Menu.h"
#include <fstream>
using namespace std;
using namespace sf;


bool showGrid=true;		// si mostramos la grilla
bool editSolido=false;	// si estamos editando los tiles solidos
bool showHelp=true;		// si mostramos la ayuda rapida

bool levelLoaded=false;		// si el nivel se cargo o hubo error
string levelFilename="";	// el nombre del archivo de nivel cargado

sf::String ayuda(" g - mostrar/ocultar grilla\n m - editar tiles solidos\n h - mostrar/ocultar ayuda", sf::Font::GetDefaultFont(), 24);

// para controlar el scroll, creamos un circulo
// imaginario centrado en la ventana y solo moveremos
// el scroll cuando el cursor del mouse se encuentre
// fuera del circulo. El tamanio del circulo es un
// porcentaje del tamanio de la ventana
const float scrollSpeed=0.6;
const float scrollCircleRadioPercent=0.5;
float scrollCircleRadio;
sf::Vector2i scrollCircleCenter;

// la ventana y el nivel
RenderWindow w;
Nivel n;


// declaraciones de las funciones
void SelectFile(string &);	// abre el dialogo para seleccion de archivo
void MenuCallBack(Menu &m, string selectedOpt);	// la funcion callback del menu
void AtenderEventosTeclado(sf::Event &e, Nivel &n, sf::RenderWindow &w);	// maneja eventos de teclado
void EditarNivel(Nivel &n, sf::Event &e, sf::Vector2i &cursor);	// edita los tiles del nivel con el raton
void InitView(Nivel &n, sf::RenderWindow &w);	// inicializa la vista del nivel y la asigna a la ventana
bool LoadLevel(string filename, Nivel &n, sf::RenderWindow &w);	// carga el nivel e inicializa la vista
void MostrarMenu(sf::RenderWindow &w);	// muestra el menu



void MostrarMenu(sf::RenderWindow &w){
	// creamos el menu
	Menu m(w, MenuCallBack);
	m.AddOption("Volver al editor");
	m.AddOption("Cargar nivel");
	m.AddOption("Guardar nivel");
	m.AddOption("Guardar nivel como");
	m.AddOption("Redimensionar nivel");
	m.AddOption("Probar nivel");
	m.AddOption("");
	m.AddOption("Salir");
	// mostramos el menu
	m.Show();
}

#ifdef __WIN32__
	#include <windows.h>
	#include <Commdlg.h>
#endif


// permite seleccionar un archivo y devuelve su nombre
void SelectFile(string &s){
	string newFilename;
	#ifdef __WIN32__
		char fileOut[256]={0};
		OPENFILENAME opfn;
		ZeroMemory(&opfn, sizeof(opfn)); 
		opfn.lStructSize=sizeof(opfn);
		opfn.lpstrFile=fileOut;
		opfn.lpstrInitialDir=".";
		opfn.nMaxFile=255;
		opfn.Flags=OFN_EXPLORER;
		GetOpenFileName(&opfn);
		newFilename=fileOut;
	#else
		system("zenity --file-selection > /tmp/zenity_file_sel");
		ifstream i("/tmp/zenity_file_sel");
		getline(i, newFilename);
		i.close();
	#endif
	if(newFilename!="") s=newFilename;
}



// esta funcion es llamada por el menu
void MenuCallBack(Menu &m, string selectedOpt){
	if(selectedOpt=="Volver al editor"){
		if(levelLoaded)
			m.ExitMenu();
	}else if(selectedOpt=="Cargar nivel"){
		SelectFile(levelFilename);
		if(levelFilename=="") return;
		LoadLevel(levelFilename, n, w);
		m.QuitMenu();
	}else if(selectedOpt=="Guardar nivel"){
		if(levelFilename=="") return;
		n.Save(levelFilename);
		m.ExitMenu();
	}else if(selectedOpt=="Guardar nivel como"){
		if(levelFilename=="") return;
		SelectFile(levelFilename);
		n.Save(levelFilename);
		m.ExitMenu();
	}else if(selectedOpt=="Redimensionar nivel"){
		if(levelLoaded){
			int nuevoAncho, nuevoAlto;
			cout<<"Redimensionar el nivel"<<endl;
			cout<<"======================"<<endl;
			cout<<"Seleccione el nuevo ancho (actual: "<<n.GetLevelSize().x<<")"<<endl;
			cin>>nuevoAncho;
			cout<<"Seleccione el nuevo alto (actual: "<<n.GetLevelSize().y<<")"<<endl;
			cin>>nuevoAlto;
			n.Resize(nuevoAncho, nuevoAlto);
			InitView(n, w);
			m.QuitMenu();
		}
	}else if(selectedOpt=="Probar nivel"){
		if(levelLoaded && levelFilename!=""){
			n.Save(levelFilename);
			string command;
			#ifdef __WIN32__
				command="./megaman.exe \"";
			#else
				command="./megaman.bin \"";
			#endif
			command+=levelFilename+"\"";
			system(command.c_str());
		}
	}else if(selectedOpt=="Salir"){
		exit(0);
	}
}


// maneja los eventos de teclado
void AtenderEventosTeclado(sf::Event &e, Nivel &n, sf::RenderWindow &w){
	if(e.Type == sf::Event::KeyPressed){
		switch(e.Key.Code){
			case sf::Key::G:  showGrid=!showGrid; break;
			case sf::Key::S:  n.Save(levelFilename); cout<<"Level saved as: "<<levelFilename<<endl; break;
			case sf::Key::M:  editSolido=!editSolido; break;
			case sf::Key::H:  showHelp=!showHelp; break;
			case sf::Key::Escape: MostrarMenu(w); break;
			
			default: break;
		}
	}
}



// maneja los eventos del raton para editar los tiles del nivel
// recibe el nivel y la posicion del cursor sobre el nivel
// (cual tile es el seleccionado)
void EditarNivel(Nivel &n, sf::Event &e, sf::Vector2i &cursor){
	if(e.Type == sf::Event::MouseButtonPressed){
		Nivel::Tile &t=n.tiles[cursor.y][cursor.x];
		switch(e.MouseButton.Button){
			case 0:
				if(editSolido){
					t.solid=!t.solid;
				}else{
					t.iImage++;
					if(t.iImage==n.sm.Size()) t.iImage=-1;
					if(t.iImage!=-1) t.solid=true;
					else  t.solid=false;
				}
			break;
			
			case 1:
				if(editSolido){
					t.solid=!t.solid;
				}else{
					t.iImage--;
					if(t.iImage<-1) t.iImage=n.sm.Size()-1;
					if(t.iImage!=-1) t.solid=true;
					else  t.solid=false;
				}
			break;
			
			case 2:
				t.iImage=-1;
				t.solid=false;
			break;
		}
		// ajustamos la imagen del tile segun su variable iImage
		if(t.iImage!=-1) t.SetImage(n.sm[t.iImage]);
	}
}


// inicializa la vista del nivel y la asigna a la ventana
// tambien inicializa la zona de scroll para moverse a traves
// del nivel
void InitView(Nivel &n, sf::RenderWindow &w){
	// iniciliza la vista del nivel y la asigna a la ventana
	n.InitLevelView(w.GetWidth(), w.GetHeight());
	w.SetView(n.GetView());
	// inicializa la posicion y el tamano de la zona de scroll
	scrollCircleCenter.x=w.GetWidth()/2;
	scrollCircleCenter.y=w.GetHeight()/2;
	if(scrollCircleCenter.x<scrollCircleCenter.y){
		scrollCircleRadio=scrollCircleCenter.x*scrollCircleRadioPercent;
	}else{
		scrollCircleRadio=scrollCircleCenter.y*scrollCircleRadioPercent;
	}
}


// carga el nivel desde el archivo dado e iniciliza la vista de
// la ventana, guarda en la bandera levelLoaded si la operacion
// fue exitosa
bool LoadLevel(string filename, Nivel &n, sf::RenderWindow &w){
	levelLoaded=n.Load(filename);
	if(levelLoaded){
		InitView(n, w);
		levelFilename=filename;
	}
	return levelLoaded;
}



int main(int argc, char *argv[]) {
	w.Create(VideoMode(800,600),"SFML Window");
	w.Clear(sf::Color(0,0,0));
	
	MostrarMenu(w);
	
	
	// coordenadas del raton en la ventana
	sf::Vector2i mouseCoords;
	// coordenadas del raton en la vista del nivel
	sf::Vector2f realMouseCoords;
	// sobre que tile esta posicionado el raton
	sf::Vector2i mouseCursor;
	
	const sf::Input& i=w.GetInput();
	float elapsedTime;
	while(w.IsOpened()){
		// conseguimos las coordenadas del raton en la ventana
		mouseCoords.x=i.GetMouseX();
		mouseCoords.y=i.GetMouseY();
		
		// las traducimos a coordenadas dentro del nivel
		realMouseCoords=w.ConvertCoords(mouseCoords.x, mouseCoords.y);
		if(levelLoaded){
			mouseCursor.x=int(realMouseCoords.x)/n.GetTileSize().x;
			mouseCursor.y=int(realMouseCoords.y)/n.GetTileSize().y;
		}
		
		sf::Event e;
		while(w.GetEvent(e)){
			if(e.Type == e.Closed){
				w.Close();
			}
			
			// adapta la vista del nivel a los cambios
			// de tamanio de la ventana
			if(e.Type == e.Resized){
				InitView(n, w);
			}
			
			AtenderEventosTeclado(e, n, w);
			EditarNivel(n, e, mouseCursor);
		}
		elapsedTime=w.GetFrameTime();
		
		
		// si el raton sale fuera del disco imaginario, movemos la ventana
		if(sqrt(powf(mouseCoords.x-scrollCircleCenter.x,2)+powf(mouseCoords.y-scrollCircleCenter.y,2))>scrollCircleRadio){
			n.SetViewCenterSmooth(realMouseCoords, scrollSpeed, elapsedTime);
		}
		
		w.Clear(Color(0,0,0,255));
		
		// dibuja el nivel
		if(levelLoaded){
			n.Draw(w);
			if(editSolido) n.DrawSolids(w);
			if(showGrid) n.DrawGrid(w);
			n.DrawCursor(w, mouseCursor.x, mouseCursor.y);
			if(showHelp){
				ayuda.SetPosition(n.GetView().GetRect().Left, n.GetView().GetRect().Top);
				ayuda.SetSize(n.GetView().GetRect().GetWidth()*0.03);
				w.Draw(ayuda);
			}
		}
		
		w.Display();
	}
	return 0;
}

