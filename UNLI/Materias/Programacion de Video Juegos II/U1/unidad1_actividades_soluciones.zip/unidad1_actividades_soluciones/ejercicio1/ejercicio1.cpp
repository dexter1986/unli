#include <iostream>
#include <cstdlib>
#include <ctime>

#include <SFML/Graphics/Image.hpp>
using namespace std;

template<class T>
T BuscaMayor(T arr[], unsigned tam){
	T mayor=arr[0];
	for(unsigned i=1; i<tam; i++){
		if(arr[i]>mayor) mayor=arr[i];
	}
	return mayor;
}


int main(int argc, char *argv[]){
	const int tamanio=10;
	int arr1[tamanio];
	double arr2[tamanio];
	string arr3[tamanio];
	
	// inicializamos la semilla del generador
	srand(time(NULL));
	
	// cargamos los arreglos numericos con valores al azar
	for(unsigned i=0; i<tamanio; i++){
		arr1[i]=rand()%20;
		arr2[i]=rand()/float(RAND_MAX);
	}
	
	// inicializamos el arreglo de cadenas
	arr3[0]="programacion";
	arr3[1]="videojuegos";
	arr3[2]="templates";
	arr3[3]="stl";
	arr3[4]="vector";
	arr3[5]="list";
	arr3[6]="map";
	arr3[7]="stack";
	arr3[8]="queue";
	arr3[9]="multimap";
	
	
	// mostramos los arreglos
	cout<<"El primer arreglo: ";
	for(unsigned i=0; i<tamanio; i++) cout<<arr1[i]<<" ";
	cout<<endl;
	
	cout<<"El segundo arreglo: ";
	for(unsigned i=0; i<tamanio; i++) cout<<arr2[i]<<" ";
	cout<<endl;
	
	cout<<"El tercer arreglo: ";
	for(unsigned i=0; i<tamanio; i++) cout<<arr3[i]<<" ";
	cout<<endl<<endl;
	
	cout<<"El mayor del primer arreglo es: "<<BuscaMayor(arr1, tamanio)<<endl;
	cout<<"El mayor del segundo arreglo es: "<<BuscaMayor(arr2, tamanio)<<endl;
	// para el arreglo de strings, el mayor es el ultimo en orden alfabetico
	cout<<"El mayor del tercer arreglo es: "<<BuscaMayor(arr3, tamanio)<<endl;
	
	
	// probamos hacer un arreglo de sf::Image 
	sf::Image arr4[tamanio];
	//BuscaMayor(arr4, tamanio);
	// No podemos utilizar la funcion con el arreglo de sf::Image ya que no
	// puede utilizarse el operador > para comparar 2 datos de este tipo
	// Cuando el compilador intenta compilar la plantilla y se da cuenta
	// de que tal comparacion no es posible, nos arroja un error
	// La forma del error depende un poco del compilador que usemos, en mi
	// caso da esto:
	// In function 'T BuscaMayor(T*, unsigned int) [with T = sf::Image]':
	// instantiated from here
	// ejercicio1.cpp:12:3: error: no match for 'operator>' in '*(arr + ((long unsigned int)(((long unsigned int)i) * 104ul))) > mayor'
	
	system("pause");
	return 0;
}


