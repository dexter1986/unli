#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <list>
#include <algorithm>

using namespace std;

int main(int argc, char *argv[]){
	// inicializamos la semilla del generador
	srand(time(NULL));
	
	// a)
	// creamos un arreglo con 0 elementos, por lo que
	// debemos insertarlos con push_back()
	vector<int> v;
	for(unsigned i=0; i<50; i++) v.push_back(rand()%101);
	
	// b)
	cout<<"El vector: ";
	for(unsigned i=0; i<v.size(); i++) cout<<v[i]<<" ";
	cout<<endl;
	
	// c)
	// para mostrar el mayor y menor debemos desreferenciar el iterador
	cout<<"El mayor elemento: "<<*max_element(v.begin(), v.end())<<endl;
	cout<<"El menor elemento: "<<*min_element(v.begin(), v.end())<<endl;
	// ordenamos parte del vector
	sort(v.begin()+10, v.end()-10);
	cout<<"El vector despues de ordenar entre las pos 10 y 40: ";
	for(unsigned i=0; i<v.size(); i++) cout<<v[i]<<" ";
	cout<<endl;
	
	// d)
	// Los algoritmos max_element() y min_element() pueden utilizarse
	// ya que requieren una estructura con iteradores de tipo ForwardIterator (como el de la lista)
	// pero el algoritmo sort requiere iteradores de acceso aleatorio, por lo que no
	// podremos utilizarlo
	
	// e)
	vector<int> u;
	// insertamos al principio de u, parte de v
	u.insert(u.begin(), v.begin()+5, v.begin()+45);
	cout<<"El nuevo vector: ";
	for(unsigned i=0; i<u.size(); i++) cout<<u[i]<<" ";
	cout<<endl;
	
	// para eliminar utilizar unique, el vector debe estar ordenado
	sort(u.begin(), u.end());
	vector<int>::iterator repetidos;
	repetidos=unique(u.begin(), u.end());
	// por razones de eficiencia, unique() no realiza el borrado de los repetidos
	// sino que los mueve al final y nos corresponde a nosotros borrarlos todos juntos
	// unique devuelve un iterador donde esta el primer repetido
	
	// borramos todos los repetidos
	u.erase(repetidos, u.end());
	// ojo al mostrarlo, el arreglo tiene menos elementos que antes
	cout<<"El nuevo vector sin repetidos: ";
	for(unsigned i=0; i<u.size(); i++) cout<<u[i]<<" ";
	cout<<endl;
	
	// f)
	list<int> l;
	// realizamos el mismo procedimiento pero con una lista
	// insertamos al principio de l, parte de v
	l.insert(l.begin(), v.begin()+5, v.begin()+45);
	cout<<"La lista: ";
	for(list<int>::iterator i=l.begin(); i!=l.end(); i++) cout<<*i<<" ";
	cout<<endl;
	
	// como los algoritmo sort() y unique() requieren iteradores de acceso aleatorio
	// no pueden ser usados con la lista. Sin embargo la lista implementa sus propios
	// sort() y unique(). Estos algoritmos operan sobre toda la lista y no se puede elegir,
	// como en el caso del vector, hacerlo sobre una parte del contenedor
	l.sort();
	l.unique();
	// el unique() de la lista si elimina los repetido
	
	cout<<"La lista sin repetidos: ";
	for(list<int>::iterator i=l.begin(); i!=l.end(); i++) cout<<*i<<" ";
	cout<<endl;
	
	system("pause");
	return 0;
}


