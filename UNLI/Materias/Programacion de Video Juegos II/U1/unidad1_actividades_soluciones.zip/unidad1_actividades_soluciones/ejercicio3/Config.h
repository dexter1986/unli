#ifndef CONFIG_H
#define CONFIG_H

#include <iostream>
#include <fstream>
#include <map>
using namespace std;

class Config {
private:
	map<string,string> entries;

public:
	// Constructores
	Config();
	Config(string filename);
	
	// Cargar/Guardar desde/en archivos
	int Load(string filename);
	int Save(string filename);
	
	// Pedir valor de una variable
	bool GetValue(string valName, float &var, float default_value=0);
	bool GetValue(string valName, int &var, int default_value=0);
	bool GetValue(string valName, string &var, string default_value="");
	
	// Setear valor de una variable
	bool SetValue(string valName, float var);
	bool SetValue(string valName, int var);
	bool SetValue(string valName, string var);
	
	// util para depurar
	void showentries();
};

#endif

