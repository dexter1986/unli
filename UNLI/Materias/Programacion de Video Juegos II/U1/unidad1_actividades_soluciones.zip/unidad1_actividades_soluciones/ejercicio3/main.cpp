#include <iostream>
#include <string>
#include "Config.h"
using namespace std;

int main(int argc, char **argv){
	// abrimos el archivo de configuraci�n
	Config config;
	config.Load("config.ini");

	// leemos los valores de la resoluci�n de pantalla
	int resw, resh;
	config.GetValue("ResW", resw);
	config.GetValue("ResH", resh);
	cout<<"La resoluci�n que figura en la configuraci�n es: ("<<resw<<","<<resh<<")"<<endl;

	// leemos el nombre del jugador
	string playername;
	config.GetValue("PlayerName", playername);
	cout<<"El nombre del jugador es: "<<playername<<endl;

	// cambiamos el nombre del jugador
	cout<<"Ingrese un nuevo nombre para el jugador: ";
	cin>>playername;
	config.SetValue("PlayerName", playername);

	// guardamos la configuracion
	config.Save("config.ini");
	system("pause");
	return 0;
}

