#include "Config.h"
#include <cstdlib>
#include <sstream>
using namespace std;

// Constructores
Config::Config(){
	
}

Config::Config(string filename){
	Load(filename);
}


/*
 * \brief:  carga la configuracion desde un archivo de texto.
 * 			Las opciones tienen la forma nombre=valor. Se almacena
 * 			tanto el nombre como el valor en strings
 * \param: nombre del archivo
 * \return: cantidad de opciones leidas o -1 si no se encontro el archivo
 */
int Config::Load(string filename){
	ifstream input(filename.c_str());
	if(!input.is_open()){
		cerr<<"ERROR: No se encontro el archivo "<<filename<<endl;
		return -1;
	}
	string temp, s1, s2;
	unsigned pos;
	while(getline(input, temp)){
		pos=temp.find('=');
		s1=temp.substr(0, pos);
		s2=temp.substr(pos+1);
		entries.insert(entries.end(), pair<string, string>(s1, s2));
	}
	input.close();
	return entries.size();
}


/*
 * \brief: guarda las opciones y sus valores en un archivo de texto
 * \param: nombre del archivo
 * \return: nada
 */
int Config::Save(string filename){
	ofstream output(filename.c_str());
	map<string, string>::iterator p=entries.begin();
	while(p!=entries.end()){
		output<<p->first<<"="<<p->second<<endl;
		p++;
	}
	output.close();
	return 0;
}


/*
 * \brief:  busca el valor correspondiente a una opcion y lo coloca en var
 *			convirtiendolo de cadena al tipo de var
 * \param: nombre de la opcion
 * \param: variable donde se coloca el valor de la opcion buscada
 * \param: valor por defecto a poner en var en caso de no encontrar la opcion
 * \return: true si se encontro la variable, false si tomo el valor por defecto
 */
bool Config::GetValue(string valName, float &var, float default_value){
	map<string, string>::iterator p=entries.find(valName);
	if(p!=entries.end()){
		var=atof((p->second).c_str());
		return true;
	}else{
		var=default_value;
		return false;
	}
}

bool Config::GetValue(string valName, int &var, int default_value){
	map<string, string>::iterator p=entries.find(valName);
	if(p!=entries.end()){
		var=atoi((p->second).c_str());
		return true;
	}else{
		var=default_value;
		return false;
	}
}

bool Config::GetValue(string valName, string &var, string default_value){
	map<string, string>::iterator p=entries.find(valName);
	if(p!=entries.end()){
		var=p->second;
		return true;
	}else{
		var=default_value;
		return false;
	}
}


/*
 * \brief:  actualiza o inserta el valor para una opcion, convirtiendo desde el
 * 			tipo de var a string para poder almacenarlo, la conversion se hace
 *			a traves de stringstreams, que son objetos que se comportan como
 *			strings y flujos (como los que usamos para archivos o consola)
 *			al mismo tiempo (http://www.cplusplus.com/reference/iostream/stringstream/)
 * \param: nombre de la opcion
 * \param: valor de la opcion
 * \return: true si el valor se actualizo, false si fue agregado
 */
bool Config::SetValue(string valName, float var){
	map<string, string>::iterator p=entries.find(valName);
	stringstream ss;
	ss<<var;
	if(p!=entries.end()){
		p->second=ss.str();
		return true;
	}else{
		entries.insert(entries.end(), pair<string, string>(valName,ss.str()));
		return false;
	}
}

bool Config::SetValue(string valName, int var){
	map<string, string>::iterator p=entries.find(valName);
	stringstream ss;
	ss<<var;
	if(p!=entries.end()){
		p->second=ss.str();
		return true;
	}else{
		entries.insert(entries.end(), pair<string, string>(valName,ss.str()));
		return false;
	}
}

bool Config::SetValue(string valName, string var){
	map<string, string>::iterator p=entries.find(valName);
	if(p!=entries.end()){
		p->second=var;
		return true;
	}else{
		entries.insert(entries.end(), pair<string, string>(valName,var));
		return false;
	}
}


// solo para depurar, mostramos el mapeo por consola
void Config::showentries(){
	map<string, string>::iterator p=entries.begin();
	while(p!=entries.end()){
		cout<<p->first<<"="<<p->second<<endl;
		p++;
	}
}
