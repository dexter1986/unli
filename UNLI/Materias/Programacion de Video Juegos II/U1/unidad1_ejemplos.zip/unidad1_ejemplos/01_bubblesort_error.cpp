#include <iostream>
using namespace std;

void BubbleSort(int arr[], int n){
	int i,j;
	int min;
	for(i=0; i<n-1; i++){ // bucle principal
		for(j=0; j<n-1; j++){
			if(arr[j]>arr[j+1]){
				min=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=min;
			}
		}
	}
}

int main(int argc, char *argv[]){
	int vector1[50];
	float vector2[50];
	double vector3[50];
	
	BubbleSort(vector1, 50);
	BubbleSort(vector2, 50);
	BubbleSort(vector3, 50);
	
	return 0;
}
