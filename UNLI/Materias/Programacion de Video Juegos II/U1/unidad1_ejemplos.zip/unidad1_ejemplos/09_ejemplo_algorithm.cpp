#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main(int argc, char *argv[]) {
	vector<int> v;
	for(unsigned i=0; i<20; i++) v.insert(v.end(), rand()%11);
	
	cout<<"v=";
	for(unsigned i=0; i<20; i++) cout<<v[i]<<" ";
	cout<<endl;
	
	// ordenamos la segunda mitad del vector
	cout<<"Ordenando la segunda mitad del vector"<<endl;
	vector<int>::iterator mitad=v.begin()+(v.size()/2);
	sort(mitad, v.end());
	cout<<"v=";
	for(unsigned i=0; i<v.size(); i++) cout<<v[i]<<" ";
	cout<<endl;
	
	// eliminamos los repetidos de la segunda mitad
	cout<<"Eliminando los repetidos de la segunda"<<endl;
	vector<int>::iterator nuevofinal;
	nuevofinal=unique(mitad, v.end());
	v.erase(nuevofinal, v.end());
	cout<<"v=";
	for(unsigned i=0; i<v.size(); i++) cout<<v[i]<<" ";
	cout<<endl;
	
	// buscamos el mayor y el menor de la primer mitad
	cout<<"El mayor de la primer mitad: ";
	cout<<*max_element(v.begin(), mitad)<<endl;
	cout<<"El menor de la primer mitad: ";
	cout<<*min_element(v.begin(), mitad)<<endl;
	
	
	return 0;
}

