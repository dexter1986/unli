#include <iostream>
using namespace std;

class Rect{
private:
	int x0, y0, ancho, alto;
	
public:
	Rect(int x0, int y0, int ancho, int alto);
	int GetAncho();
	int GetAlto(){return alto;};
}

Rect::Rect(int x0, int y0, int ancho, int alto){
	this->x0=x0;
	this->y0=y0;
	this->ancho=ancho;
	this->alto=alto;
}

int Rect::GetAncho(){return ancho;}

int main(int argc, char *argv[]){
	Rect r(1, 2, 3, 4);
	cout<<r.GetAlto()<<" "<<r.GetAncho()<<endl;
	return 0;
}
