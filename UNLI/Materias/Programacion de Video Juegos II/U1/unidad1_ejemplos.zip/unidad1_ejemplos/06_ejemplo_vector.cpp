#include <iostream>
#include <cstdlib>
#include <vector>

using namespace std;

int main(int argc, char *argv[]){
	vector<float> v;
	
	// inicializamos el generador de numeros aleatorios
	srand(time(NULL));
	
	// insertamos 10 valores aleatorios en el vector
	for(unsigned i=0; i<10; i++){
		v.push_back(rand()/float(RAND_MAX));
	}
	
	// mostramos los valores del vecor
	for(vector<float>::iterator p=v.begin(); p<v.end(); p++){
		cout<<*p<<endl;
	}
	
	return 0;
}
