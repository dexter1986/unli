#include <iostream>
using namespace std;

template <typename T>
class Rect{
private:
	T x0, y0, ancho, alto;
	
public:
	Rect(T x0, T y0, T ancho, T alto);
	T GetAncho();
	T GetAlto(){return alto;};
};

template <typename T>
Rect<T>::Rect(T x0, T y0, T ancho, T alto){
	this->x0=x0;
	this->y0=y0;
	this->ancho=ancho;
	this->alto=alto;
}

template <class T>
T Rect<T>::GetAncho(){return ancho;}


int main(int argc, char *argv[]) {
	Rect<float> r1(0.1, 0.2, 0.3, 0.4);
	Rect<int> r2(1, 2, 3, 4);
	
	cout<<r1.GetAlto()<<" "<<r2.GetAncho()<<endl;
	
	return 0;
}

