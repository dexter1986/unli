#include <iostream>
#include <map>
#include <string>

using namespace std;

int main(int arcg, char *argv[]){
	map<string, int> calificaciones;
	string nombre;
	int nota;
	
	// leemos por consola los nombres y calificaciones
	// de 5 alumnos y los insertamos en el mapa
	for(unsigned i=0; i<5; i++){
		cout<<"Ingrese el nombre del alumno: ";
		cin>>nombre;
		cout<<"Ingrese la calificacion: ";
		cin>>nota;
		// insertamos en el mapeo un nuevo par
		//con el nombre y la nota del alumno
		calificaciones.insert(	calificaciones.end(),
								pair<string, int>(nombre, nota));
	}
	cout<<endl;
	
	// busca si existe la calificacion de un alumno
	map<string, int>::iterator f;
	f=calificaciones.find("Kenny Mathews");
	if(f!=calificaciones.end()){
		cout<<"La calificacion de Kenny Mathews es: ";
		cout<<f->second<<endl;
	}else{
		cout<<"NO EXISTE calificacion para Kenny Mathews"<<endl;
	}
	cout<<endl;
	
	// con esto podemos insertar una nueva calificacion
	// o cambiar una que ya existe
	calificaciones["Shannon Mathews"]=5;

	
	// finalmente mostramos todos los elementos del mapeo
	cout<<"CALIFICACIONES"<<endl;
	map<string, int>::iterator p=calificaciones.begin();
	pair<string, int> miPar;
	while(p!=calificaciones.end()){
		miPar=*p;
		cout<<"Alumno: "<<miPar.first;
		cout<<"\t\t\t\tNota: "<<miPar.second<<endl; 
		p++;
	}
	
	
	return 0;
}


