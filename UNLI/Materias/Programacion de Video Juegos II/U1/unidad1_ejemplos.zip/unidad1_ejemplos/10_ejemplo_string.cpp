#include <iostream>
#include <string>

using namespace std;

int main(int argc, char *argv[]) {
	string cadena=
	"Casi todos creen que el tiempo es como un rio \
que fluye seguro y veloz en una sola direccion, \
pero yo le he visto la cara al tiempo y les puedo \
asegurar que estan equivocados. El tiempo es un \
oceano en la tormenta.";
	
	// mostramos la cadena
	cout<<cadena<<endl<<endl;
	
	// contamos la cantidad de veces que aparece
	// la palabra tiempo
	int ntiempo=0, pos;
	pos=cadena.find("tiempo");
	while(pos!=string::npos){
		ntiempo++;
		// busca "tiempo" empezando desde pos+6
		pos=cadena.find("tiempo", pos+6);
	}
	cout<<"La palabra tiempo aparece "<<ntiempo;
	cout<<" veces en la cadena"<<endl<<endl;
	
	// realizamos algunas modificaciones
	cadena.replace(0, 10, "Ustedes");
	cout<<cadena<<endl<<endl;
	
	// mostramos solo una porcion de la cadena
	cout<<cadena.substr(173, 22)<<endl;
	
	return 0;
}

