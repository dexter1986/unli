#include <iostream>
#include <cstdlib>
#include <vector>
#include <list>

using namespace std;

int main(int argc, char *argv[]) {
	// declaramos la lista y el vector
	list<float> l;
	vector<int> v(10, 26);
	
	// inicializamos el generador de numeros aleatorios
	srand(time(NULL));
	
	// cargamos 10 valores aleatorios en la lista (entre 0 y 1)
	for(unsigned i=0; i<10; i++){
		l.insert(l.end(), rand()/float(RAND_MAX));
	}
	
	// mostramos los valores del vector
	cout<<"Valores del vector: "<<endl;
	for(unsigned i=0; i<v.size(); i++){
		cout<<v[i]<<endl;
	}
	
	// mostramos los valores de la lista
	cout<<"Valores de la lista: "<<endl;
	list<float>::iterator p=l.begin();
	while(p!=l.end()){
		cout<<*p<<endl;
		p++;
	}
	
	return 0;
}

