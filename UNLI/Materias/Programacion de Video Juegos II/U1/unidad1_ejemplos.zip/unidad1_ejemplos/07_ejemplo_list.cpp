#include <iostream>
#include <cstdlib>
#include <list>

using namespace std;

int main(int argc, char *argv[]){
	list<int> l;
	
	// inicializamos el generador de numeros aleatorios
	srand(time(NULL));
	
	// insertamos 20 valores aleatorios en el vector
	for(unsigned i=0; i<20; i++){
		l.insert(l.end(), rand()%10);
	}
	
	cout<<"La lista:";
	list<int>::iterator p=l.begin();
	while(p!=l.end()){
		cout<<" "<<*p;
		p++;
	}
	cout<<endl;
	
	l.sort();
	cout<<"La lista ordenada:";
	for(p=l.begin(); p!=l.end(); p++){
		cout<<" "<<*p;
	}
	cout<<endl;
	
	l.unique();
	cout<<"La lista sin repetidos:";
	for(p=l.begin(); p!=l.end(); p++){
		cout<<" "<<*p;
	}
	cout<<endl;
	
	return 0;
}
