#include "glew/glew.h"
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "ParticleSystemManager.h"
#include <iostream>
#include <cstdio>

using namespace std;


int main(int argc, char *argv[]) {
	sf::RenderWindow w(sf::VideoMode(800,600),"Ejemplo Sistema de Particulas");
	
	unsigned const nMaxParticles=2000;
	
	// algunas variables utiles
	bool usePointSprites=false;
	bool pointSpritesSuported=false;
	float spawnRate=1000;
	
	
	// carga la imagen de la pariculas
	sf::Image i, j;
	i.LoadFromFile("../particle.png");
	j.LoadFromFile("../particle2.png");
	
	// crea cadenas para mostrar algunos mensajes
	sf::String str1("Botones raton: emitir particulas",sf::Font::GetDefaultFont(), 16);
	sf::String str2("Cantidad de particulas: 0",sf::Font::GetDefaultFont(), 16);
	str2.SetPosition(0, 60);
	sf::String str3("P: Activar/Desactivar GL_ARB_point_sprite: [Desactivado]",sf::Font::GetDefaultFont(), 16);
	str3.SetPosition(0, 40);
	sf::String str4("fps: 0",sf::Font::GetDefaultFont(), 16);
	str4.SetPosition(0, 80);
	sf::String str5("Mousewheel: SpawnRate (fuego) [1000]",sf::Font::GetDefaultFont(), 16);
	str5.SetPosition(0, 20);
	
	// obtiene el manejador de sistemas de particulas
	ParticleSystemManager &mg=ParticleSystemManager::GetManager();
	
	// averiguamos si podemos usar pointSprites
	if(glewIsSupported("GL_ARB_point_sprite")) pointSpritesSuported=true;
	else{
		cerr<<"ERROR: la extension GL_ARB_point_sprite no esta disponible"<<endl;
	}
	
	
	// crea un sistema de particulas y ajusta parametros del emisor
	// el sistema siempre va a estar vivo aunque no emita
	Emitter &em1=mg.AddParticleSystem(nMaxParticles);
	Emitter &em2=mg.AddParticleSystem(70);
	
	// ajusta los parametros del emisor1
	em1.SetImage(i);
	em1.SetEmmitVel(70, 70);
	em1.SetEmmitLife(1, 0.5);
	em1.SetBlendMode(sf::Blend::Add);
	em1.SetSpawnRate(spawnRate);
	em1.Spawn(false);
	
	// ajusta los parametros del emisor2
	em2.SetImage(j);
	em2.SetEmmitVel(300, 200);
	em2.SetEmmitLife(4, 0.3);
	em2.SetBlendMode(sf::Blend::Add);
	em2.SetSpawnRate(100000);
	em2.Spawn(false);
	
	// crea afectadores
	Affector *s=new SeekerGonzalo(w.GetView(), 700);
	Affector *g=new Gravity(0,-700);
	Affector *f1=new Fade(1.2);
	Affector *f2=new Fade(0.7);
	
	// aniade afectadores a los emisores
	em1.AddAffector(*g);
	em1.AddAffector(*f1);
	
	em2.AddAffector(*s);
	em2.AddAffector(*f2);
	
	// la entrada
	const sf::Input& Input = w.GetInput();
	
	// algunas variables auxiliares
	// cantidad de cuadros dibujados, para contar fps
	unsigned nFrames=0;
	// tiempo transcurrido y tiempo para contar fps
	float elapsedTime, fpsTime=0; 
	// para actualizar la cadena con los fps y otras
	char cadena[128];
	
	while(w.IsOpened()) {
		// el emisor2, al emitir, emite todas las particulas posibles
		// esto es para que parezca como una "explosion" de muchas
		// particulas juntas. Lo desactivamos ya que no podra emitir
		// mas particulas
		em2.Spawn(false);
		
		sf::Event e;
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();	
			if(e.Type == e.KeyPressed){
				switch(e.Key.Code){
				case sf::Key::F12:
					w.Capture().SaveToFile("screenshot.png");
					break;
					
				case sf::Key::P:
					if(pointSpritesSuported){
						usePointSprites=!usePointSprites;
						sprintf(cadena, "P: Activar/Desactivar GL_ARB_point_sprite: [%s]",usePointSprites?"Activado":"Desactivado");
						str3.SetText(cadena);
					}
					break;
				}
			}
			
			// hace que se emitan particulas segun los clicks
			if(e.Type == e.MouseButtonPressed){
				switch(e.MouseButton.Button){
				case sf::Mouse::Left:
						em1.Spawn(true);
					break;
					
					case sf::Mouse::Right:
						em2.Spawn(true);
					break;
				}
			}
			
			if(e.Type == e.MouseButtonReleased){
				switch(e.MouseButton.Button){
					case sf::Mouse::Left:
						em1.Spawn(false);
					break;
					

				}
			}
			
			// cambia el spawn rate con la ruedita del mouse
			if(e.Type == e.MouseWheelMoved){
				spawnRate-=10*e.MouseWheel.Delta;
				if(spawnRate<0) spawnRate=0;
				if(spawnRate>nMaxParticles) spawnRate=nMaxParticles;
				
				em1.SetSpawnRate(spawnRate);
				sprintf(cadena, "Mousewheel: SpawnRate (fuego) [%.0f]",em1.GetSpawnRate());
				str5.SetText(cadena);
			}
			
		}
		// el tiempo transcurrido
		elapsedTime=w.GetFrameTime();
		
		// ajusta la posicion del emisor segun el mouse
		em1.SetPosition(Input.GetMouseX(),Input.GetMouseY());
		em2.SetPosition(Input.GetMouseX(),Input.GetMouseY());
		((SeekerGonzalo *)s)->Seek(Input.GetMouseX(),Input.GetMouseY());
		
		// limpia la pantalla, simula y dibuja el sistema
		w.Clear(sf::Color(0,0,0,255));
		mg.Simulate(elapsedTime);
		if(usePointSprites) mg.Render_PointSprites(w);
		else mg.Render(w);
		
		// incrementa el tiempo del fps
		fpsTime+=elapsedTime;
		// si paso mas de 1 segundo, actualizamos los fps
		if(fpsTime>1){
			fpsTime--;
			sprintf(cadena, "Cantidad de particulas: %i",mg.GetNumParticles());
			str2.SetText(cadena);
			sprintf(cadena, "fps: %i",nFrames);
			str4.SetText(cadena);
			nFrames=0;
		}else{
			nFrames++;
		}
		
		// dibuja los mensajes
		w.Draw(str1);
		w.Draw(str2);
		w.Draw(str3);
		w.Draw(str4);
		w.Draw(str5);
		
		// actualiza la pantalla
		w.Display();
	}
	
	delete s;
	delete f1;
	delete f2;
	delete g;
	return 0;
}

