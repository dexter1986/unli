#include <iostream>
#include <vector>
#include <SFML/Graphics.hpp>
#include "PVJ2_SimpleEngine/AnimatedSprite.h"
#include <iostream>
int main(int argc, char *argv[]) {
	sf::Clock clock;
	float elapsedTime;
	sf::Event event;
	sf::RenderWindow window;
	
	window.Create(sf::VideoMode(800,600), "SFML_Test");
	window.SetFramerateLimit(60);
	
	AnimatedSprite animsprite("megaman_sprites.png", 3, 4);
	std::vector<unsigned> frames;
	frames.push_back(3); frames.push_back(4); frames.push_back(5); frames.push_back(4);
	animsprite.SetAnimation(frames, 1.0);
	animsprite.SetScale(4, 4);
	animsprite.SetPosition(100, 200);
	
	
	
	clock.Reset();
	while(window.IsOpened()){
		elapsedTime=clock.GetElapsedTime();
		clock.Reset();
		
		while(window.GetEvent(event)) {
			if(event.Type == event.Closed){
				window.Close();
			}
		}
		animsprite.Animate(elapsedTime);
		window.Clear(sf::Color(255, 255, 255));
		window.Draw(animsprite);
		window.Display();
	}
}

