#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "SpriteSheetManager.h"
#include "Animation.h"
using namespace sf;

// cuanto se muestra cada frame
const float animVel=0.1;

int main(int argc, char *argv[]){
	// creamos nuestra ventana y definimos el area visible
	RenderWindow w(VideoMode(300,300),"Ejemplo Animacion 2");
	w.SetView(View(FloatRect(0,0,57,60)));
	
	// creamos nuestro manager de imagenes
	SpriteSheetManager sm;
	sm.Load("../box_sprites.png", 4);
	
	// creamos los sprites
	Sprite box1, box2, box3;
	box1.SetPosition(0,0);
	box2.SetPosition(20,0);
	box3.SetPosition(40,0);
	
	// creamos las animaciones
	Animation anim1, anim2, anim3;
	anim1.AddFrame(sm[0], 0.25);
	anim1.AddFrame(sm[1], 0.25);
	anim1.AddFrame(sm[2], 0.25);
	anim1.AddFrame(sm[3], 0.25);
	
	anim2.AddFrame(sm[0], 1);
	anim2.AddFrame(sm[1], 0.25);
	anim2.AddFrame(sm[2], 0.25);
	anim2.AddFrame(sm[3], 0.25);
	anim2.AddFrame(sm[0], 1);
	anim2.AddFrame(sm[3], 0.25);
	anim2.AddFrame(sm[2], 0.25);
	anim2.AddFrame(sm[1], 0.25);

	// tiene 1 solo frame por lo que sera estatica
	anim3.AddFrame(sm[0], 1);
	
	// el reloj para contar el paso del tiempo
	Clock clk;
	float dt;
	
	// el bucle del juego...
	while(w.IsOpened()) {
		sf::Event e;
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();	
		}
		
		// calculamos el tiempo transcurrido
		dt=clk.GetElapsedTime();
		clk.Reset();
		
		// limpiamos el buffer de pantalla
		w.Clear(Color(0,0,0,255));
		
		box1.SetImage(anim1.Animate(dt));
		box2.SetImage(anim2.Animate(dt));
		box3.SetImage(anim3.Animate(dt));
		
		// dibujamos los sprites
		w.Draw(box1);
		w.Draw(box2);
		w.Draw(box3);
		
		// actualizamos la pantalla
		w.Display();
	}
	return 0;
}

