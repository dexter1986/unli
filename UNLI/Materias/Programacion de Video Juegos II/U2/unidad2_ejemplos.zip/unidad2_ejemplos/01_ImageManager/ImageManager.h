#ifndef IMAGEMANAGER_H
#define IMAGEMANAGER_H

#include <iostream>
#include <map>
#include <SFML/Graphics.hpp>
using namespace std;

class ImageManager {
private:
	map<string, sf::Image> images;
	
public:
	sf::Image &GetImage(string filename);
	sf::Image &operator[](string filename);
	unsigned Size();
};

#endif

