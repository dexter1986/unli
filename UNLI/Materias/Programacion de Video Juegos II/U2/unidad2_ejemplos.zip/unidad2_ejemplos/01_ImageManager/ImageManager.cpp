#include "ImageManager.h"

Image &ImageManager::GetImage(string filename){
	// buscamos la imagen pedida
	map<string, sf::Image>::iterator p;
	p=images.find(filename);
	// si no la encontramos
	if(p==images.end()){
		// la cargamos desde el archivo
		sf::Image img;
		img.LoadFromFile(filename);
		// y la insertamos en el mapa
		pair< map<string, sf::Image>::iterator, bool > q;
		q=images.insert(pair<string, sf::Image>(filename, img));
		// hacemos que p apunte a la imagen insertada
		p=q.first;
	}
	// devolvemos la imagen
	return p->second;
}


Image &ImageManager::operator[](string filename){
	return GetImage(filename);
}


unsigned ImageManager::Size(){
	return images.size();
}
