#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "SpriteSheetManager.h"
using namespace sf;

// cuanto se muestra cada frame
const float animVel=0.1;

int main(int argc, char *argv[]){
	// creamos nuestra ventana y definimos el area visible
	RenderWindow w(VideoMode(300,300),"Ejemplo Animacion 1");
	w.SetView(View(FloatRect(0,0,150,150)));
	
	// creamos nuestro manager de imagenes
	SpriteSheetManager sm;
	sm.Load("../hulk.png", 8);
	
	// creamos el sprite
	Sprite hulk;
	hulk.SetPosition(0,0);

	// el nro de cuadro que estamos mostrando
	int iFrame=0;
	// y la cantidad de tiempo que ya lo mostramos
	float frameElapsed=0;
	
	// el reloj para contar el paso del tiempo
	Clock clk;
	
	// el bucle del juego...
	while(w.IsOpened()) {
		sf::Event e;
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();	
		}
		
		// limpiamos el buffer de pantalla
		w.Clear(Color(0,0,0,255));
		
		// calculamos el tiempo que paso
		frameElapsed+=clk.GetElapsedTime();
		clk.Reset();
		
		if(frameElapsed>animVel){
			// actualizamos el frame y el tiempo
			iFrame++;
			frameElapsed-=animVel;
			// cuidamos que el nro de frame no se pase
			if(iFrame>7) iFrame=0;
		}
		
		// seteamos la imagen del sprite
		hulk.SetImage(sm[iFrame]);
		
		// y lo dibujamos
		w.Draw(hulk);
		
		// actualizamos la pantalla
		w.Display();
	}
	return 0;
}

