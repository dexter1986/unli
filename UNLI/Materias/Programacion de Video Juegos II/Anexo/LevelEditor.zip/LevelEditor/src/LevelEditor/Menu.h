#ifndef MENU_H
#define MENU_H
#include <SFML/Graphics/String.hpp>
#include <vector>
using namespace std;

class Menu;

// menuCallback sera utilizado para 
// el tipo de funcion que pasaremos como callback
typedef void (*menuCallback)(Menu &, string);

class Menu{
	private:
	vector<sf::String> opciones;	// las opciones
	sf::RenderWindow *w;			// la ventana sobre la cual dibujamos el menu
	menuCallback cb;				// la funcion cb sera la que llamaremos para que haga algo al seleccionar una opcion
	
	bool exit, quit;				// banderas para saber si se debe salir del menu
	sf::IntRect menuRect;			// la region del menu
	
	// opciones de tamanio y color
	unsigned menuFontSize;			// el tamanio de fuente
	unsigned menuBorder;			// el borde del menu
	unsigned optionPadding;			// espaciado vertical entre opciones
	sf::Color menuWindowColor;			// color del recuadro de menu
	sf::Color menuWindowBorderColor;	// color del borde del recuadro
	sf::Color optNormal;				// color de las opciones
	sf::Color optSelected;				// color de la opcion seleccionada
	
	// posiciona el recuadro de menu y las opciones
	void RearrangeMenu();
	
	
	public:
	// para crear un menu indicamos la ventana y la funcion que se
	// encargara de hacer las cosas cada vez que se presione una opcion
	Menu(sf::RenderWindow &w, menuCallback cb);
	// permite agregar una opcion
	void AddOption(string option);
	// la funcion show toma el control del programa y llama a la funcion cb
	void Show();
	// es llamada para salir del menu
	void ExitMenu();
	// sale del menu sin restaurar la vista
	void QuitMenu();
};



#endif

