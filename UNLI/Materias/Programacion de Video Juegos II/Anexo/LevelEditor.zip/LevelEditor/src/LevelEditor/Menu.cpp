#include "Menu.h"
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Shape.hpp>
#include <iostream>
using namespace std;


// constructor:
// inicializa variables
Menu::Menu(sf::RenderWindow &w, menuCallback cb){
	this->w=&w;
	this->cb=cb;
	exit=quit=false;
	menuWindowColor=sf::Color(255, 50, 156, 190);
	menuBorder=20;
	optionPadding=5;
	RearrangeMenu();
}

// permite salir del menu
void Menu::ExitMenu(){
	exit=true;
}

// permite salir del menu sin restaurar la vista
void Menu::QuitMenu(){
	quit=true;
}

// agrega una opcion al menu
void Menu::AddOption(string option){
	sf::String *p;
	opciones.push_back(sf::String(option, sf::Font::GetDefaultFont(), 24));
	// debemos poner las coordenadas del sprite en su centro
	p=&opciones[opciones.size()-1];
	p->SetCenter(p->GetRect().GetWidth()/2, 0);
	// cada vez que agregamos una opcion, rearmamos el menu
	RearrangeMenu();
}


// posiciona el recuadro del menu y las opciones
void Menu::RearrangeMenu(){
	if(opciones.empty()) return;
	// calculamos el tamanio del rectangulo
	menuRect.Top=menuRect.Left=0;
	// el alto es: la suma del alto de las opciones + los bordes de arriba y abajo + distancia de padding vertical entre opciones
	menuRect.Bottom=opciones.size()*opciones[0].GetRect().GetHeight()+menuBorder*2+optionPadding*(opciones.size()-1);
	menuRect.Right=0;
	// el ancho del rectangulo es el ancho de la opcion mas ancha...
	for(unsigned i=0; i<opciones.size(); i++){
		if(opciones[i].GetRect().GetWidth()>menuRect.Right){
			menuRect.Right=opciones[i].GetRect().GetWidth();
		}
	}
	// ... mas los bordes a los costados
	menuRect.Right+=menuBorder*2;
	
	// una vez que tenemos el tamanio del rectangulo, lo centramos en la ventana
	menuRect.Offset((w->GetWidth()/2)-menuRect.GetWidth()/2, (w->GetHeight()/2)-menuRect.GetHeight()/2);
	
	// centramos las opciones horizontalmente
	float height=opciones[0].GetRect().GetHeight();
	for(unsigned i=0; i<opciones.size(); i++){
		opciones[i].SetPosition(menuRect.Left+menuRect.GetWidth()/2, menuBorder+menuRect.Top+height*i+optionPadding*i);
	}
}


// muestra el menu y procesa los eventos del mismo
void Menu::Show(){
	// guardamos la vista vieja para despues restaurarla
	const sf::View &oldView=w->GetView();
	// cambiamos la vista a la vista por defecto de la ventana
	w->SetView(w->GetDefaultView());
	sf::Vector2i mouseCoords; // coordenadas del ratos
	const sf::Input &i=w->GetInput();
	
	// como imagen del fondo del menu tomamos la imagen
	// que tenia la ventana antes de entrar al menu
	sf::Image menuBackground;
	menuBackground=w->Capture();
	sf::Sprite background;
	background.SetImage(menuBackground);
	// alteramos el color y modo de blending para que el
	// fondo aparezca mas oscuro
	background.SetColor(sf::Color(255,255,255,100));
	background.SetBlendMode(sf::Blend::Alpha);
	
	int selectedOption;	// la opcion seleccionada
	sf::Event e;
	
	while(!exit){
		// pedimos las coordenadas del raton
		mouseCoords.x=i.GetMouseX();
		mouseCoords.y=i.GetMouseY();
		
		// procesamos los eventos
		while(w->GetEvent(e)){
			if(e.Type == e.Closed){
				::exit(0);
			}
			
			// con escape salimos del menu y volvemos a lo anterior
			if(e.Type == e.KeyPressed){
				if(e.Key.Code==sf::Key::Escape) exit=true;
			}
			
			// si se hace click y hay alguna opcion seleccionada,
			// llamamos a la funcion callback con el texto de esa
			// opcion
			if(e.Type == e.MouseButtonPressed){
				if(selectedOption!=-1){
					cb(*this, opciones[selectedOption].GetText());
					if(quit) return;
				}
			}
		}
		
		// buscamos si el raton esta sobre alguna de las opciones
		selectedOption=-1;
		for(unsigned i=0; i<opciones.size(); i++){
			if(opciones[i].GetRect().Contains(mouseCoords.x, mouseCoords.y)){
				selectedOption=i;
				break;
			}
		}
		
		// limpiamos y dibujamos
		w->Clear(sf::Color(0,0,0));
		w->Draw(background);
		w->Draw(sf::Shape::Rectangle(menuRect.Left,menuRect.Top,menuRect.Right,menuRect.Bottom,menuWindowColor, 2, sf::Color(255,255,255)));
		
		// dibujamos las opciones alterando su color segun esten seleccionadas o no
		for(unsigned i=0; i<opciones.size(); i++){
			if(i==selectedOption){
				opciones[i].SetColor(sf::Color(255,255,0));
			}else{
				opciones[i].SetColor(sf::Color(255,255,255));
			}
			w->Draw(opciones[i]);
		}
		w->Display();
	}
	// antes de irnos, restauramos la vista
	w->SetView(oldView);
}


