#include "Megaman.h"
#include "Disparos.h"
#include <iostream>
using namespace std;

// algunas constantes
float const v0_salto=-256;	// velocidad inicial al comenzar el salto 
float const gravity=512;	// gravedad
float const shoot_time=0.3; // tiempo que dura la secuencia de disparo
float const velmisiles=180; // velocidad de los disparos (pixeles x segundo)
float const vx=60;			// velocidad del movimiento horizontal (constante)


// Constructor: recibimos el nivel para controlar las colisiones y
// un manejardor de disparos para crear los disparos
Megaman::Megaman(ManejadorDisparos *d, Nivel *n) {
	InicializarAnimaciones();
	estado=PARADO;				// setea el estado inicial
	direccion=1;
	SetCenter(im[0].GetWidth()/2.0,im[0].GetHeight()/2.0);	// las coordenadas que utilicemos corresponden al centro del sprite
	vy=0;
	shootTime=shoot_time;
	disparos=d;
	this->n=n;
}


// carga e inicializa las animaciones con sus cuadros y tiempos
void Megaman::InicializarAnimaciones(){
	im.Load("data/megaman_sprites.png", 3, 4);
	animaciones[PARADO].AddFrame(im[0], 1.2);
	animaciones[PARADO].AddFrame(im[1], 0.1);
	animaciones[CORRIENDO].AddFrame(im[3], 0.16);
	animaciones[CORRIENDO].AddFrame(im[4], 0.16);
	animaciones[CORRIENDO].AddFrame(im[5], 0.16);
	animaciones[CORRIENDO].AddFrame(im[4], 0.16);
	animaciones[DISPARANDO].AddFrame(im[8], 0.2);
	animaciones[SALTANDO].AddFrame(im[6], 2);
	animaciones[DISPARANDO_Y_CORRIENDO].AddFrame(im[9], 0.16);
	animaciones[DISPARANDO_Y_CORRIENDO].AddFrame(im[10], 0.16);
	animaciones[DISPARANDO_Y_CORRIENDO].AddFrame(im[11], 0.16);
	animaciones[DISPARANDO_Y_CORRIENDO].AddFrame(im[10], 0.16);
	animaciones[SALTANDO_Y_MOVIENDOSE].AddFrame(im[6], 2);
	animaciones[SALTANDO_Y_DISPARANDO].AddFrame(im[7], 2);
	animaciones[SALTANDO_MOVIENDOSE_Y_DISPARANDO].AddFrame(im[7], 2);
}


// el cambio de estado resetea el estado de la animacion del proximos estado
// pero en el caso de ciertos cambios de estado, por ejemplo CORRIENDO=>DISPARANDO_Y_CORRIENDO
// es necesario que la nueva animacion empieze en donde la anterior termino (las animaciones
// CORRIENDO y DISPARANDO_Y_CORRIENDO son practicamente identicas, para eso utilizamos el
// flag continueFromCurrent, si esta en verdadero ponemos a la nueva animacion en el mismo
// estado que la anterior
void Megaman::CambiarEstado(Estado nuevoEstado, bool continueFromCurrent){
	int viejoEstado=estado;
	estado=nuevoEstado;
	animaciones[nuevoEstado].Reset();
	if(continueFromCurrent){
		// seteamos el frame de la nueva animacion
		animaciones[nuevoEstado].SetCurrentFrameNum(animaciones[viejoEstado].GetCurrentFrameNum());
		// seteamos el tiempo del frame de la nueva animacion al mismo tiempo que tenia la anterior
		animaciones[nuevoEstado].Animate(animaciones[viejoEstado].GetCurrentFrameElapsedTime());
	}
}


// para saber si ya expiro el tiempo que dura la secuencia de disparo
bool Megaman::SecuenciaDisparoFinalizada(){
	return shootTime<0;
}


// al disparar reseteamos el contador shootTime (que es decrementado hasta
// que finaliza la secuencia de disparo) y creamos el proyectil especificando
// la posicion de inicio y su velocidad
void Megaman::Disparar(float x, float y){
	shootTime=shoot_time;
	disparos->AgregarDisparo(x, y, velmisiles*direccion);
}


// la secuencia de salto, seteamos la velocidad inicial vertical
void Megaman::Saltar(){
	vy=v0_salto;
}


#ifndef round
 #define round(r) r-int(r)>=0.5?int(r)+1:int(r)
#endif
// devuelve el Axis-Aligned Bounding Box para megaman
sf::FloatRect Megaman::GetAABB(){
	sf::Vector2f p=GetPosition();
	return sf::FloatRect(round(p.x-10), round(p.y-10), round(p.x+8), round(p.y+16));
}

// para depurar, imprime el estado, pero solo cuando este cambia
void Megaman::PrintState(){
	static string states[]={"PARADO","CORRIENDO","DISPARANDO","SALTANDO","DISPARANDO_Y_CORRIENDO","SALTANDO_Y_DISPARANDO","SALTANDO_Y_MOVIENDOSE","SALTANDO_MOVIENDOSE_Y_DISPARANDO"};
	static int estadoViejo=0;
	// si el estado cambio, imprimimos el nuevo estado actual
	if(estado!=estadoViejo){
		cout<<states[estado]<<endl;
		estadoViejo=estado;
	}
}


// saber si choca con alguna pared por derecha o por izquierda
bool Megaman::ChocaraPared(float dt, float &distAjuste){
	// creamos rectangulos para el bounding box actual
	// y el area de colision
	FloatRect aabb, areaColision;
	
	// conseguimos el bounding box en la posicion actual
	aabb=GetAABB();
	bool chocaPared;
	
	// la distancia que nos moveriamos
	float despl=dt*vx*direccion;
	
	// buscamos el bounding box que tendriamos
	// si nos moviesemos, preguntamos si
	// colisionamos y la distancia
	// que nos podriamos mover sin colisionar (ajuste)
	aabb.Left+=despl;
	aabb.Right+=despl;
	// calculamos si habria colision
	chocaPared=n->HayColision(aabb, areaColision);
	distAjuste=direccion*(dt*vx-areaColision.GetWidth());
	return chocaPared;
}


// saber si choca con el techo
bool Megaman::ChocaraTecho(float dt, float &distAjuste){
	bool chocaConTecho;
	// calculamos la velocidad que tendriamos
	float newvy=vy+gravity*dt;
	// si estamos cayendo, no podemos chocar con
	// el suelo
	if(newvy>0) return false;
	else{
		FloatRect aabb, areaColision;
		
		// la distancia que nos vamos a mover
		float despl=dt*newvy;
		
		// conseguimos el AABB actual y calculamos
		// el que tendriamos en un instante de tiempo
		aabb=GetAABB();
		aabb=aabb;
		aabb.Top+=despl;
		aabb.Bottom+=despl;
		// calculamos si habria colision
		chocaConTecho=n->HayColision(aabb, areaColision);
		distAjuste=despl+areaColision.GetHeight();
	}
	return chocaConTecho;
}


// saber si chocara con el suelo cuando esta cayendo,
// o si hay suelo debajo
bool Megaman::ChocaraSuelo(float dt, float &distAjuste){
	bool chocaConSuelo;
	// calculamos la velocidad que tendriamos
	float newvy=vy+gravity*dt;
	// si estamos subiendo, no podemos chocar con
	// el suelo
	if(newvy<0) return false;
	else{
		FloatRect aabb, areaColision;
		aabb=GetAABB();
		// la distancia que nos vamos a mover
		float despl=dt*newvy;
		
		// conseguimos el AABB actual y calculamos
		// el que tendriamos en un instante de tiempo
		aabb.Top+=despl;
		aabb.Bottom+=despl;
		// calculamos si habria colision
		chocaConSuelo=n->HayColision(aabb, areaColision);
		distAjuste=despl-areaColision.GetHeight();
	}
	return chocaConSuelo;	
}


// Esta es la funcion mas importante, realiza los cambios de estado, movimientos
// y animacion del personaje
void Megaman::Mover_y_Animar(Joystick j, float dt){
	// EL SWITCH GRANDE...
	// para cada estado, preguntamos si ocurrio alguno de los eventos que hacen
	// que se pase a otro estado
	
	// la distancia devuelta por ChocaraPared(), ChocaraSuelo(), etc
	float distAjuste;
	
	switch(estado){
	case PARADO:
		if(j.left){
			direccion=-1;
			// si podemos correr, lo hacemos
			if(!ChocaraPared(dt, distAjuste))
				CambiarEstado(CORRIENDO);
			else
				// si no hay lugar para correr, nos ajustamos a la pared,
				// pero no cambiamos el estado
				Move(distAjuste, 0);
		}else if(j.right){
			// lo mismo si es hacia la derecha
			direccion=1;
			if(!ChocaraPared(dt, distAjuste))
				CambiarEstado(CORRIENDO);
			else
				Move(distAjuste, 0);
		}
		
		// si saltamos o disparamos
		if(j.a && SecuenciaDisparoFinalizada()){
			CambiarEstado(DISPARANDO);
			// la posicion del disparo esta calculada a ojo...
			Disparar(GetPosition().x+8*direccion, GetPosition().y);
		}
		
		// si no hay suelo debajo, empezamos a caer
		if(!ChocaraSuelo(dt, distAjuste)){
			CambiarEstado(SALTANDO);
			vy=0;
		}
		
		// si saltamos
		if(j.b){
			CambiarEstado(SALTANDO);
			Saltar(); // comienza el saltos
		}
		break;
		
	case CORRIENDO:
		// si disparamos
		if(j.a && SecuenciaDisparoFinalizada()){
			CambiarEstado(DISPARANDO_Y_CORRIENDO, true);
			Disparar(GetPosition().x+8*direccion, GetPosition().y);
		}
		
		if(!j.left && !j.right){
			CambiarEstado(PARADO);
		}else if(j.left){
			direccion=-1;
			// si chocamos con la pared...
			if(ChocaraPared(dt, distAjuste)){
				CambiarEstado(PARADO);
				// ajustamos a la pared
				Move(-distAjuste, 0);
			}
			// lo mismo para la derecha
		}else if(j.right){
			direccion=1;
			if(ChocaraPared(dt, distAjuste)){
				CambiarEstado(PARADO);
				Move(distAjuste, 0);
			}
		}
		
		// si no hay suelo debajo, empezamos a caer
		if(!ChocaraSuelo(dt, distAjuste)){
			CambiarEstado(SALTANDO_Y_MOVIENDOSE);
			vy=0;
		}
		
		// si saltamos
		if(j.b){
			CambiarEstado(SALTANDO_Y_MOVIENDOSE);
			Saltar(); // comienza el salto
		}
		break;
		
	case SALTANDO:
		if(j.left){
			direccion=-1;
			// si no chocamos la pared, empezamos a movernos
			if(!ChocaraPared(dt, distAjuste)){
				CambiarEstado(SALTANDO_Y_MOVIENDOSE);	
			}else{
				// si no, ajustamos a la pared sin cambiar el estado
				Move(distAjuste, 0);
			}
			// lo mismo para la derecha
		}else if(j.right){
			direccion=1;
			if(!ChocaraPared(dt, distAjuste)){
				CambiarEstado(SALTANDO_Y_MOVIENDOSE);
			}else{
				Move(distAjuste, 0);
			}
		}
		
		// si disparamos
		if(j.a && SecuenciaDisparoFinalizada()){
			CambiarEstado(SALTANDO_Y_DISPARANDO);
			Disparar(GetPosition().x+8*direccion, GetPosition().y-5);
		}
		
		// si tocamos el suelo, cambiamos el estado y ademas
		// debemos ajustar nuestra posicion al piso para que nuestro
		// personaje no quede penetrando el tile
		if(ChocaraSuelo(dt, distAjuste)){
			CambiarEstado(PARADO);
			Move(0, distAjuste);
			vy=0;
		}else if(ChocaraTecho(dt, distAjuste)){
			// lo mismo si chocamos con el techo
			Move(0, distAjuste);
			vy=0;
		}
		break;
		
		
	case DISPARANDO:
		if(j.left){
			// si podemos mover a la izquierda empezamos a movernos,
			// sino, ajustamos sin cambiar el estado
			direccion=-1;
			if(!ChocaraPared(dt, distAjuste))
				CambiarEstado(DISPARANDO_Y_CORRIENDO, true);
			else
				Move(distAjuste, 0);
		}else if(j.right){
			// lo mismo para la derecha
			direccion=1;
			if(!ChocaraPared(dt, distAjuste))
				CambiarEstado(DISPARANDO_Y_CORRIENDO, true);
			else
				Move(distAjuste, 0);
		}
		
		// si terminamos de disparar
		if(SecuenciaDisparoFinalizada()){ // finaliza la secuencia de disparo
			CambiarEstado(PARADO);
		}
		
		// si apretamos saltar
		if(j.b){
			CambiarEstado(SALTANDO);
			Saltar(); // comienza el salto
		}
		break;
		
		
	case DISPARANDO_Y_CORRIENDO:
		// si no se apreta der ni izq, dejamos de correr
		if(!j.left && !j.right){
			CambiarEstado(DISPARANDO);
		}else if(j.left){
			// si queremos mover a la izq y chocamos con la pared,
			// ajustamos y cambiamos el estado
			direccion=-1;
			if(ChocaraPared(dt, distAjuste)){
				Move(distAjuste, 0);
				CambiarEstado(DISPARANDO);
			}
		}else if(j.right){
			// lo mismo para la derecha
			direccion=1;
			if(ChocaraPared(dt, distAjuste)){
				Move(distAjuste, 0);
				CambiarEstado(DISPARANDO);
			}
		}
		
		// saltamos
		if(j.b){
			CambiarEstado(SALTANDO_MOVIENDOSE_Y_DISPARANDO);
			Saltar(); // comienza el salto
		}
		
		// si no hay suelo, empezamos a caer
		if(!ChocaraSuelo(dt, distAjuste)){
			CambiarEstado(SALTANDO_Y_DISPARANDO);
			vy=0;
		}
		
		// si terminamos de disparar
		if(SecuenciaDisparoFinalizada()){
			CambiarEstado(CORRIENDO, true);
		}
		break;
		
		
	case SALTANDO_Y_DISPARANDO:
		// si terminamos de disparar
		if(SecuenciaDisparoFinalizada()){
			CambiarEstado(SALTANDO);
		}
		
		if(j.left){
			// si podemos mover a la izquierda, lo hacemos
			// sino, ajustamos a la pared sin cambiar el estado
			direccion=-1;
			if(!ChocaraPared(dt, distAjuste))
				CambiarEstado(SALTANDO_Y_MOVIENDOSE);
			else
				Move(distAjuste, 0);
		}else if(j.right){
			// lo mismo para la derecha
			direccion=1;
			if(!ChocaraPared(dt, distAjuste))
				CambiarEstado(SALTANDO_Y_MOVIENDOSE);
			else
				Move(distAjuste, 0);
		}
		
		// si colisiona con techo o suelo
		if(ChocaraSuelo(dt, distAjuste)){
			Move(0, distAjuste);
			CambiarEstado(DISPARANDO);
		}else if(ChocaraTecho(dt, distAjuste)){
			Move(0, distAjuste);
			vy=0;
		}
		
		break;
		
	case SALTANDO_Y_MOVIENDOSE:
		// si disparamos
		if(j.a && SecuenciaDisparoFinalizada()){
			CambiarEstado(SALTANDO_MOVIENDOSE_Y_DISPARANDO);
			Disparar(GetPosition().x+8*direccion, GetPosition().y-5);
		}
		
		// si no apretamos der o izq, que deje de moverse
		if(!j.left && !j.right){
			CambiarEstado(SALTANDO);
		}else if(j.left){
			// si chocamos con una pared, ajustamos y cambiamos
			// el estado
			direccion=-1;
			if(ChocaraPared(dt, distAjuste)){
				Move(distAjuste, 0);
				CambiarEstado(SALTANDO);
			}
		}else if(j.right){
			direccion=1;
			if(ChocaraPared(dt, distAjuste)){
				Move(distAjuste, 0);
				CambiarEstado(SALTANDO);
			}
		}
		
		// si colisiona con techo o suelo
		if(ChocaraSuelo(dt, distAjuste)){
			vy=0;
			Move(0, distAjuste);
			CambiarEstado(CORRIENDO);
		}else if(ChocaraTecho(dt, distAjuste)){
			Move(0, distAjuste);
			vy=0;
		}
		break;
		
	case SALTANDO_MOVIENDOSE_Y_DISPARANDO:
		// si terminamos de disparar
		if(SecuenciaDisparoFinalizada()){
			CambiarEstado(SALTANDO_Y_MOVIENDOSE);
		}
		
		// si no apretamos der o izq, que deje de moverse
		if(!j.left && !j.right){
			CambiarEstado(SALTANDO_Y_DISPARANDO);
		}else if(j.left){
			// si chocamos con una pared, ajustamos y cambiamos
			// el estado
			direccion=-1;
			if(ChocaraPared(dt, distAjuste)){
				Move(distAjuste, 0);
				CambiarEstado(SALTANDO_Y_DISPARANDO);
			}
		}else if(j.right){
			direccion=1;
			if(ChocaraPared(dt, distAjuste)){
				Move(distAjuste, 0);
				CambiarEstado(SALTANDO_Y_DISPARANDO);
			}
		}
		
		// si chocamos con el suelo o el techo
		if(ChocaraSuelo(dt, distAjuste)){
			vy=0;
			CambiarEstado(DISPARANDO_Y_CORRIENDO);
			Move(0, distAjuste);
		}else if(ChocaraTecho(dt, distAjuste)){
			Move(0, distAjuste);
			vy=0;
		}
		break;
	}
	
	// segun el estado, movemos horizontalmente
	if(estado==CORRIENDO || estado==SALTANDO_Y_MOVIENDOSE || estado==DISPARANDO_Y_CORRIENDO || estado==SALTANDO_MOVIENDOSE_Y_DISPARANDO){
		Move(direccion*vx*dt, 0);
	}
	
	// segun el estado, movemos verticalmente
	if(estado==SALTANDO || estado==SALTANDO_Y_MOVIENDOSE || estado==SALTANDO_Y_DISPARANDO || estado==SALTANDO_MOVIENDOSE_Y_DISPARANDO){
		vy+=gravity*dt;
		Move(0, vy*dt);
	}
	
	// segun la direccion le avisamos si debe dibujar el sprite invertido
	FlipX(direccion<0);
	
	// decrementamos tiempo a la secuencia de disparo
	if(!SecuenciaDisparoFinalizada()) shootTime-=dt;
	
	// animamos y ponemos la imagen al sprite
	SetImage(animaciones[estado].Animate(dt));
	
	// para depurar muestra un mensaje cuando cambia el estado
//	PrintState();
}
