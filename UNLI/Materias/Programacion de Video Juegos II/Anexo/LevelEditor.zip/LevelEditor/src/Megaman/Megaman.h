#ifndef MEGAMAN_H
#define MEGAMAN_H

#include "Megaman.h"
#include "Animation.h"
#include "SpriteSheetManager.h"
#include "Disparos.h"
#include "Nivel.h"

// una estructura simple para pasarle los controles a megaman
struct Joystick{
	bool up, down, left, right, a, b;
};

class Megaman: public Sprite{
	private:
	enum Estado{
		PARADO,
		CORRIENDO,
		DISPARANDO,
		SALTANDO,
		DISPARANDO_Y_CORRIENDO,
		SALTANDO_Y_DISPARANDO,
		SALTANDO_Y_MOVIENDOSE,
		SALTANDO_MOVIENDOSE_Y_DISPARANDO
	};
	Estado estado;				// el estado actual
	int direccion;				// si apunta a la der o izq (flip horizontal de la textura)
	Animation animaciones[8];	// animaciones para cada estado
	SpriteSheetManager im;		// nuestro manejador de la spritesheet
	ManejadorDisparos *disparos;// clase que se encargara de mover/dibujar los disparos
	
	float vy;					// velocidad actual en y (salto y caida)
	float shootTime;			// tiempo que transcurrio desde el ultimo disparo
	
	Nivel *n;					// el nivel, para detectar colisiones con paredes, suelo, etc
	
	// inicializa las animaciones, es llamado en el constructor
	void InicializarAnimaciones();
	
	// cambia el estado y hace algunas operaciones necesarias
	void CambiarEstado(Estado nuevoEstado, bool continueFromCurrent=false);
	
	// algunas acciones
	void Disparar(float x, float y);
	void Saltar();
	
	// funciones que determinan eventos de entrada
	bool SecuenciaDisparoFinalizada();
	
	// para saber si al moverse chocara con alguna pared, suelo o el techo	
	bool ChocaraPared(float dt, float &distAjuste);
	bool ChocaraTecho(float dt, float &distAjuste);
	bool ChocaraSuelo(float dt, float &distAjuste);
	
	// para fines de depuracion, imprime es estado actual cuando cambia
	void PrintState();
	
	public:
	// constructor
	Megaman(ManejadorDisparos *d, Nivel *n);
	
	// realiza el movimiento, detecta colisiones y anima
	void Mover_y_Animar(Joystick j, float dt);
	
	// devuelve el bounding box de Megaman
	sf::FloatRect GetAABB();
};

#endif

