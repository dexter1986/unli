#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <iostream>
using namespace std;

int CorrerServidor();
int CorrerCliente();


/**
* punto de entrada del programa
*/
int main(int argc, char *argv[]) {
	cout<<"Desea correr un cliente o un servidor? [c/S]: ";
	char input;
	cin.get(input);
	if(input=='c' || input=='C'){
		cin.ignore();
		return CorrerCliente();
	}
	else return CorrerServidor();
}


/**
* Funcion main() del Servidor
*/
int CorrerServidor() {
	cout<<"Ejemplo de programacion con sockets UDP en SFML (Servidor)"<<endl;
	
	// sockets para el servidor y cliente
	sf::SocketUDP clientSocket;
	short unsigned port=1712;
	
	// asocia el socket al puerto
	clientSocket.Bind(port);
	
	// recibe un mensaje desde el ciente
	char buffer[128];
	std::size_t Received;
	sf::IPAddress a("127.0.0.1");
	if(clientSocket.Receive((char *)buffer, sizeof(buffer), Received, a, port)!=sf::Socket::Done){
		cout<<"ERROR: fallo recepcion del mensaje"<<endl;
	}
	
	// muestra el mensaje
	cout<<"Mensaje recibido: "<<buffer<<endl;
	
	// cerramos las conexiones
	clientSocket.Close();
	
	cout<<"Presione una tecla para continuar..."<<endl;
	cin.get();
	return 0;
}


/**
* Funcion main() del Cliente
*/
int CorrerCliente() {
	cout<<"Ejemplo de programacion con sockets UDP en SFML (cliente)"<<endl;
	
	sf::SocketUDP serverSocket;
	const unsigned port=1712;
	
	// lee un mensaje desde consola
	string mensaje;
	cout<<"Ingrese el mensaje que desea enviar: ";
	getline(cin,mensaje);
	
	// y envia el mensaje al servidor
	if(serverSocket.Send(mensaje.c_str(), mensaje.size()+1, "127.0.0.1", port) != sf::Socket::Done){
		cout<<"ERROR: fallo el envio del mensaje"<<endl;
	}else{
		cout<<"Mensaje enviado con exito."<<endl;
	}
	
	// finaliza la conexion
	serverSocket.Close();
	
	cout<<"Presione una tecla para continuar..."<<endl;
	cin.get();
	return 0;
}

