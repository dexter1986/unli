#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <iostream>
using namespace std;

int CorrerServidor();
int CorrerCliente();


/**
* punto de entrada del programa
*/
int main(int argc, char *argv[]) {
	cout<<"Desea correr un cliente o un servidor? [c/S]: ";
	char input;
	cin.get(input);
	if(input=='c' || input=='C'){
		cin.ignore();
		return CorrerCliente();
	}
	else return CorrerServidor();
}


/**
 * Funcion main() del Servidor
 */
int CorrerServidor() {
	cout<<"Ejemplo de programacion con sockets TCP en SFML (Servidor)"<<endl;
	
	// sockets para el servidor y cliente
	sf::SocketTCP serverSocket, clientSocket;
	const unsigned port=1712;
	
	// pone al socket del servidor a escuchar
	// por conexiones entrantes en el puerto 1712
	serverSocket.Listen(port);
	
	// acepta la conexion utilizando el socket clientSocket para
	// referirse al otro equipo (al cliente)
	serverSocket.Accept(clientSocket);
	
	// envia un mensaje al cliente
	string saludo="Hola. Soy el servidor.";
	if (clientSocket.Send(saludo.c_str(), saludo.size()+1)!= sf::Socket::Done){
		cout<<"ERROR: fallo el envio del mensaje"<<endl;
	}
	
	// recibe un mensaje desde el ciente
	char buffer[128];
	std::size_t Received;
	if(clientSocket.Receive(buffer, sizeof(buffer), Received)!=sf::Socket::Done){
		cout<<"ERROR: fallo recepcion del mensaje"<<endl;
	}
	
	// muestra el mensaje
	cout<<"Mensaje recibido: "<<buffer<<endl;
	
	// cerramos las conexiones
	clientSocket.Close();
	serverSocket.Close();

	cout<<"Presione una tecla para continuar..."<<endl;
	cin.get();
	return 0;
}


/**
 * Funcion main() del cliente
 */
int CorrerCliente() {
	cout<<"Ejemplo de programacion con sockets TCP en SFML (cliente)"<<endl;
	
	sf::SocketTCP serverSocket;
	const unsigned port=1712;
	
	
	// intenta conectarse a 127.0.0.1 en el puerto 1712
	if(serverSocket.Connect(port, "127.0.0.1") != sf::Socket::Done){
		cout<<"ERROR: no pudo establecerse la conexion"<<endl;
		return -1;
	}
	
	// una vez conectado, podemos recibir datos desde el servidor
	// mediante serverSocket
	char buffer[128];
	size_t Received;
	if(serverSocket.Receive(buffer, sizeof(buffer), Received) != sf::Socket::Done){
		cout<<"ERROR: no pudieron recibirse los datos"<<endl;
	}
	
	// muestra el mensaje del servidor 
	cout<<buffer<<endl;
	
	// lee un mensaje desde consola
	string mensaje;
	cout<<"Ingrese el mensaje que desea enviar: ";
	getline(cin,mensaje);
	
	// y envia el mensaje al servidor
	if(serverSocket.Send(mensaje.c_str(), mensaje.size()+1) != sf::Socket::Done){
		cout<<"ERROR: fallo el envio del mensaje"<<endl;
	}else{
		cout<<"Mensaje enviado con exito."<<endl;
	}
	
	// finaliza la conexion
	serverSocket.Close();

	cout<<"Presione una tecla para continuar..."<<endl;
	cin.get();
	return 0;
}


