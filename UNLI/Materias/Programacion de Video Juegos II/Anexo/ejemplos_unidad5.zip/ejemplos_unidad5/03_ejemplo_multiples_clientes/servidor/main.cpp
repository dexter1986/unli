#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
using namespace std;

// estructura para los datos del cliente
// (datos sprites + id)
struct Cliente: public sf::Sprite{
	unsigned clientId;
};


// sobrecarga del operador << para agregar
// clientes a un paquete
sf::Packet &operator<<(sf::Packet &p, Cliente &c){
	sf::Vector2f pos=c.GetPosition();
	sf::Uint16 x=pos.x, y=pos.y;
	p<<x<<y;
	sf::Color color=c.GetColor();
	sf::Uint8 r=color.r, g=color.g, b=color.b;
	p<<r<<g<<b;
	sf::Uint8 id=c.clientId;
	p<<id;
	return p;
}


// sobrecarga del operador >> para extraer
// clientes de un paquete
sf::Packet &operator>>(sf::Packet &p, Cliente &c){
	sf::Uint16 x, y;
	p>>x>>y;
	c.SetPosition(x, y);
	sf::Uint8 r, g, b;
	p>>r>>g>>b;
	c.SetColor(sf::Color(r,g,b));
	sf::Uint8 var;
	p>>var;
	c.clientId=var;
	return p;
}

vector<Cliente> clientes;				// los clientes
vector<sf::SocketTCP> socketsClientes;	// sockets de los clientes

int main(int argc, char *argv[]) {
	sf::SelectorTCP selector;
	sf::SocketTCP listener;
	if(!listener.Listen(1712)){
		cout<<"ERROR: no se pudo inicializar socket"<<endl;
		return -1;
	}else{
		cout<<"Servidor escuchando en puerto 1712..."<<endl;
	}
	
	// agregarmos al selector el socket que acepta las conexiones
	selector.Add(listener);
	
	unsigned nSocketsReady, i, nClientes;
	// si debe armarse el paquete con la info de todos los clientes
	bool debeActualizar;
	
	sf::SocketTCP s;
	while(true){
		debeActualizar=false;
		
		// pregunta si hay sockets listos para leer
		nSocketsReady=selector.Wait(0.0001);
		// recorre los sockets listos para leer 
		for(i=0; i<nSocketsReady; i++){
			s=selector.GetSocketReady(i);
			// si el socket listo es el listener, entonces
			// tenemos una solicitud de un cliente nuevo
			if(s==listener){
				// aceptamos al nuevo cliente en un nuevo socket
				// enviandole los datos de un cliente solamente
				// con su numero de id
				sf::SocketTCP t;
				s.Accept(t);
				Cliente c;
				c.clientId=clientes.size();
				sf::Packet enviar;
				enviar<<c;
				t.Send(enviar);

				clientes.push_back(c);
				socketsClientes.push_back(t);
				selector.Add(t);
				cout<<"Ciente conectado. Id: "<<c.clientId<<endl;
			}else{
				// si recibimos datos de un cliente, actualizamos
				Cliente c;
				sf::Packet recibir;
				if(s.Receive(recibir)!=sf::Socket::Done){
					cout<<"Cliente desconectado.";
					selector.Remove(s);
				}else{
					recibir>>c;
					clientes[c.clientId]=c;
					debeActualizar=true;
				}
			}
		}
		
		// arma un paquete con el estado de todos los clientes
		if(debeActualizar){
			sf::Packet estado;
			nClientes=socketsClientes.size();
			for(unsigned j=0; j<nClientes; j++){
				estado<<clientes[j];
			}
			
			// envia el paquete a cada cliente
			unsigned nSocketsClientes=socketsClientes.size();
			vector<sf::SocketTCP>::iterator p=socketsClientes.begin();
			while(p!=socketsClientes.end()){
				if(p->Send(estado)!=sf::Socket::Done){
					// si el envio fallo, el socket ya no es valido
					p=socketsClientes.erase(p);
					cout<<"Cliente desconectado.";
				}else p++;
			}
		}
	}
	
	selector.Clear();
	
	return 0;
}

