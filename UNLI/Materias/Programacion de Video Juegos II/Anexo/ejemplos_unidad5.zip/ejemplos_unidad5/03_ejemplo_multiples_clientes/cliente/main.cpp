#include <iostream>
#include <vector>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Network.hpp>
#include <SFML/Graphics.hpp>
#include <cstdio>
using namespace std;

// estructura para los datos del cliente
// (datos sprites + id)
struct Cliente: public sf::Sprite{
	unsigned clientId;
};


// sobrecarga del operador << para agregar
// clientes a un paquete
sf::Packet &operator<<(sf::Packet &p, Cliente &c){
	sf::Vector2f pos=c.GetPosition();
	sf::Uint16 x=pos.x, y=pos.y;
	p<<x<<y;
	sf::Color color=c.GetColor();
	sf::Uint8 r=color.r, g=color.g, b=color.b;
	p<<r<<g<<b;
	sf::Uint8 id=c.clientId;
	p<<id;
	return p;
}


// sobrecarga del operador >> para extraer
// clientes de un paquete
sf::Packet &operator>>(sf::Packet &p, Cliente &c){
	sf::Uint16 x, y;
	p>>x>>y;
	c.SetPosition(x, y);
	sf::Uint8 r, g, b;
	p>>r>>g>>b;
	c.SetColor(sf::Color(r,g,b));
	sf::Uint8 var;
	p>>var;
	c.clientId=var;
	return p;
}

Cliente miBicho;			// mi sprite 
vector<Cliente> clientes;	// los demas clientes




int main(int argc, char *argv[]) {
	// resolucion de la ventana
	unsigned const resx=500, resy=300;
	
	// cargamos la imagen que usaremos para los sprites
	sf::Image i;
	i.LoadFromFile("../space_inv.png");

	// inicializamos el cliente
	miBicho.SetPosition(rand()%resx+1,rand()%resy+1);
	miBicho.SetColor(sf::Color(rand()%256,rand()%256,rand()%256));
	
	// intentamos conectar al servidor
	sf::SocketTCP socket;
	if(socket.Connect(1712, "127.0.0.1")!=sf::Socket::Done){
		cout<<"ERROR: no se pudo conectar con el servidor"<<endl;
		cout<<"Presione una tecla para continuar..."<<endl;
		cin.get();
		return -1;
	}
	
	// una vez establecida la conexion, recibimos los datos
	// de un cliente para saber cual es nuestro id
	sf::Packet paquete;
	Cliente temp;
	if(socket.Receive(paquete)!=sf::Socket::Done){
		cout<<"Error al recibir id."<<endl;
		cin.get();
		return -1;
	}
	paquete>>temp;
	miBicho.clientId=temp.clientId;
	
	// creamos la ventana y le ponemos nuestro id como titulo
	char titulo[128];
	sprintf(titulo, "Cliente Id: %i", miBicho.clientId); 
	sf::RenderWindow w(sf::VideoMode(resx,resy),titulo);
	
	// creamos un selector para usar el socket para comunicarnos
	// con el servidor de forma asincrona
	sf::SelectorTCP selector;
	selector.Add(socket);
	
	// le enviamos al servidor nuestro color y posicion
	paquete.Clear();
	paquete<<miBicho;
	socket.Send(paquete);
	
	
	bool draggingBicho=false;	// si estamos arrastrando el sprite
	const sf::Input &input=w.GetInput();
	unsigned mouse_x, mouse_y, mouse_x_anterior, mouse_y_anterior, nSocketsReady;
	sf::Event e;
	
	while(w.IsOpened()) {
		mouse_x=input.GetMouseX();
		mouse_y=input.GetMouseY();
		
		while(w.GetEvent(e)) {
			if(e.Type == e.Closed)
				w.Close();
			
			// si presionamos el boton del raton en la region del sprite, activamos el dragging
			if(e.Type == e.MouseButtonPressed){
				sf::Vector2f pos=miBicho.GetPosition();
				if(fabs(pos.x-mouse_x)<i.GetWidth()/2 && fabs(pos.y-mouse_y)<i.GetHeight()/2){
					draggingBicho=true;
				}
			}
			
			if(e.Type == e.MouseButtonReleased){
				draggingBicho=false;
			}
		}
		
		// si estamos arrastrando
		if(draggingBicho){
			// movemos el bicho
			if(mouse_x!=mouse_x_anterior && mouse_y!=mouse_y_anterior){
				miBicho.SetPosition(mouse_x, mouse_y);
				// enviamos la nueva posicion al servidor
				mouse_x_anterior=mouse_x;
				mouse_y_anterior=mouse_y;
				paquete.Clear();
				paquete<<miBicho;
				socket.Send(paquete);
			}
		}
		
		// revisamos si el socket esta listo para recibir informacion
		nSocketsReady=selector.Wait(0.0001);
		// recibimos datos del servidor
		if(nSocketsReady>0){
			clientes.clear();
			paquete.Clear();
			Cliente temp;
			if(selector.GetSocketReady(0).Receive(paquete)!=sf::Socket::Done){
				return -1;
			}
			// una vez recibidos los datos, actualizamos la
			// informacion de los clientes
			while(paquete>>temp){
				temp.SetImage(i);
				temp.SetCenter(i.GetWidth()/2,i.GetHeight()/2);
				clientes.push_back(temp);
			}
		}
		
		// dibujamos nuestro sprite y luego el de todos los clientes
		w.Clear(sf::Color(0,0,0,255));
		w.Draw(miBicho);
		for(unsigned i=0; i<clientes.size(); i++){
			w.Draw(clientes[i]);
		}
		
		w.Display();
	}

	return 0;
}

