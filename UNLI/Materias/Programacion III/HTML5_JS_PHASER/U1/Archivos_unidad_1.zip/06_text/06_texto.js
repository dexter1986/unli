/* Estructura basica */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.CANVAS, '', { create: create });



    function create() {


        // texto
        var text = "- phaser -\n probando texto \n 3er renglon.";

        // estilo de fuente
        var style = { font: "65px Arial", fill: "#ff0044", align: "center" };


    // agrego texto: X, Y, Text, estilo
        var t = game.add.text(game.world.centerX-300, 0, text, style);



    }




};




