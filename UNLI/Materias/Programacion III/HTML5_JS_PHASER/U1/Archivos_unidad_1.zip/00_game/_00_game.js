/* Estructura basica */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });

    // DONDE
    //docuemtancion de Game
    //file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Game.html

    //Game es la funcion principal que crea el juego
    //parametros
    //new Game(width, height, renderer, parent, state, transparent, antialias, physicsConfig)

    //render: Phaser.AUTO autodetecta, Phaser.WEBGL, Phaser.CANVAS, Phaser.HEADLESS (todavia no se que hace este utlimo)
    //parent: el ID del elemento HTML padre
    //state: Objeto, recibe como parametro las 4 funciones de estado elementales:

    //preload: pasa antes de cargar
    // create: condicion inicial
    // update: se actualiza en cada ciclo
    // render: lo que queres que se dibuje

    function preload () {

        // primitiva para cargar assets (audio, image, etc)

        game.load.image('logo', '../../imagenes/phaser.png');

    }

    function create () {

        // lo agrego al game (seguro que mas adelante van a parecer al escena y los actores)
        //paramentros x,y,imagen

        var logo = game.add.sprite(game.world.centerX, game.world.centerY, 'logo');

        //lo anclo al centro
        logo.anchor.setTo(0.5, 0.5);

    }

};