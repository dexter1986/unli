/* Estructura basica */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });



    function preload() {


        // fijate que carga: nombre del asset, la URL, un archivo json con el mapa de frames del sprite.


        game.load.atlasJSONHash('bot', '../../assets/sprites/running_bot.png', '../../assets/sprites/running_bot.json');


        /*sobre el mapa JSON

         "filename": "run00", //nombre del frame
         "frame": {"x":34,"y":128,"w":56,"h":60}, //ubicacion en el frame, ancho y alto
         "rotated": false, //si esta rotado... [?]
         "trimmed": true, // si esta cortado o tiene algun borde. Ej de trimed: http://www.html5gamedevs.com/uploads/monthly_02_2014/post-6968-0-24708800-1392789579.png
         ejemplo de no trimed: http://www.html5gamedevs.com/uploads/monthly_02_2014/post-6968-0-70063700-1392789580.png
         "spriteSourceSize": {"x":0,"y":2,"w":56,"h":60}, //estas dos cosas no las entendi, son como un offset
         "sourceSize": {"w":56,"h":64}

        */
    }



    function create() {



        //  agrego el sprite y creo el objeto bot (sprite)

        var bot = game.add.sprite(200, 200, 'bot');



        //  Ahora se agrega el esprite llamado "run" no se especifica ningun frame porque usa todos los que estan en la imagen
        // pero aqui se podria especificar puntualmente cada movimiento

        bot.animations.add('run');




        // comienzo, par: animacion, fps, ciclico

        bot.animations.play('run', 15, true);



    }



};




