/* Estructura basica */

window.onload = function() {


    // usamos los 4 estados!

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update, render: render });


    //preload

    function preload() {


        game.load.image('phaser', '../../assets/sprites/phaser.png');


    }



    var sprite;

    function create() {

        //habilito la fisica al mundo, segun entendi, la fisica ARCADE esta habilitada por defecto

        //(o sea que particularmente para para esta configuracion esta linea se puede comentar)
        game.physics.startSystem(Phaser.Physics.ARCADE);



        sprite = game.add.sprite(game.world.centerX, game.world.centerY, 'phaser');

        sprite.anchor.set(0.5);

        //le habilito el cuerpo fisico
        game.physics.arcade.enable(sprite);



    }



        // en cada ciclo
    function update () {



        //  si el sprite esta a mas de 8 px del puntero, lo muevo en esa direccion

        // hay 3 formas de medir distancia
        //distanceBetween: distancia entre 2 objetos
        //distanceToPointer: distancia entre un objeto y un objeto pointer (el objeto pointer es la entrada de eventos)
        //distanceToXY: distancia a una coordenada especifica

        if (game.physics.arcade.distanceToPointer(sprite, game.input.activePointer) > 8)

        {

            //moveToPointer(displayObject, speed, pointer, maxTime)
            //  Si no esta definido el pointer usa el Phaser.Input.activePointer
            //maxTime (ms): ajusta la velocidad para coincidir con el tiempo q pongas aca



            //game.physics.arcade.moveToPointer(sprite, 300)

            game.physics.arcade.moveToPointer(sprite, 300,game.input.activePointer,2000);

        }

        else

        {

          //si esta sobre le mouse, la dejo quieta

            sprite.body.velocity.set(0);

        }



    }


//dibujo el debug
    function render () {

        game.debug.inputInfo(32, 32);



    }


};