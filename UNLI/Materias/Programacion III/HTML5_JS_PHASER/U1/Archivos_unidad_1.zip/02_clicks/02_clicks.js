/* Estructura basica */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });

    function preload() {

        //cargamos imagen
        game.load.image('einstein', '../../assets/pics/ra_einstein.png');
    }

    function create() {

        //ponemos la imagen en el 0,0

        var image = game.add.sprite(0, 0, 'einstein');

        //habilitamos las imputs (o sea, los eventos) para la imagen
        image.inputEnabled=true;

        //y agregamos los eventos
        // no te preocupes, mas adelante se ven mas eventos, algunos eventos para sprites son:

        /**
         *
         onAddedToGroup
         .onRemovedFromGroup
         .onKilled
         .onRevived
         .onOutOfBounds
         .onEnterBounds

         .onInputOver
         .onInputOut
         .onInputDown
         .onInputUp
         .onDragStart
         .onDragStop

         .onAnimationStart
         .onAnimationComplete
         .onAnimationLoop

         **/

        // aparentemente el Input es el click o el touch
        //le agregamos una funcion al evento
        //parametros, funcion, objeto


        // mouse abajo
        image.events.onInputDown.add(CuandoHagoClick,this);
        // mouse sobre la imagen
        image.events.onInputOver.add(CuandoOver,this);

    }

    function CuandoHagoClick () {
        alert('mouse abajo');
    }

    function CuandoOver () {
        alert('mouse sobre');
    }

};