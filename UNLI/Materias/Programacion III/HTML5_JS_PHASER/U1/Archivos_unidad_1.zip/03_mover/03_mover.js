/* Estructura basica */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });

    function preload() {


        game.load.image('einstein', '../../assets/pics/ra_einstein.png');
    }

    function create() {




        var image = game.add.sprite(0, 0, 'einstein');

        // para mover un objeto tengo que definirle una fisica
        //creo un cuerpo fisico
        //parametros: objeto, configuracion de la fisica, booleano para ver el debug
        // existen 3 tipos de configuraciones (fijate en la documentacion)
        // ARCADE, NINJA, P2. Todas tienen diferente configuraciones de velocidad, colisiones, etc
        //Mas adelante vamos a ver mas de esto


        game.physics.enable(image, Phaser.Physics.ARCADE);


        image.body.velocity.x=50;

    }

};