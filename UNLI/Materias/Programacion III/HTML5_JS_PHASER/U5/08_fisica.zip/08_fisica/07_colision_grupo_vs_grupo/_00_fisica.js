/* Estructura basica */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });
    var Brojas;
    var Bamarillas;
    var Bazules;


    function preload () {

        // primitiva para cargar assets (audio, image, etc)
        game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');
        game.load.image('ball_2', '../../assets/sprites/red_ball.png');


    }

    function create () {



        //habilitamos la fisica en el game
        game.physics.startSystem(Phaser.Physics.ARCADE);
        //fijamos una graveda
        game.physics.arcade.gravity.y = 100;
        //decimos que objetos van a respetar la fisica




        Bamarillas = game.add.group();
        Bamarillas.enableBody = true;
        Bamarillas.physicsBodyType = Phaser.Physics.ARCADE;

        Bazules = game.add.group();
        Bazules.enableBody = true;
        Bazules.physicsBodyType = Phaser.Physics.ARCADE;

        Brojas = game.add.group();
        Brojas.enableBody = true;
        Brojas.physicsBodyType = Phaser.Physics.ARCADE;

        game.time.events.repeat(100, 50, creaBolaAmarilla, this);
        game.time.events.repeat(100, 50, creaBolaAzul, this);


        game.physics.enable( [Bamarillas,Bazules,Brojas], Phaser.Physics.ARCADE);



    }

    function creaBolaAmarilla(){
        var x = game.rnd.integerInRange(0, 400);
        var yGravity = game.rnd.integerInRange(100, 300);
        var xVelocity = game.rnd.integerInRange(100, 300);

        var pl = Bamarillas.create(game.world.centerX+x, game.world.centerY-200, 'ball');
        pl.anchor.setTo(0.5, 0.5);
        pl.body.gravity.y = yGravity;
        pl.body.velocity.x = -xVelocity;
        pl.body.bounce.y = 0.8;

    }

    function creaBolaAzul(){
        var x = game.rnd.integerInRange(0, 400);
        var yGravity = game.rnd.integerInRange(100, 300);
        var xVelocity = game.rnd.integerInRange(100, 300);

        var pl = Bazules.create(game.world.centerX-x, game.world.centerY-200, 'ball_1');
        pl.anchor.setTo(0.5, 0.5);
        pl.body.gravity.y = yGravity;
        pl.body.velocity.x = xVelocity;
        pl.body.bounce.y = 0.8;

    }

    function creaBolaRoja(ob1,ob2){



        var yGravity = game.rnd.integerInRange(100, 300);
        var xVelocity = game.rnd.integerInRange(-100, 100);
        var yVelocity = game.rnd.integerInRange(-100, 200);


        var pl = Brojas.create(ob1.x, ob1.y, 'ball_2');
        pl.anchor.setTo(0.5, 0.5);
        pl.body.gravity.y = yGravity;
        pl.body.velocity.setTo(xVelocity,yVelocity);
        pl.body.bounce.y = 0.8;

        ob1.kill();
        ob2.kill();


    }

    function update(){


        game.physics.arcade.collide(Bazules, Bamarillas,creaBolaRoja,null,this);


    }

};