/* Estructura basica */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });
    var plataforma;
    var Bamarillas;
    var Bazules;


    function preload () {

        // primitiva para cargar assets (audio, image, etc)
        game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');
        game.load.image('plataforma', '../../assets/sprites/platform.png');

    }

    function create () {



        plataforma = game.add.sprite(game.world.centerX-300, game.world.centerY, 'plataforma');
        // la anclamos al centro




        //habilitamos la fisica en el game
        game.physics.startSystem(Phaser.Physics.ARCADE);
        //fijamos una graveda
        game.physics.arcade.gravity.y = 100;
        //decimos que objetos van a respetar la fisica




        Bamarillas = game.add.group();
        Bamarillas.enableBody = true;
        Bamarillas.physicsBodyType = Phaser.Physics.ARCADE;


        game.time.events.repeat(100, 20, creaBolaAmarilla, this);


        game.physics.enable( [Bamarillas,plataforma], Phaser.Physics.ARCADE);

        plataforma.body.allowGravity = false;
        plataforma.body.immovable = true;



    }

    function creaBolaAmarilla(){
        var x = game.rnd.integerInRange(0, 400);
        var yGravity = game.rnd.integerInRange(100, 300);
        var xVelocity = game.rnd.integerInRange(100, 300);

        var pl = Bamarillas.create(game.world.centerX+x, game.world.centerY-200, 'ball_1');
        pl.anchor.setTo(0.5, 0.5);
        pl.body.gravity.y = yGravity;
        pl.body.velocity.x = -xVelocity;
        pl.body.bounce.y = 0.8;




    }

    function update(){

        game.physics.arcade.collide(plataforma, Bamarillas);
        //game.physics.arcade.collide(plataforma, bolas[1]);

        plataforma.body.velocity.setTo(0, 0);



    }

};