/* Estructura basica */

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });


	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');

	}

	function create () {
	

		var bola = game.add.sprite(game.world.centerX-100, game.world.centerY, 'ball');
        var bola1 = game.add.sprite(game.world.centerX, game.world.centerY, 'ball_1');
        // la anclamos al centro

        bola.anchor.setTo(0.5, 0.5);
        bola1.anchor.setTo(0.5, 0.5);

        //habilitamos la fisica en el game
        game.physics.startSystem(Phaser.Physics.ARCADE);
        //fijamos una graveda
        game.physics.arcade.gravity.y = 100;
        //decimos que objetos van a respetar la fisica
        game.physics.enable( [bola,bola1], Phaser.Physics.ARCADE);

        //choque con bordes
        bola.body.collideWorldBounds = true;
        bola1.body.collideWorldBounds = true;

        //le doy una gravedad local al objeto
        bola1.body.gravity.y = 200;

        bola.body.bounce.y = 0.8;
        bola1.body.bounce.y = 0.8;

	}

};