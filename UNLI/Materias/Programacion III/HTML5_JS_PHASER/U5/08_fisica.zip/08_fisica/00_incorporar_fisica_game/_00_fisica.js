/* Estructura basica */

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });


	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('ball', '../../assets/sprites/aqua_ball.png');

	}

	function create () {
	

		var bola = game.add.sprite(game.world.centerX, game.world.centerY, 'ball');
        // la anclamos al centro
        bola.anchor.setTo(0.5, 0.5);

        //habilitamos la fisica en el game
        game.physics.startSystem(Phaser.Physics.ARCADE);
        //fijamos una graveda
        game.physics.arcade.gravity.y = 100;
        //decimos que objetos van a respetar la fisica
        game.physics.enable( bola, Phaser.Physics.ARCADE);

        //choque con bordes
        bola.body.collideWorldBounds = true;


	}

};