/* Estructura basica */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });
    var plataforma;
    var bolas = [];

    function preload () {

        // primitiva para cargar assets (audio, image, etc)
        game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');
        game.load.image('plataforma', '../../assets/sprites/platform.png');

    }

    function create () {


        bolas[0] = game.add.sprite(game.world.centerX-100, game.world.centerY-200, 'ball');
        plataforma = game.add.sprite(game.world.centerX-300, game.world.centerY, 'plataforma');
        // la anclamos al centro

        bolas[0].anchor.setTo(0.5, 0.5);


        //habilitamos la fisica en el game
        game.physics.startSystem(Phaser.Physics.ARCADE);
        //fijamos una graveda
        game.physics.arcade.gravity.y = 100;
        //decimos que objetos van a respetar la fisica
        game.physics.enable( [bolas[0],plataforma], Phaser.Physics.ARCADE);

        //choque con bordes
        bolas[0].body.collideWorldBounds = true;


        //le doy una gravedad local al objeto
        bolas[0].body.gravity.y = 200;

        bolas[0].body.bounce.y = 0.8;

        plataforma.body.immovable = true;
        plataforma.body.allowGravity = false;

    }


    function update(){

        game.physics.arcade.collide(plataforma, bolas[0],chocaron,null,this);

        plataforma.body.velocity.setTo(0, 0);


    }



    function chocaron (ob1, ob2) {//plataforma, bola

        //si es menor a 10 es porque ya se quedo quieta
        if (Math.abs(ob2.body.velocity.y) > 10) {

            var bola = game.add.sprite(game.world.randomX, game.world.randomY, 'ball_1');
            game.physics.enable(bola, Phaser.Physics.ARCADE);
        }

    }



    };