/* Estructura basica */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });
    var Grupo;
    var ball;


    function preload () {

        // primitiva para cargar assets (audio, image, etc)
        game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');



    }

    function create () {





        //Creo el grupo
        Grupo = game.add.group();

        //creo objetos dentro del grupo
        Grupo.create(game.world.randomX, game.world.randomY, 'ball');

        Grupo.create(game.world.randomX, game.world.randomY, 'ball');

        Grupo.create(game.world.randomX, game.world.randomY, 'ball');

        Grupo.create(game.world.randomX, game.world.randomY, 'ball');



    }



    function update(){





    }

};