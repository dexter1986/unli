/* Estructura basica */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });
    var Grupo;
    var ball;


    function preload () {

        // primitiva para cargar assets (audio, image, etc)
        game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');



    }

    function create () {





        //Creo el grupo
        Grupo = game.add.group();

        for(var i = 0;i<20;i++){

            //creo objetos dentro del grupo
            Grupo.create(game.world.randomX, game.world.randomY, 'ball');

        }

        //  cambia el estado de un atributo (atributo, valor)
        Grupo.setAll('inputEnabled', true);

        //  And allow them all to be dragged (metodo, contexto, atributos)
        //metodo: es el metodo en el objeto hijo
        //el contexto en el cual es llamado, es decir, la clase que contiene le metodo
        //los atibutos pasados al metodo separados por comas

        //recordar que el drag se llama asi:
        //sprite.input.enableDrag(true)

        Grupo.callAll('input.enableDrag', 'input',true);




    }



    function update(){





    }

};