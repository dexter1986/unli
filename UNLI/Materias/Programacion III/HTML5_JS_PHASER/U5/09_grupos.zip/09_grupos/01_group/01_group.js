// Group
// creacion de grupos


/*
*
* Documentacion para este script:
*
* Group:
*
* docs/Phaser.Group.html
*
*
* */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });



    function preload() {

				game.load.image('player', '../../assets/sprites/player.png');
        game.load.image('invader', '../../assets/games/invaders/invader.png');

    }



    var diamond;
		var posX=400; //Posicion X del personaje
		var posY=500; //Posicion Y del personaje

		var friend;
		var enemies;		


    function create() {
			// creamos 2 grupos
			friend = game.add.group();
			enemies = game.add.group();				

			for (var i = 0; i < 8; i++) {
					// creamos una nueva instancia de Phaser.Sprite y la agrega al grupo
					// que usa el sprite invader
					// create(x, y, key)
					enemies.create(Math.random() * 800, 120 + Math.random() * 200, 'invader');
			}

			//Creamos el sprite player
			var player = game.add.sprite(posX,posY, 'player');
			// Agregamos el sprite exitente player al grupo friend
			friend.add(player);			
    }
		
		function update() {
		}
		
};