/* Estructura basica */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create});
    var Grupo;
    var ball;


    function preload () {

        // primitiva para cargar assets (audio, image, etc)
        game.load.image('ball', '../../assets/sprites/aqua_ball.png');
        game.load.image('ball_1', '../../assets/sprites/yellow_ball.png');



    }

    function create () {





        //Creo el grupo
        Grupo = game.add.group();

        for(var i = 0;i<20;i++){

            //creo objetos dentro del grupo
            Grupo.create(game.world.randomX, game.world.randomY, 'ball');


        }

        Grupo.setAll('inputEnabled', true);


        //para obtener un objeto particular puedo usar getAt (indice)
        for(var i = 0;i<20;i++){


            Grupo.getAt(i).events.onInputDown.add(remover, this);


        }






    }



    function remover(obb){


     Grupo.remove(obb);


    }

};