// Group
// creacion de grupos y collide con spritesheet

/*
*
* Documentacion para este script:
*
* Group:
*
* docs/Phaser.Group.html
*
*
* */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

    function preload() {
				game.load.image('player', '../../assets/sprites/player.png');
				game.load.spritesheet('invader', '../../assets/games/invaders/invader.png', 16, 16, 1);
    }

		var enemies;
		var cursors;


    function create() {
			player = game.add.sprite(300, 300, 'player');
			player.name = 'player_sprite';
			game.physics.enable(player, Phaser.Physics.ARCADE);
			// creamos el grupo
			enemies = game.add.group();				
			enemies.enableBody = true;
			enemies.physicsBodyType = Phaser.Physics.ARCADE;			

			for (var i = 0; i < 8; i++) {
					// creamos una nueva instancia del grupo Phaser.Sprite
					// que usa el spritesheet invader
					// create(x, y, key)
					var c = enemies.create(Math.random() * 800, Math.random() * 200, 'invader', 99);
					c.name = 'invader' + i;
					c.body.immovable = true;
			}
			
			cursors = game.input.keyboard.createCursorKeys();
    }
		
		function update() {
			game.physics.arcade.collide(player, enemies, collisionHandler, null, this);
			
			player.body.velocity.x = 0;
			player.body.velocity.y = 0;

			if (cursors.left.isDown) {
					player.body.velocity.x = -200;
			}
			else if (cursors.right.isDown) {
					player.body.velocity.x = 200;
			}

			if (cursors.up.isDown) {
					player.body.velocity.y = -200;
			}	else if (cursors.down.isDown) {
					player.body.velocity.y = 200;
			}			
		}
		
		function collisionHandler (player, invader) {
			// Si hay colision lo elimina
			if (invader.frame == 99) {
					invader.kill();
			}

		}		
};