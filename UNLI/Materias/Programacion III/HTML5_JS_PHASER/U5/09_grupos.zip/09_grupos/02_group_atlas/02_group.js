// Group
// creacion de grupos y spritesheet

/*
*
* Documentacion para este script:
*
* Group:
*
* docs/Phaser.Group.html
*
*
* */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

    function preload() {
				game.load.atlas('atlas', '../../assets/sprites/patricio/spritesheet.png', '../../assets/sprites/patricio/sprites.json');
    }

		var enemies;


    function create() {
			// creamos el grupo
			enemies = game.add.group();				

			for (var i = 0; i < 8; i++) {
					// creamos una nueva instancia del grupo Phaser.Sprite
					// que usa el sprite atlas
					// create(x, y, key)
					sprite = enemies.create(Math.random() * 800, Math.random() * 200, 'atlas');
			}
			// estos son los frames para la animacion idle_
			var frameNames = Phaser.Animation.generateFrameNames('idle_', 0, 6, '', 2);
			// Group.callAll llama a los metodos existentes en cada hijo del grupo
			enemies.callAll('animations.add', 'animations', 'idle', frameNames, 15, true, false);
			// equivale a hacer 'play a la animacion idle' , existente en cada hijo por si mismo
			enemies.callAll('play', null, 'idle');			
			
    }
		
		function update() {
		}
		
};