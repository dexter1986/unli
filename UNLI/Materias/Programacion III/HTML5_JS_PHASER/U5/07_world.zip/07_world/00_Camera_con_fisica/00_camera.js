// world
// la camara sigue al personaje


/*
 *
 * Documentacion para este script:
 *
 * World:
 *
 * docs/Phaser.World.html
 *
 * */

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });


	//a ver los sprites no son regulares, por lo que no podemos definir de forma igual los frames
	// para ello necesitamos un archivo mapa json que dice que tipo de animacion tenemos en cada frame

	//personaje
	var Patricio;

	//las animaciones (estados) que vamos a usar

	var _idle;
	var _walk;
	var _jump;

	//teclas


	var _Keys = [];

	//velocidad al caminar
	var velX = 150;

	//velocidad al saltar
	var velY = -1000;

	//velocidad de la camara
	var velCamaraX = velX/15;


	function preload(){
		//aqui cargaremos el spritesheet y el atlas que dice a que animacion pertenece cada frame
		game.load.atlas('atlas', '../../assets/sprites/patricio/spritesheet.png', '../../assets/sprites/patricio/sprites.json');
		game.load.image('background', '../../assets/pics/platformer_backdrop.png');
		game.load.image('logo', '../../assets/buttons/arrow-button.png');

		//teclas
		_Keys[0] = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
		_Keys[1] = game.input.keyboard.addKey(Phaser.Keyboard.UP);
		_Keys[2] = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
		_Keys[3] = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
	}


	function create(){
		// setBounds configura el tama�o del world
		// setBounds(x, y, width, height)
		game.world.setBounds(0, 0, 1200, 600);		
		Background = game.add.sprite(0, 0, 'background');
		Background.scale.set(3.75,2.34);//320 x 256

    Logo = game.add.sprite(0, 0, 'logo');
		Logo.scale.set(0.5,0.5);
		// Fija el sprite a la camara, es decir que el logo la acompanara cuando la desplacemos con game.camera.x
    Logo.fixedToCamera = true;
		// Luego de fijar el sprite a la camara, lo desplazamos respecto a la esquina superior izquierda
    Logo.cameraOffset.setTo(20, 10);

		//cargamos a patricio
		Patricio = game.add.sprite(200, 200, 'atlas');

		//lo acomodamos
		Patricio.scale.set(1.5,1.5);
		Patricio.anchor.set(0.5,0.5);				

		//Definimos las animaciones
		//los parametros son:
		// - cadena de texto con la que empieza la animacion en el mapa json
		// - indice inicial
		// - indice final de frame
		// - cadena de texto final
		// - cuantos carateres tiene en los indices

		_idle = Phaser.Animation.generateFrameNames('idle_', 0, 6, '', 2);
		_jump = Phaser.Animation.generateFrameNames('jump_', 0, 4, '', 2);
		_walk = Phaser.Animation.generateFrameNames('walk_', 0, 9, '', 2);

		// Se los asignamos a Patricio
		Patricio.animations.add('idle',_idle , 10, true);
		Patricio.animations.add('walk',_walk , 10, true);
		Patricio.animations.add('jump',_jump , 10, false);

		//Le dicemos que cargue el idle
		Patricio.animations.play('idle');

		//Activamos la fisica (no importa por ahora)
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.physics.arcade.gravity.y = 800;
		game.physics.enable( Patricio);
		//bordes
		Patricio.body.collideWorldBounds = true;
		Patricio.body.gravity.y = 500;
	}

	function update(){
		//le saco toda fuerza que puediera tener en horizontal
		Patricio.body.velocity.x = 0;

		//si aprieta izquierda
		if (_Keys[0].isDown) {
				Patricio.body.velocity.x = -velX;
				// modifica la coordenada x de la camara
				game.camera.x-=velCamaraX;

				//si esta mirando a la derecha
				if(Patricio.scale.x>=0){
						Patricio.scale.x*=-1;
				}
				//si esta tocando el piso
				if(Patricio.body.onFloor())
				{Patricio.animations.play('walk');}
		}
		else {//sino
				//si aprieta a la derecha
				if (_Keys[2].isDown){
						Patricio.body.velocity.x = velX;
						// modifica la coordenada x de la camara
						game.camera.x+=velCamaraX;
						//si esta mitando a la izquierda
						if(Patricio.scale.x<0){
								Patricio.scale.x*=-1;
						}
						//si esta en el piso
						if(Patricio.body.onFloor())
						{Patricio.animations.play('walk');}
				}
				else{
						//sino, no esta haciendo nada (idle)
						if(Patricio.body.onFloor()){
								Patricio.animations.play('idle');
						}
				}
		}

		// si aprieta saltar y esta en el piso
		if (_Keys[1].isDown && Patricio.body.onFloor()){
				Patricio.body.velocity.y = velY;
				Patricio.animations.stop();
				Patricio.animations.play('jump');
		}
	}
};