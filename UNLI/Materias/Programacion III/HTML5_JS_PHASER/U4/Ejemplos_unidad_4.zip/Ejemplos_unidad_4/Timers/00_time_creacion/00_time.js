// tween
// sprite con movimiento

var timer;

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update: update });



    var texto;




    function preload() {

    }



    function create() {



        texto = game.add.text(game.world.centerX-90, 16, '', { fill: '#ff00ff' });

        var tiempo = 4000; //en ms


        /*
        *
        *
        * El Time es el controlador interno del tiempo del core.
        * El Time instancia Timer
        * Los Timer son pausas o delays que no hacen nada, solo esperan y ejecutan alguna funcion
        * un callback. Las cosas que le podemos definir al Timer son:

         add(delay, callback, callbackContext, arguments)
         destroy()
         loop(delay, callback, callbackContext, arguments)
         order()
         pause()
         remove(event)
         removeAll()
         repeat(delay, repeatCount, callback, callbackContext, arguments)
         resume()
         start(delay)
         stop(clearEvents)

        * */


        //argumentos add: delay, callback, objeto a se llamado, argumentos para el callback

        timer = game.time.events.add(tiempo, cambiaBack, this);


    }

    function cambiaBack() {


        var R_hexa = Phaser.Color.colorToHexstring((Math.random()*256)^1);
        var G_hexa = Phaser.Color.colorToHexstring((Math.random()*256)^1);
        var B_hexa = Phaser.Color.colorToHexstring((Math.random()*256)^1);

        var color = "#"+R_hexa+G_hexa+B_hexa;

        game.stage.backgroundColor = color;

    }

    function update() {

      texto.text = timer.delay - game.time.events.duration;

    }

};