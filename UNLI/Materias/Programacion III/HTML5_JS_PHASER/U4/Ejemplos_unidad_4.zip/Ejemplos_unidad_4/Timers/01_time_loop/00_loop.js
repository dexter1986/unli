// tween
// sprite con movimiento

var timer;

window.onload = function() {

    

     var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update: update });

     //game.load.image('hongo', '../mushroom2.png');


     var texto;
     var honguito;
     var loops = 0;;



     function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


     }



     function create() {


     honguito = game.add.sprite(200, 200, 'hongo');

     texto = game.add.text(game.world.centerX-50, 16, '', { fill: '#ffffff' });

     var tiempo = 1000; //en ms





     //loop(delay, callback, callbackContext, arguments)





     timer = game.time.events.loop(tiempo, mueveHonguito, this);

     }

     function mueveHonguito() {

     honguito.x = game.world.randomX;
     honguito.y = game.world.randomY;
     loops++;


     }

     function update() {

     texto.text = "loop: "+loops;


     }




};