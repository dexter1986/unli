// tween
// sprite con movimiento

var timer;

window.onload = function() {

    

     var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update: update });

     //game.load.image('hongo', '../mushroom2.png');


     var texto;
     var honguito;
     var loops = 0;
     var maxLoops = 10;



     function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


     }



     function create() {


     honguito = game.add.sprite(200, 200, 'hongo');

     texto = game.add.text(game.world.centerX-130, 16, '', { fill: '#ffffff' });

     var tiempo = 1000; //en ms





     //loop(delay, callback, callbackContext, arguments)





     timer = game.time.events.repeat(tiempo, maxLoops, mueveHonguito, this);

     }

     function mueveHonguito() {


     loops++;

     honguito.x = game.world.randomX;
     honguito.y = game.world.randomY;





     }

     function update() {

         texto.text = "van "+loops+" repito hasta "+maxLoops;


     }




};