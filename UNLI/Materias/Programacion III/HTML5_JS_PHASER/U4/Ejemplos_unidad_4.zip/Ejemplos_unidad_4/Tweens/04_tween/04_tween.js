// tween
// sprite con 4 tweens mixtos concatenados en loop

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

	// documetancion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html


	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('ball', '../../assets/sprites/blue_ball.png');

	}
	
	var image;
	// posicion inicial del sprite
	var posX = 100;
	var posY = 200;

	function create () {
		// fondo cyan
		game.stage.backgroundColor = '#0091cc';	
		// agregamos la imagen al game
		image = game.add.sprite(posX, posY, 'ball');
		// la anclamos al centro
		image.anchor.setTo(0.5, 0.5);
		image.alpha = 0;
		
		// creamos el tween que se aplicara al objeto image
		var behavior=game.add.tween(image);
		// configuramos el tween: to(properties, duration, ease, autoStart, delay, repeat, yoyo)
		// concatenamos 4 tweens mixtos, y los fijamos en loop
    behavior.to({ x: 700, alpha: 0.5 }, 3000, Phaser.Easing.Linear.None) // hace el recorrido y varia alpha en 3 seg
						.to({ y: 400, alpha: 1 }, 1000, Phaser.Easing.Linear.None) // hace el recorrido y varia alpha en 1 seg
						.to({ x: 100, alpha: 0.5 }, 1000, Phaser.Easing.Linear.None)
						.to({ y: 200, alpha: 0 }, 1000, Phaser.Easing.Linear.None)
						.loop() // hace loop de una cadena de tweens
						.start();	// inicia el tween
	}

	
	function update() {
    // Sprite debug info
    game.debug.spriteInfo(image, 32, 32);		
	}

};