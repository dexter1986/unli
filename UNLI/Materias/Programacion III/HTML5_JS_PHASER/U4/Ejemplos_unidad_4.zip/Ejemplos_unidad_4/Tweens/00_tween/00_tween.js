// tween
// sprite con movimiento

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

	// documetacion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html
	// to(properties, duration, ease, autoStart, delay, repeat, yoyo)
	// properties: indica la propiedad a interpolar
	// duration: la duraci�n del tween en ms (default 1000)
	// ease: tipo de funcion Easing Function usada para interpolar (default Phaser.Easing.Linear.None)
	// autoStart: booleano que especifica si el tween iniciar� automaticamente o no (default false)
	// delay: tiempo antes que inicie el tween (default 0)
	// repeat: valor num�rico que indica si el tween debe reiniciar una vez completado el ciclo inicial. Es ignorado por tweens encadenados (default 0)
	// yoyo: booleano que indica si el tween volvera al estado anterior en modo ping pong (elimina callback de onComplete) (default false)
	

	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('cara', '../../assets/sprites/cara_img.png');

	}
	
	var image;

	function create () {
	
		// agregamos la imagen al game
		image = game.add.sprite(0, game.world.centerY, 'cara');
		// la anclamos al centro
		image.anchor.setTo(0.5, 0.5);
		
		// estado inicial de la propiedad
		image.x = image.width/2;
		// creamos el tween que se aplicara al objeto image
		var behavior=game.add.tween(image);
		// to se utiliza para configurar el tween
		// to(properties, duration, ease, autoStart, delay, repeat, yoyo)
		behavior.to({ x: game.world.width-(image.width/2) }, 2000);
		// inicia el tween
		behavior.start();
	}

	
	function update() {
    // Sprite debug info
    game.debug.spriteInfo(image, 32, 32);		
	}

};