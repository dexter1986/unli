// tween
// sprite con alpha variable entre 0 y 1

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create });

    function preload() {
		
				// primitiva para cargar assets (audio, image, etc)
        game.load.image('logo', '../../assets/sprites/phaser2.png');

    }

    function create() {
				
				// agregamos la imagen al game
        var sprite = game.add.sprite(game.world.centerX, game.world.centerY, 'logo');

				// la anclamos al centro
        sprite.anchor.setTo(0.5, 0.5);
				// estado inicial de alpha
        sprite.alpha = 0;
				// creamos el tween que se aplicara al objeto image				
				// to se utiliza para configurar el tween
				// to(properties, duration, ease, autoStart, delay, repeat, yoyo)
        game.add.tween(sprite).to( { alpha: 1 }, 2000, Phaser.Easing.Linear.None, true, 0, 1000, true);

    }
};