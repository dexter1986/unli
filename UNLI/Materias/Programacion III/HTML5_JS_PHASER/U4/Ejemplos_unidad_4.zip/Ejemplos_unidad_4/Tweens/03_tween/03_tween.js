// tween
// sprite con rotacion

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

	// documetancion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html


	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('cara', '../../assets/sprites/cara_img.png');

	}
	
	var image;
	//var angle = 0;

	function create () {
	
		// agregamos la imagen al game
		image = game.add.sprite(game.world.centerX, game.world.centerY, 'cara');
		// la anclamos al centro
		image.anchor.setTo(0.5, 0.5);
		
		image.angle = 0;
		
		// creamos el tween que se aplicara al objeto image
		var behavior=game.add.tween(image);
		// to se utiliza para configurar el tween
		// to(properties, duration, . . . )
		behavior.to({ angle: 180 }, 3000) // va de 0 a 180 grados en 3 seg
						.to({ angle: 0   }, 1000) // va de 180 a 0 grados en 1 seg
						.loop() // hace loop de una cadena de tweens
						.start();	// inicia el tween
	}

	
	function update() {
    // Sprite debug info
    game.debug.spriteInfo(image, 32, 32);		
	}

};