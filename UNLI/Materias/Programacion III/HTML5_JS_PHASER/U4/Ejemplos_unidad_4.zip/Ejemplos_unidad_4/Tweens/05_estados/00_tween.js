// tween
// sprite con callbacks y escalado

window.onload = function() {

	// documetancion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html

	var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create });

	function preload() {

			game.load.image('ball', '../../assets/sprites/yellow_ball.png');
			game.load.image('Gball', '../../assets/sprites/green_ball.png');
			game.load.image('Rball', '../../assets/sprites/red_ball.png');

	}

	var ball;
	var tween;
	var text;
	var loops = 1;

	//para el tween
	var scale_x = 3;
	var scale_y = 3;

	var escala = {x: scale_x, y: scale_y};
	var duracion = 2000;
	var easing = Phaser.Easing.Linear.Out;
	var autostart = true;
	var delay = 0;
	var repetir = 3;
	var yoyo = false
	

	function create() {

		ball = game.add.sprite(200, 200, 'ball');
		ball.anchor.setTo(0.5,0.5);

		ball.scale.setTo(1.0, 1.0);

		tween = game.add.tween(ball.scale).to(escala, duracion, easing, autostart,delay,repetir,yoyo);

		/*
		onComplete
		onLoop
		onStart
		*/

		// cuando inicia
		// habilitamos el callback del onStart y cuando se ejecute llamamos a la funcion empieza
		tween.onStart.add(empieza, this);

		// cuando hace un ciclo
		tween.onLoop.add(loop, this);

		// cuando termina
		tween.onComplete.add(complete, this);

		text = game.add.text(game.world.centerX-90, 16, 'estado:', { fill: '#ffffff' });

	}

	// informa en el canvas que inicio el tween
	function empieza(){

			text.text = "estado: empieza";

	}

	function loop(){

			text.text = "estado: loop " + loops;

			loops++;

	}

	// informa en el canvas que finalizo el tween
	function complete(){

			text.text = "estado: termino";

	}

};