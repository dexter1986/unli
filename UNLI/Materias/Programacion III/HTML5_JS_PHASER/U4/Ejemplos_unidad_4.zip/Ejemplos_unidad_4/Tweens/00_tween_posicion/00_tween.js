// tween
// sprite con movimiento

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

	// documetancion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html
	// to(properties, duration, ease, autoStart, delay, repeat, yoyo)
	// properties: type object: Properties you want to twee
	// duration: type number: Duration of this tween in ms (default 1000)
	// ease: type function: Easing function (default Phaser.Easing.Linear.None)
	// autoStart: type boolean: Whether this tween will start automatically or not (default false)
	// delay: type number: Delay before this tween will start (default 0)
	// repeat: type number: Should the tween automatically restart once complete? This ignores any chained tweens (default 0)
	// yoyo: type boolean: A tween that yoyos will reverse itself and play backwards automatically. 
	//			 A yoyo'd tween doesn't fire the Tween.onComplete event, so listen for Tween.onLoop instead (default false)
	

	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('cara', '../../assets/sprites/cara_img.png');

	}
	
	var image;

	function create () {
	
		// agregamos la imagen al game
		image = game.add.sprite(0, game.world.centerY, 'cara');
		// la anclamos al centro
		image.anchor.setTo(0.5, 0.5);
		
		image.x = image.width*.5;
		// creamos el comportamiento que se aplicara al objeto image
		var behavior=game.add.tween(image);
		// to se utiliza para configurar el tween
		// to(properties, duration, ease, autoStart, delay, repeat, yoyo)
		behavior.to({ x: game.world.width-(image.width *.5) }, 2000, Phaser.Easing.Linear.None, true, 0, 1, true);
		// inicia el tween
		//behavior.start();// start tambien puede ser llamado desde Tween.to por el parametro autoStart en true
	}

	
	function update() {
    // Sprite debug info
    game.debug.spriteInfo(image, 32, 32);		
	}

};