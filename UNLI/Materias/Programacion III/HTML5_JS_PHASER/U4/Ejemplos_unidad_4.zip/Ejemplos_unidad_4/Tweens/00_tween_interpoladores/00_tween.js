// tween
// efecto producido en el sprite al aplicar distintos valores para la funcion Easing Function

window.onload = function() {

	// documetancion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html

	// to(properties, duration, ease, autoStart, delay, repeat, yoyo)
	// properties: objeto{} Propiedades a mover
	// duration: numero, duracion en ms
	// ease: tipo de funcion Easing Function usada para interpolar (default Phaser.Easing.Linear.None)
	/*
	Phaser.Easing.Back
	Phaser.Easing.Bounce
	Phaser.Easing.Circular
	Phaser.Easing.Cubic
	Phaser.Easing.Elastic
	Phaser.Easing.Exponential
	Phaser.Easing.Linear
	Phaser.Easing.Quadratic
	Phaser.Easing.Quartic
	Phaser.Easing.Quintic
	Phaser.Easing.Sinusoidal
	*/
	// autoStart: type boolean: arranque automatico
	// delay: type number: delay para arrancar (default 0)
	// repeat: type number: repetir
	// yoyo: type boolean: ping pong (elimina callback de onComplete)

	var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create });

	function preload() {

		game.load.image('ball', '../../assets/sprites/yellow_ball.png');
		game.load.image('Gball', '../../assets/sprites/green_ball.png');
		game.load.image('Rball', '../../assets/sprites/red_ball.png');

	}

	var ball = [];
	var tweens = [];
	var inicio = 100;
	var final = 600;
	var cantidad = 11;
	var duracion = 3000;

	function create() {

		for(var i=0;i<cantidad;i++) {

			 ball[i] = game.add.sprite(inicio, (i*50)+50, 'ball');
			 Gball = game.add.sprite(inicio, (i*50)+50, 'Gball');
			 Rball = game.add.sprite(final, (i*50)+50, 'Rball');

		}
		startBounceTween();
	}

	function startBounceTween() {
		//ball.y = 0;
		for(var i=0;i<cantidad;i++) {

			tweens[i] = game.add.tween(ball[i]);

		}

		tweens[0].to({ x: final },duracion, Phaser.Easing.Back.In);
		tweens[1].to({ x: final },duracion, Phaser.Easing.Bounce.In);
		tweens[2].to({ x: final },duracion, Phaser.Easing.Circular.In);
		tweens[3].to({ x: final },duracion, Phaser.Easing.Cubic.In);
		tweens[4].to({ x: final },duracion, Phaser.Easing.Elastic.In);
		tweens[5].to({ x: final },duracion, Phaser.Easing.Exponential.In);
		tweens[6].to({ x: final },duracion, Phaser.Easing.Linear.In);
		tweens[7].to({ x: final },duracion, Phaser.Easing.Quadratic.In);
		tweens[8].to({ x: final },duracion, Phaser.Easing.Quartic.In);
		tweens[9].to({ x: final },duracion, Phaser.Easing.Quintic.In);
		tweens[10].to({ x: final },duracion, Phaser.Easing.Sinusoidal.In);

		for(var i=0;i<cantidad;i++) {

			tweens[i].start();

		}

	}

};