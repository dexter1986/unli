// tween
// sprite con alpha en loop, variable entre 0 y 1

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

	// documetancion de Tween
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Tween.html


	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('cara', '../../assets/sprites/cara_img.png');

	}
	
	var image;

	function create () {
		// fondo cyan
		game.stage.backgroundColor = '#0091cc';	
		// agregamos la imagen al game
		image = game.add.sprite(game.world.centerX, game.world.centerY, 'cara');
		// la anclamos al centro
		image.anchor.setTo(0.5, 0.5);
		
		// creamos el comportamiento que se aplicara al objeto image
		var behavior=game.add.tween(image);
		// configuramos el tween: to(properties, duration, ease, autoStart, delay, repeat, yoyo)
		// concatenamos 2 tweens, y los fijamos en loop
    image.alpha = 0;
		behavior.to({ alpha: 1 }, 2000, Phaser.Easing.Linear.None, true, 0) // espera 0 seg para ir de alpha 0 a alpha 1
						.to({ alpha: 0 }, 2000, Phaser.Easing.Linear.None, true, 4000) // espera 4 seg para ir de alpha 1 a alpha 0
						.loop(); // hace loop de una cadena de tweens
						//.start();// start puede ser llamado tambien desde por el parametro autoStart de Tween.to
	}

	
	function update() {
	}

};