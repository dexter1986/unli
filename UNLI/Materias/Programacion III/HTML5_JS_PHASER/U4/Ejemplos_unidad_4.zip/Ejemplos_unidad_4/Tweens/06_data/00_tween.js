// tween
// tween Data
// vamos a hacer una interpolacion entre 0 y 255 para 10 segundos con 60 fps
// la idea es poder cambiar los 3 canales rgb para asi llegar del negro al blanco

// generateData genera una matriz con los valores de los objetos interpolados desde el valor inicial al final,
// realizando una simulaci�n entre la cantidad intermedia de fotogramas definidos, 
// basandose en los valores de configuraci�n dada en Tween.to
// No tiene en cuenta el delay y la repeticion de los tweens encadenados
// Devuelve solo un juego de datos de interpolacion, incluyendo yoyo si esta configurado
window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create, update:update });

	function preload() {
	}

	var tween;
	var text;
	var data;
	var index = 0;

  //para el tween
	var duracion = 10000;
	var easing = Phaser.Easing.Linear.Out;

	function create() {

			game.stage.backgroundColor = "#000000";

			// vamos a hacer una interpolacion entre 0 y 255 para 10 segundos con 60 fps
			// la idea es poder cambiar los 3 canales rgb para asi llegar del negro al blanco

			// valor inicial
			var tweenData = { r: 0, g:0, b:0};
			// con make lo declaramos, pero no lo instanciamos
			tween = game.make.tween(tweenData).to( { r: 255, g:255, b:255}, duracion, easing);

			// generamos data en base a los fps que deseamos
			var fps = 60;
			data = tween.generateData(fps);

			// Ahora en data tenemos un arreglo de (10 * 60 = 600) valores muestreados
			// que van de 0 a 255. Falta asignarselos al color para ver como cambia
			text = game.add.text(game.world.centerX-90, 16, '', { fill: '#ff00ff' });
			
	}


	function update(){

		// la funcion colorToHexstring convierte un valor entero de 0 a 255 en su correspondiente en Hexa
		// sirve para generar el arreglo de color de la forma que soporta Phaser : # FF FF FF (R G B)

		// data es un arreglo con 3 componentes :r,g,b
		// Ej: data[100].r tiene el valor de r en la interpolacion numero 100
		var R_hexa = Phaser.Color.colorToHexstring(data[index].r);
		var G_hexa = Phaser.Color.colorToHexstring(data[index].g);
		var B_hexa = Phaser.Color.colorToHexstring(data[index].b);

		// string de color
		// (la variacion de r,g,b es la misma: podriamos usar una sola variable)
		var color = "#"+R_hexa+G_hexa+B_hexa;

		game.stage.backgroundColor = color;

		index++;

		if (index === data.length){
			index = 0;
		}

		text.text = "data["+index+"].r = " +((data[index].r)^1)+"";

	}

	//Prueben de cambiar el bounce al tween y vean como asigna los colores

};