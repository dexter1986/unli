/* Estructura basica */


/*
*
* Documentacion para este script:
*
* Keyboard:
*
* docs/Phaser.Input.html
*
*
* */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });



    function preload() {


        game.load.image('diamante', '../../assets/sprites/diamond.png');



    }



    function create() {




        diamante = game.add.sprite(300, 300, 'diamante');


        //este evento, el drag, es un evento muy usado y ya esta definido.
        //Sino tendriamos que crearlo a partir del mouseDown, MouseUp y MouseMove

        //habilitamos los eventos al sprite

        diamante.inputEnabled = true;



        //  Habilitamos el drag

        diamante.input.enableDrag(true);



    }
		
};