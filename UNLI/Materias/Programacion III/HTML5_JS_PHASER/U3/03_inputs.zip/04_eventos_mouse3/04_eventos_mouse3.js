/* Estructura basica */


/*
*
* Documentacion para este script:
*
*
* docs/Phaser.Input.html
*
* docs/Phaser.InputHandler.html
*
* */

window.onload = function() {






    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create, update: update });



    function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


    }



    var text;


    function create() {




        Hongo = game.add.sprite(128, 128, 'hongo');

        //habilito eventos

        Hongo.inputEnabled = true;

       /*
       * Tambien es interesante conocer los estados del mouse (en funcion update)
       * */

        text = game.add.text(game.world.centerX-90, 16, 'evento:', { fill: '#ffffff' });



    }


    function update(){



            if (game.input.mousePointer.isDown){

                text.text = 'evento: abajo';

            }

            if (game.input.mousePointer.isUp){

                text.text = 'evento: arriba';

            }

    }
};