/* Estructura basica */


/*
*
* Documentacion para este script:
*
*
* docs/Phaser.Input.html
*
* docs/Phaser.InputHandler.html
*
* */

window.onload = function() {






    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create });



    function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


    }



    var text;


    function create() {




        Hongo = game.add.sprite(128, 128, 'hongo');

        //habilito eventos

        Hongo.inputEnabled = true;

        /*
        *
        * Algunos eventos
        *
        *
        *          onAddedToGroup
        .onRemovedFromGroup
        .onKilled
        .onRevived
        .onOutOfBounds
        .onEnterBounds

        .onInputOver
        .onInputOut
        .onInputDown
        .onInputUp
        .onDragStart
        .onDragStop

        .onAnimationStart
        .onAnimationComplete
        .onAnimationLoop

        * */



        Hongo.events.onInputDown.add(clicks,this);
        Hongo.events.onInputOver.add(sobre,this);
        Hongo.events.onInputOut.add(salgo,this);
        Hongo.events.onInputUp.add(suelto,this);






        text = game.add.text(game.world.centerX-90, 16, 'evento:', { fill: '#ffffff' });



    }


    function clicks(item){
        text.text = 'evento: abajo';
    }
    function sobre(item){
        text.text = 'evento: entro';
    }
    function salgo(item){
        text.text = 'evento: salgo';
    }
    function suelto(item){
        text.text = 'evento: suelto';
    }

};