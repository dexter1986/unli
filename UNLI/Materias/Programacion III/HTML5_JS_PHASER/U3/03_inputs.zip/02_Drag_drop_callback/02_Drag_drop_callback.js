/* Estructura basica */


/*
*
* Documentacion para este script:
*
*
* docs/Phaser.Input.html
*
* docs/Phaser.InputHandler.html
*
* */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update:update});

    var Hongo;
    var text;


    function preload() {

        game.load.image('hongo', '../../assets/sprites/mushroom2.png');

    }



    function create() {

            Hongo = game.add.sprite(200, 200, 'hongo');
            Hongo.inputEnabled = true;
            Hongo.input.enableDrag();

            Hongo.events.onDragStop.add(VolverInicio);


        text = game.add.text(game.world.centerX-90, 16, '', { fill: '#ffffff' });


    }


function update(){

    text.text = "dragueado: "+Hongo.input.isDragged+'';

}




    function VolverInicio(Spr) {

        Spr.x = 200;
        Spr.y = 200;



    }


};