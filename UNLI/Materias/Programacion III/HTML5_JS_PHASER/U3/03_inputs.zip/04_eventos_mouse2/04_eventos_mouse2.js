/* Estructura basica */


/*
*
* Documentacion para este script:
*
*
* docs/Phaser.Input.html
*
* docs/Phaser.InputHandler.html
*
* */

window.onload = function() {






    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create });



    function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


    }



    var text;


    function create() {




        Hongo = game.add.sprite(128, 128, 'hongo');


       /*
       * tambien es posible definir los eventos del mouse del juego. Claro que aplican a la escena en gral
       * */



        game.input.onDown.add(clicks,this);
        game.input.onUp.add(suelto,this);




        text = game.add.text(game.world.centerX-90, 16, 'evento:', { fill: '#ffffff' });



    }


    function clicks(item){
        text.text = 'evento: abajo';
    }

    function suelto(item){
        text.text = 'evento: suelto';
    }



};