/* Estructura basica */


/*
*
* Documentacion para este script:
*
* Keyboard:
*
* docs/Phaser.Phaser.Keyboard.html
*
*
* */

window.onload = function() {


		var cursors;

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

		


    function preload() {

        game.load.image('diamante', '../../assets/sprites/diamond.png');
				//Crea y retorna un objeto conteniendo: Up, Down, Left y Right
				cursors=game.input.keyboard.createCursorKeys();				

    }



    var diamond;
		var posX=20; //posicion X del personaje
		var posY=20; //posicion Y del personaje
		var velX=10;  //velocidad X del personaje
		var velY=10;  //velocidad Y del personaje
		var anchoSprite=30;

		


    function create() {


        //Creamos el sprite
        diamond = game.add.sprite(posX,posY, 'diamante');
				//centro
        diamond.anchor.set(0.5,0.5);
				

    }
		
		function update() {
			// puede moverse un sprite utilizando el teclado
			if (cursors.up.isDown){
				posY-=velY;
				diamond.y=posY;
			}else if (cursors.down.isDown){
				posY+=velY;
				diamond.y=posY;
			}

			if (cursors.left.isDown){
				posX-=velX;
				diamond.x=posX;
			}else if (cursors.right.isDown){
				posX+=velX;
				diamond.x=posX;
			}

		}
		
};