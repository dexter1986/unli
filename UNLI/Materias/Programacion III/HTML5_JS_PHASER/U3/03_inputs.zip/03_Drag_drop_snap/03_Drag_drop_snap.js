/* Estructura basica */


/*
*
* Documentacion para este script:
*
*
* docs/Phaser.Input.html
*
* docs/Phaser.InputHandler.html
*
* */

window.onload = function() {






    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create });



    function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');

    }



    function create() {




        Hongo = game.add.sprite(128, 128, 'hongo');

        //habilito eventos

        Hongo.inputEnabled = true;

        //Habilito Drags

        Hongo.input.enableDrag();



        //El snap lo que hace es que el desplazamiento sea discreto, es decir que se desplaza de a tramos por una grilla invisible.
        //por ejemplo, en una grilla de 90x90

        //enableSnap(snapX, snapY, onDrag, onRelease, snapOffsetX, snapOffsetX)
        //snapX: grilla x
        //snapY: grilla y
        //onDrag: booleano, que se desplace discretamente mientras dragueo
        //onRelease: booleano, que se acomode en la grilla cuando suelto
        //snapOffsetX: Opcional, si quiero setear un tope superior iz
        //snapOffsetY: Opcional, si quiero setear un tope superior iz

        Hongo.input.enableSnap(90, 90, true, true);



    }



};