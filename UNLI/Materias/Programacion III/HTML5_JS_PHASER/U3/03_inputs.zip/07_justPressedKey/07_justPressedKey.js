/* Estructura basica */


/*
 *
 * Documentacion para este script:
 *
 * Keyboard:
 *
 * docs/Phaser.Phaser.Keyboard.html
 *
 *
 * */

window.onload = function() {


    var cursors;

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

    //Tambien es posible definir una tecla cualquiera, incluso las flechas

    var arKey;
    var abKey;
    var izKey;
    var deKey;


    function preload() {

        game.load.image('diamante', '../../assets/sprites/diamond.png');

        // Hay que definirlas una por una



        arKey = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        abKey = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
        izKey = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        deKey = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);



    }



    var diamond;
    var posX=20; //posicion X del personaje
    var posY=20; //posicion Y del personaje
    var velX=10;  //velocidad X del personaje
    var velY=10;  //velocidad Y del personaje
    var anchoSprite=30;




    function create() {


        //Creamos el sprite
        diamond = game.add.sprite(posX,posY, 'diamante');
        //centro
        diamond.anchor.set(0.5,0.5);


    }

    function update() {
        // preguntamos directamente por la tecla


        // Just release: devuelve true o false si la tecla fue la ultima en presionarse dentro del tiempo dado
        //Este comando es util para balancear equipos con distintos fps

        // justReleased(keycode, duration)

        if (game.input.keyboard.justPressed(Phaser.Keyboard.UP, 100)){

                posY-=velY;
            diamond.y=posY;

        }else if (game.input.keyboard.justPressed(Phaser.Keyboard.DOWN, 100)){
            posY+=velY;
            diamond.y=posY;
        }

        if (izKey.isDown){
            posX-=velX;
            diamond.x=posX;


        }else if (deKey.isDown){
            posX+=velX;
            diamond.x=posX;
        }




    }

};