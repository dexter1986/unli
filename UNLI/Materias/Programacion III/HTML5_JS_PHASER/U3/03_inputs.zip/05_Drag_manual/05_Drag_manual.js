/* Estructura basica */


/*
*
* Documentacion para este script:
*
*
* docs/Phaser.Input.html
*
* docs/Phaser.InputHandler.html
*
* */

window.onload = function() {






    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create, update: update });



    function preload() {


        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


    }



    var text;
    //estado
    var drag = false;
    //objeto actual draggeado
    var dragged;

    function create() {




        Hongo = game.add.sprite(128, 128, 'hongo');
        Hongo2 = game.add.sprite(300, 300, 'hongo');

        //habilito eventos

        Hongo.inputEnabled = true;
        Hongo2.inputEnabled = true;

       /*
       * Con tod lo visto, podemos hacer el Drag
       * */

        text = game.add.text(game.world.centerX-90, 16, 'evento:', { fill: '#ffffff' });



        Hongo.events.onInputDown.add(clicks,this);
        Hongo2.events.onInputDown.add(clicks,this);




    }


     function clicks(item){
         item.x = game.input.mousePointer.x - item.width*.5;
         item.y = game.input.mousePointer.y - item.height*.5;
         dragged = item;
         drag = true;
    }


    //tambien es posible hacerlo con fisica y la funcion
    //
    // game.physics.arcade.moveToPointer(sprite, velocidadEnPixel);
    // esta funcion mueve hasta el punto pasado por parametro, sino se pasa punto
    //toma por defecto el puntero del mouse

    function update(){



            if (game.input.mousePointer.isDown){
                //si esta abajo y hay drag, muevo
                if(drag){

                    dragged.x = game.input.mousePointer.x - dragged.width*.5;
                    dragged.y = game.input.mousePointer.y - dragged.height*.5;
                }
                text.text = 'evento: abajo';

            }

            if (game.input.mousePointer.isUp){
                //Sino, suelto y bajo bandera
                if(drag){

                    drag = false;

                }

                text.text = 'evento: arriba';

            }

    }
};