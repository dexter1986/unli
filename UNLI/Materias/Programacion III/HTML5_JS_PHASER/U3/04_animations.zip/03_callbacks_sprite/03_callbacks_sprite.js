/* Estructura basica */


/*
 *
 * Documentacion para este script:
 *
 * AnimationManager:
 *
 * docs/Phaser.AnimationManager.html
 *
 * */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

    //es posible definir una tecla cualquiera, incluso las flechas

    var izKey;
    var deKey;

	var caminando = [6,7,8,9,10,11];

    var parado = [12];


    function preload() {


	    game.load.spritesheet('file', '../../assets/sprites/guyb1.png', 170, 246, 18);


        izKey = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        deKey = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);

    }



    var spriteHero;
    var velX=0;
    var posX = 200;




    function create() {
				//
        spriteHero = game.add.sprite(200, 200, 'file');
        spriteHero.anchor.set(0.5,0.5);
        spriteHero.scale.setTo(0.5, 0.5);

        var anim = spriteHero.animations.add('run', caminando);

        //vamos a agregar 3 callback

        anim.onStart.add(comienza, this);
        anim.onLoop.add(ciclo, this);
        anim.onComplete.add(stop, this);

        //play
        anim.play(10, true);


    }

    function comienza(sprite, animation){

        //al comenzar le damos una posicion y una velocidad
        velX = -2;
        sprite.x = 300;

    }

    function ciclo(sprite, animation){


        //si es el 10mo ciclo, termino, sino lo hago caminar para el otro lado

        if(animation.loopCount == 10){

            //lo detenemos
            animation.loop = false;

        }

        sprite.scale.x*=-1;
        velX*=-1;
    }

    function stop(sprite, animation){

        //lo hacemos detenerse y le cambiamos el frame

        //lo detenemos
        velX = 0;
        //le definimos una nueva animacion
        spriteHero.animations.add('stay', parado);
        //que la corra una vez, no ciclica
        spriteHero.animations.play('stay',1,false);


    }


		

    function update() {

            posX-=velX;
            spriteHero.x=posX;

        }


};