/* Estructura basica */


/*
 *
 * Documentacion para este script:
 *
 * AnimationManager:
 *
 * docs/Phaser.AnimationManager.html
 *
 * */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

    //es posible definir una tecla cualquiera, incluso las flechas
    var arKey;
    var abKey;
    var izKey;
    var deKey;

		var walkingFront = [1, 2, 3];
		var walkingBack = [5, 6, 7];

    function preload() {

        //Vamos a cargar un spritesheet
        //parametros: id_nombre, URL, Frame_Width, Frame_Height, Nro_frames				
        //128x128 el tamanio de cada frame
				//18 frames
        //si en el PNG hay tantos frames como para cubrir la imagen entera, entonces no hace falta este ultimo parametro

        //128=512/4 ; 128=256/2
				game.load.spritesheet('file', '../../assets/sprites/evoland_classic_clink.png', 128, 128, 8);

        // Hay que definirlas una por una
        arKey = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        abKey = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);				
        izKey = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        deKey = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);

    }



    var spriteHero;
    var posX=20; //posicion X del personaje
    var posY=20; //posicion Y del personaje
    var velX=10;  //velocidad X del personaje
    var velY=10;  //velocidad Y del personaje



    function create() {
				//creamos el spritesheet
				crearSprite();

    }



    function crearSprite() {
        //creamos el sprite
        spriteHero = game.add.sprite(posX, posY, 'file');
				//se escala es sprite
				spriteHero.scale.setTo(0.5, 0.5);
        //agregamos el spritesheet llamado "wb" y otro "wf"
				//especificamos el movimiento denominado walkingBack y walkingFront respectivamente
				//add(name, frames, ... )
        spriteHero.animations.add('wb', walkingBack);
        spriteHero.animations.add('wf', walkingFront);
    }
		
		

		
    function update() {
        // preguntamos directamente por la tecla
        if (arKey.isDown){
						//play(name, frameRate, loop, killOnComplete)
						spriteHero.animations.play('wb', 15, true);
            posY-=velY;
            spriteHero.y=posY;

        }else if (abKey.isDown){
						spriteHero.animations.play('wf', 15, true);
            posY+=velY;
            spriteHero.y=posY;
        }else if (izKey.isDown){
						spriteHero.animations.play('wf', 15, true);
            posX-=velX;
            spriteHero.x=posX;
        }else if (deKey.isDown){
						spriteHero.animations.play('wf', 15, true);
            posX+=velX;
            spriteHero.x=posX;
        }
				
				// Retorna true si la tecla se solto
				if ((game.input.keyboard.justReleased(Phaser.Keyboard.UP,500)) ||
					  (game.input.keyboard.justReleased(Phaser.Keyboard.DOWN,500)) ||
					  (game.input.keyboard.justReleased(Phaser.Keyboard.LEFT,500)) ||
					  (game.input.keyboard.justReleased(Phaser.Keyboard.RIGHT,500)) ){
						//stop(name, resetFrame)
						spriteHero.animations.stop('wf',true);// le da bola al booleano resetFrame?
				}
    }

};