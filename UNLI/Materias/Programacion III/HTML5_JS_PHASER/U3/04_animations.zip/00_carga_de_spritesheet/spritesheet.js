/* Estructura basica */


/*
 *
 * Documentacion para este script:
 *
 * AnimationManager:
 *
 * docs/Phaser.AnimationManager.html
 *
 * */

window.onload = function() {

    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });

    //es posible definir una tecla cualquiera, incluso las flechas

    var izKey;
    var deKey;
    //este arreglo dice los frames que vamos a utilizar en el spritesheet
		var caminando = [6,7,8,9,10,11];


    function preload() {

        //Vamos a cargar un spritesheet
        //parametros: id_nombre, URL, Frame_Width, Frame_Height, Nro_frames
				//18 frames
        //si en el PNG hay tantos frames como para cubrir la imagen entera, entonces no hace falta este ultimo parametro

        //170=1024/6 ; 246=739/3
				game.load.spritesheet('file', '../../assets/sprites/guyb1.png', 170, 246, 18);

        // Hay que definirlas una por una
        izKey = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        deKey = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);

    }



    var spriteHero;
    var posX=20; //posicion X del personaje
    var velX=10;  //velocidad X del personaje




    function create() {
				//creamos el spritesheet
				crearSprite();

    }



    function crearSprite() {
        //creamos el sprite
        spriteHero = game.add.sprite(posX, 200, 'file');
        //centramos el sprite para que al espejarlo sea con respecto el centroide
        spriteHero.anchor.set(0.5,0.5);
				//se escala es sprite
				spriteHero.scale.setTo(0.5, 0.5);
        //agregamos el spritesheet llamado "run"
				//se especifica el movimiento denominado caminando
				//add(name, frames, ... )
        spriteHero.animations.add('run', caminando);
				//play(name, frameRate, loop, killOnComplete)
        spriteHero.animations.play('run', 15, true);
    }
		
		

    function update() {
        // preguntamos directamente por la tecla
        if (izKey.isDown){
						spriteHero.scale.setTo(-0.5, 0.5);
            posX-=velX;
            spriteHero.x=posX;
        }else if (deKey.isDown){
						spriteHero.scale.setTo(0.5, 0.5);
            posX+=velX;
            spriteHero.x=posX;
        }

    }

};