


window.onload = function() {

    //(0)
    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });
    var Patricio;


    //(1)
    //var _idle = [0,1,2,3,4,5,6];

    //(2)
    var _idle;
    var _walk;
    var _jump;
    var _fall;
    var _run;

    //(4)
    var _Keys = [];
    var velX = 150;

    //(6)
    var velY = -450;

    //(7)
    var map;
    var layer;
    var layer1;
    var tile;


    //(8)
    var monedas;


    var Background;

    //(9)


    //(0)
    function preload() {


        //(1)
        game.load.atlas('atlas', '../../assets/sprites/patricio/spritesheet.png', '../../assets/sprites/patricio/sprites.json');


        //(4)
        _Keys[0] = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        _Keys[1] = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        _Keys[2] = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
        _Keys[3] = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);

        //(7)

        game.load.tilemap('map', '../../assets/tilemaps/maps/mapa_P3_1.json', null, Phaser.Tilemap.TILED_JSON);
        game.load.image('ground_1x1', '../../assets/tilemaps/tiles/ground_1x1.png');



        //(8)
        game.load.spritesheet('moneda', '../../assets/sprites/coin.png', 32, 32);


        game.load.image('background', '../../assets/pics/platformer_backdrop.png');

    }



//(0)
    function create() {


        Background = game.add.sprite(0, 0, 'background');
        Background.scale.set(4,3);//320 x 256


        Patricio = game.add.sprite(200, 200, 'atlas');
        Patricio.scale.set(1.5,1.5);
        Patricio.anchor.set(0.5,0.5);


        //(2)

        _idle = Phaser.Animation.generateFrameNames('idle_', 0, 6, '', 2);
        _jump = Phaser.Animation.generateFrameNames('jump_', 0, 4, '', 2);
        _walk = Phaser.Animation.generateFrameNames('walk_', 0, 9, '', 2);
        _run = Phaser.Animation.generateFrameNames('run_', 0, 8, '', 2);
        _fall = Phaser.Animation.generateFrameNames('fall_', 0, 1, '', 2);

        Patricio.animations.add('idle',_idle , 10, true);
        Patricio.animations.play('idle');

        Patricio.animations.add('walk',_walk , 10, true);
        Patricio.animations.add('jump',_jump , 10, false);


        //(3)
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.physics.arcade.gravity.y = 800;
        //habilito los cuerpos de los sprites que van a tener fisica
        game.physics.enable( Patricio);
        //bordes
        Patricio.body.collideWorldBounds = true;
        //elasticidad al borde (no deseable)
        //Patricio.body.bounce.y = 0.8;
        //podria agregarle aceleracion particular
        Patricio.body.gravity.y = 500;






        //(7)
        //agrego el tilemap (logico)
        map = game.add.tilemap('map');
        //agrego la imagen del tile
        tile = map.addTilesetImage('ground_1x1');

        //creo la capa de objetos
        layer = map.createLayer('piso');
        layer1 = map.createLayer('pared');

        // ajustamos el mundo a la capa de objeto
        layer.resizeWorld();

        //cuales son los tiles que van a colisionar, del 1 al 12
        map.setCollisionBetween(1,3);

        //la camara sigue
        game.camera.follow(Patricio);

		//traemos patricio al frente de todo
        Patricio.bringToTop();

        //(8)
        //grupo

        monedas = game.add.group();
        monedas.enableBody = true;
        monedas.physicsBodyType = Phaser.Physics.ARCADE;


        //createFromObjects(name, gid, key, frame, exists, autoCull, group, CustomClass, adjustY);

        //GID: fruta, 26
        map.createFromObjects('coin', 26, 'moneda', 0, true, false, monedas);

        //Que no le afecte la gravedad
        for(var i =0; i<monedas.length; i++){

            monedas.getAt(i).body.allowGravity = false;

        }




    }
    //(0)
    function update() {



        //(7)

        game.physics.arcade.collide(Patricio, layer);

        //(8)
        game.physics.arcade.collide(Patricio, monedas, juntaMoneda, null, this);





        //(4)
        Patricio.body.velocity.x = 0;


        if (_Keys[0].isDown) {
            Patricio.body.velocity.x = -velX;

            //(5)
            if(Patricio.scale.x>=0){
                    Patricio.scale.x*=-1;
            }

            //(-5)
            if(Patricio.body.onFloor())
                {Patricio.animations.play('walk');}


        }
        else {
            if (_Keys[2].isDown){
                Patricio.body.velocity.x = velX;

                //(5)
                if(Patricio.scale.x<0){
                    Patricio.scale.x*=-1;
                }
                if(Patricio.body.onFloor())
                    {Patricio.animations.play('walk');}
            }
            else{
                if(Patricio.body.onFloor()){
                    Patricio.animations.play('idle');
                }
            }

        }
            //(-5)


        //(6)
        if (_Keys[1].isDown && Patricio.body.onFloor()){

            Patricio.body.velocity.y = velY;
            Patricio.animations.stop();
            Patricio.animations.play('jump');


        }


    }


    function juntaMoneda(player ,moneda){



        //(8)
        moneda.kill();


    }

};