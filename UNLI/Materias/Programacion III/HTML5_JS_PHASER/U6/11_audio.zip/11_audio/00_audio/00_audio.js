// audio
// se reproduce el audio apenas carga la pagina
// se puede pausar y controlar el volumen de lo que se reproduce
// si se pasa encima de la estrella se reproduce otro sonido


/*
*
* Documentacion para este script:
*
* Class: Sound:
*
* docs/Phaser.Sound.html

* Class: SoundManager:
*
* docs/Phaser.SoundManager.html
*
* */

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, 'phaser-example', { preload: preload, create: create, render: render });

	function preload() {
		game.load.image('img0', '../../assets/sprites/cokecan.png');
		game.load.image('img1', '../../assets/games/starstruck/star2.png');
		// carga el archivo de audio
		// el 1er parametro es la key para identificar el sonido
		// el 2do parametro es un array conteniendo el mismo archivo audio pero en diferentes formatos
		// esto nos puede ser util si usamos Firefox ya que no soporta archivos mp3, solo usa ogg
		game.load.audio('efecto0', ['../../assets/audio/oedipus_wizball_highscore.mp3', '../../assets/audio/oedipus_wizball_highscore.ogg']);
		// si vamos a trabajar con un solo tipo de archivos, podemos simplificar pasando el array asi
		game.load.audio('efecto1', '../../assets/audio/SoundEffects/meow1.mp3');
	}
	

	var text;
	var music0;
	var music1;
	function create() {
		// fondo cyan
		game.stage.backgroundColor = '#0091cc';

		imagen0 = game.add.sprite(game.world.centerX, game.world.centerY, 'img0');
		imagen0.x-=(imagen0.width/2.0);
		
		//habilitamos eventos
		imagen0.inputEnabled = true;
		imagen0.events.onInputDown.add(clicks,this);
		
		imagen1 = game.add.sprite(game.world.centerX, 200, 'img1');
		imagen1.anchor.set(0.5,0.5);
		imagen1.scale.set(2.0,2.0);
		//habilitamos eventos
		imagen1.inputEnabled = true;
		imagen1.events.onInputOver.add(sobre,this);
		imagen1.events.onInputOut.add(salgo,this);
		
		// agregamos el audio al game
		music0 = game.add.audio('efecto0');
		// reproduce el sonido
		// play(marker, position, volume, loop, forceRestart)
		// volume: default 1
		// loop: default false
		music0.play('', 0, 0.75, true);
		
		// agregamos el otro audio al game
		music1 = game.add.audio('efecto1');
		
		game.input.onDown.add(cambiarVolumen, this);

		text = game.add.text(game.world.centerX, 15, 'music0:isPlaying', { fill: '#ffffff' });

	}
	

	function clicks(item){
		if(music0.isPlaying){ // isPlaying es true cuando el audio se encuentra en modo play
			music0.pause(); // pausa el audio
			text.text = 'music0:isPlaying->paused';
		}else if(music0.paused){ // paused es true cuando el audio esta en modo pause
			music0.resume(); // reanuda el audio
			text.text = 'music0:paused->isPlaying';
		}
		music0.volume += 0.1; // subimos el volumen porque esta en la mitad inferior, para compensar
	}
	
	
	function sobre(item){
		// volumen 0.9 y sin repeticion
		music1.play('', 0, 0.9, false);
		text.text = 'music1:isPlaying';
	}
	
	
	function salgo(item){
		text.text = '';
	}
	

	function cambiarVolumen(posicion){
		// si picamos en la mitad inferior bajamos el volumen
		// si picamos en la mitad superior subimos el volumen
		if (posicion.y < 300){
			// setea el volumen para este audio entre 0 y 1
			music0.volume += 0.1;
			if(music0.volume>=1.0){music0.volume=1.0}
			text.text = 'volume +';
		}else{
			music0.volume -= 0.1;
			if(music0.volume<=0.0){music0.volume=0.0}
			text.text = 'volume -';
		}
	}	
	

	function render() {
			// Sound debug info
			game.debug.soundInfo(music0, 20, 32);
	}
};