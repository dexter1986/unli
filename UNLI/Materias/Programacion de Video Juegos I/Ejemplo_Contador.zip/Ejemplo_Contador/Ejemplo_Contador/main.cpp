#include <SFML/Graphics.hpp>
#include <iostream>

//DECLARACION DE CONSTANTES
const int TIEMPO_JUEGO = 60; //En segundos


//DECLARACION DE VARIABLES
sf::RenderWindow window;
sf::Text textoContador;

//variable de instacia al reloj de SFML
sf::Clock reloj;

float tiempoInicio;
float tiempoFin;


//DECLARACION DE METODOS
void actualizarContador();
void dibujar();

//PUNTO DE ENTRADA
int main(){
	
    //Se crea la ventana principal del juego
	window.create(sf::VideoMode(800, 600), "Juego");

	//Texto de Contador
    sf::Font font;
    if (!font.loadFromFile("Recursos/Fuentes/arial.ttf"))
        return EXIT_FAILURE;
	
	textoContador.setFont(font);
	textoContador.setCharacterSize(60);

	
	//Asignar a tiempoInicio una unica vez, el tiempo actual + el tiempo de juego en segundos.
	tiempoInicio = reloj.getElapsedTime().asSeconds() + TIEMPO_JUEGO;

	//Detecci�n de eventos de SFML
    while (window.isOpen()) {

        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed){
                window.close();
			}

        }

		actualizarContador();

		//Limpia lo dibujado en ciclo anterior
	    window.clear();

		dibujar();

		//Se muestra en ventana,lo nuevo que se ha dibujado con window.draw
        window.display();
    }

    return 0;
}



void actualizarContador(){
	tiempoFin = reloj.getElapsedTime().asSeconds();//Asignar a tiempoFin, el tiempo actual en cada framerate
	
	int seconds = ((int)(tiempoInicio - tiempoFin));

	if(seconds >= 0){
		char buffer[20];
		sprintf(buffer, "Tiempo: %i", seconds);
		textoContador.setString(buffer);
	}else{
		textoContador.setString("El tiempo finaliz�.....");
	}

}

void dibujar(){

	window.draw(textoContador);

}