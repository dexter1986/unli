#include <SFML/Graphics.hpp>

class nodo {
public:
	nodo(int v, sf::Sprite sp, nodo *sig);
	nodo *siguiente;
	sf::Sprite spriteObj;
	int valor;
};