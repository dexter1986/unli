#include "nodo.h"	

nodo::nodo(int v, sf::Sprite sp, nodo *sig){
	valor = v;
	spriteObj = sp;
	siguiente = sig;
};