#include <SFML/Graphics.hpp>
#include "imageManager.h"
#include <iostream>

#include "lista.h"

using namespace std;

const int ANCHO_BLOQUE = 45;

sf::Texture bloqueTexture;

//Se crea la ventana principal del juego
sf::RenderWindow window(sf::VideoMode(800, 600), "Juego");



int main() {
	

	//Se crea una instancia del objeto imageManager
	imageManager img_mgr;

	//Se asigna la carpeta relativa donde se alojan nuestras im�genes
	img_mgr.addResourceDirectory("Recursos/imagenes/" );

	bloqueTexture = img_mgr.getImage( "bloque_pared.png");

	//////////////////////EJEMPLO USO DE LISTA/////////////////////////////

	lista *tren = new lista();

	//Se corrobora que la lista est� vacia, debe dar "1" = true
	cout << "La lista esta vacia?: " << tren->ListaVacia()  << endl;

	//Se insertan valores a la lista, los nodos se insertar�n en orden: 1->3->20->55
	//pero los sprites deben ordenarse segun la carga de los valores, en este ejemplo se
	//realiza un ordenamiento fijo.
	sf::Sprite spriteAux;
	spriteAux.setTexture(bloqueTexture);
	spriteAux.setPosition(ANCHO_BLOQUE*2,0);
	tren->Insertar(20, spriteAux);

	sf::Sprite spriteAux2;
	spriteAux2.setTexture(bloqueTexture);
	spriteAux2.setPosition(ANCHO_BLOQUE, 0);
	tren->Insertar(3, spriteAux2);
	
	sf::Sprite spriteAux3;
	spriteAux3.setTexture(bloqueTexture);
	spriteAux3.setPosition(ANCHO_BLOQUE*3, 0);
	tren->Insertar(55, spriteAux3);

	sf::Sprite spriteAux4;
	spriteAux4.setTexture(bloqueTexture);
	spriteAux4.setPosition(0, 0);
	tren->Insertar(1, spriteAux4);
	////////////////////////////////////


	//Se corrobora que la lista no est� vacia, debe dar "0" = falso
	cout << "La lista esta vacia?: " << tren->ListaVacia()  << endl;

	//Se busca nodo con valor existente
	nodo *nodoBusqueda = tren->Busqueda(46);
	if(nodoBusqueda)
		cout << "Se encontro el nodo con valor: " <<  nodoBusqueda->valor  << endl;
	else
		cout << "No se encontro el nodo con el valor buscado"  << endl;


	//Detecci�n de eventos de SFML
    while (window.isOpen()) {

        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed){
                window.close();
			}

			//A modo de ejemplo al presionar la tecla Space, se eliminan dos nodos de la lista
			if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Space ){
				//Se borran valores de la lista
				tren->Borrar(55);
				tren->Borrar(1);
			}
        }
		
		//Limpia lo dibujado en ciclo anterior
	    window.clear();

		// Dibujar bloques
		nodo *nodoAux = tren->primero;
		while(nodoAux){
			sf::Sprite sp = nodoAux->spriteObj;
			window.draw(sp);
			nodoAux = nodoAux->siguiente;
		}
		
		//Se muestra en ventana,lo nuevo que se ha dibujado con window.draw
        window.display();
	}


    return 0;

}