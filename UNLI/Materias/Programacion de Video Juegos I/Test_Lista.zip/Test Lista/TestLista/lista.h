#include "nodo.h"

class lista {
public:
	lista();
	~lista();

	//void Insertar(int v);
	void Insertar(int v, sf::Sprite sp);
	void Borrar(int v);
	nodo* lista::Busqueda(int v);

	bool ListaVacia();

	nodo *primero;

private:
	nodo *actual;

	void Siguiente();
	void Primero();
	void Ultimo();
};