﻿#include "lista.h"

lista::lista(){
	primero=actual=NULL;
}

lista::~lista(){
	
}

void lista::Siguiente(){
	if(actual)
		actual = actual->siguiente;
}

void lista::Primero() {
	actual = primero;
}

void lista::Ultimo() {
	actual = primero;
	if(!ListaVacia())
		while(actual->siguiente) 
			Siguiente();
}

nodo* lista::Busqueda(int v){
	nodo *nodoAux;
	nodoAux = primero;

	if(!ListaVacia())
		while(nodoAux->siguiente && nodoAux->valor != v)
			nodoAux = nodoAux->siguiente;

	//El nodo de retorno puede ser el nodo del valor buscado 
	//ó NULL si no se encuentra
	if(nodoAux->valor == v)
		return nodoAux;
	else
		return NULL;
}

void lista::Insertar(int v, sf::Sprite sp){
	nodo *anterior;
	// Si la lista está vacía
	if(ListaVacia() || primero->valor > v) {
		// Asignamos a lista un nievo nodo de valor v y
		// cuyo siguiente elemento es la lista actual
		primero = new nodo(v, sp,primero);
	} else {
		// Buscar el nodo de valor menor a v
		anterior = primero;
		// Avanzamos hasta el último elemento o hasta que el
		//siguiente tenga
		// un valor mayor que v
		while(anterior->siguiente && anterior->siguiente->valor <= v)
			anterior = anterior->siguiente;
		// Creamos un nuevo nodo después del nodo anterior, y cuyo
		//siguiente
		// es el siguiente del anterior
		anterior->siguiente = new nodo(v, sp,anterior->siguiente);
	}
}

void lista::Borrar(int v){
	nodo *anterior;
	nodo *nodoAux;
	nodoAux = primero;

	anterior = NULL;
	while(nodoAux && nodoAux->valor < v) {
		anterior = nodoAux;
		nodoAux = nodoAux->siguiente;
	}

	if(!nodoAux || nodoAux->valor != v) {
		return;
	}else { // Borrar el nodo
		if(!anterior) // Primer elemento
			primero = nodoAux->siguiente;
		else // un elemento cualquiera
			anterior->siguiente = nodoAux->siguiente;

		delete nodoAux;
	}
}

bool lista::ListaVacia(){
	if(primero==actual && actual==NULL)
		return true;
	return false;
}