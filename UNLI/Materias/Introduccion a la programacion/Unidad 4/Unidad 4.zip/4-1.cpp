#include<iostream>

using namespace std;

int altdisp(int distancia);
int posbomb(float tiempo,int &distancia);
bool esFecha(int anio,int mes,int dia);
void intercambio(char &p1,char &p2);

int main(int argc, char *argv[])
{
	return 0;
}
