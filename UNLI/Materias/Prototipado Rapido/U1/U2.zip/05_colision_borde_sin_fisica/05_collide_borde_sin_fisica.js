/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
*
* */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create , update:update });



    function preload() {

        game.load.image('diamante', '../../assets/sprites/diamond.png');

    }



    var diamond;
		var posX=20; //Posicion X del personaje
		var posY=20; //Posicion Y del personaje
		var velX=10;  //velocidad X del personaje
		var velY=10;  //velocidad Y del personaje
		var velAngular=0.5;
		var anchoSprite=30;



    function create() {


        //Creamos el sprite
        diamond = game.add.sprite(posX,posY, 'diamante');
				//centro
        diamond.anchor.set(0.5,0.5);
				

    }
		
		function update() {
		
			// hacemos rebotar el personaje contra los bordes
			posX+=velX;
			posY+=velY;
			diamond.x=posX;
			diamond.y=posY;
			diamond.rotation+=velAngular;

			if ((posX+(anchoSprite/2)) >= 800){
				velX*= -1;
			}else{
				if ((posX-(anchoSprite/2)) <= 0){
					velX*= -1;
				}
			}
			
			if ((posY-(anchoSprite/2)) <= 0){
				velY*= -1;
			}else{
				if ((posY+(anchoSprite/2)) >= 600){
					velY*= -1;		
				}
			}

		}
		
};