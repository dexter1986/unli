/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
*
* */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update: update });



    function preload() {



        game.load.image('conejo', '../../assets/sprites/bunny.png');

        game.load.image('hongo', '../../assets/sprites/mushroom2.png');



    }



    var Conejo;

    var Hongo;

    var text;



    function create() {



        Conejo = game.add.sprite(100, 200, 'conejo');
        Hongo = game.add.sprite(400, 400, 'hongo');


        //habilitamos los eventos
        Conejo.inputEnabled = true;
        Hongo.inputEnabled = true;

        //esta funcion habilita el drag para este objeto
        // otra forma es definirle una funcion al onDragStart y el onDragStop
        //pero como ya esta implementado, vamos a usarlo. Igualmetne lo veremos mas adelante

        Conejo.input.enableDrag();
        Hongo.input.enableDrag();


        // Asi defino un texto (posX, posY, texto, style[])

        text = game.add.text(game.world.centerX-90, 16, 'Tirame un drag', { fill: '#ffffff' });



    }



    function update() {

        // Asi chequeo si hay colision, viendo si hay sobreposicion
        //La funcion de interseccion lo que hace es comparar dos bounds (rectangulos)
        //Es una primita de Rectangle
        //En Phaser, todas las primitivas de colisione e intereseccion estan definidas en las figuras
        //geometricas, lo veremos mas adelante.


        //mas adelante veremos bien el tema de colisiones y bounds

        var boundA = Conejo.getBounds();
        var boundB = Hongo.getBounds();


        if (Phaser.Rectangle.intersects(boundA, boundB))

        {
            text.text = 'Colision: SI';

        }

        else

        {

            text.text = 'Colision: NO';

        }



    }




};