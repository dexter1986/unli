/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
* World
*
* docs/Phaser.World.html
*
* */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });



    function preload() {



        game.load.image('hongo', '../../assets/sprites/mushroom2.png');


    }



    function create() {


        nro_de_hongos =10;



        for (var i = 0; i < nro_de_hongos; i++)
        {


            //game.world.randomX devuelve un valor aleatorio entre 0 y ancho del CANVAS. Lo mismo para el randomY
            //si se sabe por anticipado el ancho y el alto de la pantalla, se puede obtener el mismo resultado de la siguiente manera
            //Math.random()*VALOR_MAX

            var Hongo = game.add.sprite(game.world.randomX, game.world.randomY, 'hongo');


            //Veremos eventos mas adelante, por el momento aceptar lo que dice


            //habilito eventos sobre el sprite
            Hongo.inputEnabled = true;


            //cursor de la manito
            Hongo.input.useHandCursor = true;


            //pongo una funcion al evento del click (o touch)
            //funcion, parametro
            Hongo.events.onInputDown.add(destoyIt, this);

        }



    }



    function destoyIt (HongoSprite) {


        //destruyo el srpite
        HongoSprite.destroy();

    }




};