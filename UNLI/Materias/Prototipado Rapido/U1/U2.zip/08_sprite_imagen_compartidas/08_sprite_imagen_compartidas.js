/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
*
* */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, 'e', { preload: preload, create: create });



    //Puede pasar que en el spritesheet haya muchos sprite para diferentes actores
    //Aqui hay un ejemplo de como descomponerlo


    function preload() {

        game.load.atlas('atlas', '../../assets/sprites/ball_map.png', '../../assets/sprites/ball_map.json');

        //pagina para hacer atlas
        //http://www.leshylabs.com/apps/sstool/

    }

    //arreglo
    var balls = [];



    function create() {


        balls[0] = game.add.sprite(64, 64, 'atlas');

        //nos fijamos en el atlas, cual es el nombre del frame que dice el json
        balls[0].frameName = 'sprite1';


        //Damos drag para hacerlo mas chulo
        balls[0].inputEnabled = true;
        balls[0].input.enableDrag();

        //para el resto hacemos un for

        for (var i = 1; i < 6 ; i++){

            balls[i] = game.add.sprite(game.world.randomX, game.world.randomY, 'atlas');
            //en JavaScript si a un string le sumamos un valor, este se concatena al string
            balls[i].frameName = 'sprite'+(i+1);

            //drag
            balls[i].inputEnabled = true;
            balls[i].input.enableDrag();

        }


    }



};