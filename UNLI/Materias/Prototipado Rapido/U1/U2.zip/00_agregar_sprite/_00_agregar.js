/* Estructura basica */

window.onload = function() {

	var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });

	// documetancion de Game
	// file:///C:/wamp/www/phaser/phaser-master/docs/Phaser.Game.html

	// Game es la funcion principal que crea el juego
	// parametros
	// new Game(width, height, renderer, parent, state, transparent, antialias, physicsConfig)

	// render: Phaser.AUTO autodetecta, Phaser.WEBGL, Phaser.CANVAS, Phaser.HEADLESS
	// parent: el ID del elemento HTML padre
	// state: Objeto, recibe como parametro las 4 funciones de estado elementales:

	// preload: aqui se carga todo antes de iniciar el juego
	// create: condicion inicial, creaci�n de los objetos
	// update: aqui se ejecutan instrucciones que necesitan ser leidas en cada ciclo
	// render: aqui se colocan las estructuras que necesitan ser dibujadas por el puntero de dibujo

	function preload () {

		// primitiva para cargar assets (audio, image, etc)
		game.load.image('cara', '../../assets/sprites/cara_img.png');

	}

	function create () {
	
		// agregamos la imagen al game
		// parametros x,y,imagen
		var image = game.add.sprite(game.world.centerX, game.world.centerY, 'cara');
		// la anclamos al centro
		image.anchor.setTo(0.5, 0.5);

	}

};