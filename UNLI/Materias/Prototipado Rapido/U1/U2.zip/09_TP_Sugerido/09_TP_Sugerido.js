/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
*
* */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });




    function preload() {



       //cargamos el sprite, el frame tiene 37x45, son 18 frames

        game.load.spritesheet('mummy', '../../assets/sprites/metalslug_mummy37x45.png', 37, 45, 18);

        //Vamos a poner honguitos contra quienes chocarse
        game.load.image('hongo', '../../assets/sprites/mushroom2.png');

    }


    //sin el var, son variables globales
    var Hongos = [];
    var Mummy;



    function create() {


        crearMomia();

        Hongos[0] = game.add.sprite(200, 200, 'hongo');
        Hongos[1] = game.add.sprite(550, 400, 'hongo');
        Hongos[2] = game.add.sprite(400, 250, 'hongo');
        Hongos[3] = game.add.sprite(100, 350, 'hongo');


    }



    function crearMomia() {


        //aleatorio entre 1 y 200
        var Y =Math.floor((Math.random()*200)+1);
        //la agregamos
        Mummy = game.add.sprite(game.world.randomX, Y, 'mummy');
        //le agregamos la animacion de caminar (si aca tuvieramos otra, podemos definir los indices de cada una)
        Mummy.animations.add('walk');
        //y que camine nomas
        Mummy.animations.play('walk',20,true);
        //le habilitamos los eventos y luego el drag
        Mummy.inputEnabled = true;
        Mummy.input.enableDrag();
        //ahora lo vamos a hacer caer con fisica
        game.physics.enable(Mummy, Phaser.Physics.ARCADE);
        Mummy.body.velocity.setTo((Math.random()*50)+30, 0);
        Mummy.body.collideWorldBounds = true;
        Mummy.body.gravity.set(0, 180);
        Mummy.body.bounce.setTo(1,1);


    }



    function update(){






        for(var i = 0;i<4;i++){

            var boundA = Hongos[i].getBounds();
            var boundB = Mummy.getBounds();

            if (Phaser.Rectangle.intersects(boundA, boundB)){

                Mummy.destroy();
                crearMomia();

                break;

            }

        }

    }



};