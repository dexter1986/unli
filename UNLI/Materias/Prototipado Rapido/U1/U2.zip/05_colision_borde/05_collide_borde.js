/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
*
* */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create  });



    function preload() {

        game.load.image('diamante', '../../assets/sprites/diamond.png');

    }



    var diamond;




    function create() {


        //Creamos el sprite
        diamond = game.add.sprite(100,100, 'diamante');

        //Aqui definiremos la fisica, veremos mas adelante, no se preocupen

        //habilito el cuerpo fisico(por defecto siempre es ARCADE)
        game.physics.enable(diamond, Phaser.Physics.ARCADE);


        //le doy la velocidad :px/s
        diamond.body.velocity.setTo(200, 200);

        //habilito el choque contra los bordes de la pantalla
        diamond.body.collideWorldBounds = true;

        //energia de choque contra las bordes (1:100%, 0:0%)
        diamond.body.bounce.setTo(0.5,0.5);

        //gravedad: px/s
        diamond.body.gravity.set(0, 180);




    }




};