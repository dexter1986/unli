/* Estructura basica */


/*
 *
 * Documentacion para este script:
 *
 * AnimationManager:
 *
 * docs/Phaser.AnimationManager.html
 *
 * */



window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });




    function preload() {



        /*Vamos a cargar un spritesheet*/
        //  37x45 el tananio de cada frame


        //parametros: id_nombre, URL, Frame_Width, Frame_Height, Nro_frames

        // si en el PNG hay tantos frames como para cubrir la imagen entera, entonces no hace falta este ultimo parametro

        game.load.spritesheet('mummy', '../../assets/sprites/metalslug_mummy37x45.png', 37, 45, 18);



    }



    function create() {



        crearMomia();



    }



    function crearMomia() {



        var mummy = game.add.sprite(200, 200, 'mummy');

        mummy.scale.setTo(3, 3);




        //agregamos una animacion con un "nombre_id"

        // par: add(name, frames, frameRate, loop, useNumericIndex)


        //solo tenemos una, asi que llamamos solo al primer parametro
        mummy.animations.add('walk');



        //

        //play(name, frameRate, loop, killOnComplete)

        //name: Nombre_id de cuando se agrego

        //frameRate: frame por segundo
        //loop
        // kill_on_finished: si loop es false, destruir objeto padre cuando termina




        mummy.animations.play('walk',20,true);



    }



};