/* Estructura basica */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, render: render });



    function preload() {




        //(x,y,xEnd,yEnd)

        //Aqui se dibujan las lineas del cuadrado (mas adelante veremos las geometrias)
        sup = new Phaser.Line(200, 200, 400, 200);
        iz = new Phaser.Line(200, 200, 200, 400);
        de = new Phaser.Line(400, 200, 400, 400);
        inf = new Phaser.Line(200, 400, 400, 400);



        //game.load.image(nombre_id,URL_asset)
        game.load.image('mushroom', '../../assets/sprites/mushroom2.png');


    }

    function create() {


        // game.add.sprite(posX,posY,nombre_id)

        //Por defecto siempre se posiciones en el 0,0 del sprite, o sea, en la esq sup izq

        //vertice supIz
        var supIz = game.add.sprite(200, 200, 'mushroom');

        //vert sup der
        var supDe = game.add.sprite(400, 200, 'mushroom');

        // vert inf der
        var infDe = game.add.sprite(400, 400, 'mushroom');

        // vert inf iz
        var infIz = game.add.sprite(200, 400, 'mushroom');



        /* las anclas permiten centrar nuestro sprite. Descomentar estas lineas para ver*/

/*

    // Las anclas estan normalizadas entre 0 y 1, si ponemos 0,5 en sprite se centrara.
    //aunque la logica dice que deberia ser -0.5, ya que el desplazamiento es negativo,
     //pero esta hecho asi para facilitar la comprension

        supIz.anchor.set(0.5,0.5);
        supDe.anchor.set(0.5,0.5);
        infDe.anchor.set(0.5,0.5);
        infIz.anchor.set(0.5,0.5);


        //Si las ancas son negativas, el desplazamiento es hacia el otro lado (sentido positivo). Tarea: probar eso.
 */

    }

    function render(){

        game.debug.geom(sup,'#ff0000');
        game.debug.geom(iz,'#ff0000');
        game.debug.geom(de,'#ff0000');
        game.debug.geom(inf,'#ff0000');

    }

};