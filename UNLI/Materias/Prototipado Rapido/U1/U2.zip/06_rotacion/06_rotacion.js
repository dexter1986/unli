/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
*
* */

window.onload = function() {




    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create, update:update, render:render});



    function preload() {



        //game.load.image('flecha', '../../assets/sprites/arrow.png');
		game.load.image('flecha', 'arrow.png');



    }

        var Flecha;


    function create() {



        Flecha = game.add.sprite(game.world.centerX, game.world.centerY, 'flecha');

        //centro
        Flecha.anchor.set(0.5,0.5);
        //agrando
        Flecha.scale.set(4,4);

    }



    function update() {



        //  si estamos mas lejos de 8 pixeles

        //distancia a un punto:
        // |(x2 - x1)^2 - (y2 - y1)^2|

        //por lo cual seria

      /*  if(Math.abs(
            Math.pow(game.input.activePointer.x - Flecha.x,2) -
            Math.pow(game.input.activePointer.y - Flecha.y,2)
        ) >8){
      */
        // por suerte, si les parece muy complejo ya esta implementado en el objeto physics, tranqui lo veremos mas adelante
        //sino, pueden descomentar el if de arriba y ver como funciona

        if (game.physics.arcade.distanceToPointer(Flecha, game.input.activePointer) > 8){

            var angle= Math.atan2(
                    game.input.y - game.world.centerY,
                    game.input.x - game.world.centerX);


            // rotacion

            Flecha.rotation = angle;


        }



    }


    function render () {

        game.debug.inputInfo(32, 32);



    }



};