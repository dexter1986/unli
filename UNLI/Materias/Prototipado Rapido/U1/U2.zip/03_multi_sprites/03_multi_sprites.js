/* Estructura basica */


/*
*
* Documentacion para este script:
*
* AnimationManager:
*
* docs/Phaser.AnimationManager.html
*
* */

window.onload = function() {


    var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });





    function preload() {



        /*Vamos a cargar un spritesheet*/
        //  169x229 el tananio de cada frame


        //parametros: id_nombre, URL, Frame_Width, Frame_Height, Nro_frames



        game.load.spritesheet('guybrush', '../../assets/sprites/guyb1.png', 169, 246);



    }



    function create() {



        Mono_de_3_cabezas();



    }



    function Mono_de_3_cabezas() {



        var GuyWalking1 = game.add.sprite(100, 100, 'guybrush');
        var GuyWalking2 = game.add.sprite(400, 100, 'guybrush');
        var GuyTalking = game.add.sprite(400, 350, 'guybrush');


        // par: add(name, frames, frameRate, loop, useNumericIndex)


        GuyWalking1.animations.add('frente',[0,1,2,3,4,5],10,true);
        GuyWalking2.animations.add('costado',[6,7,8,9,10,11],10,true);
        GuyTalking.animations.add('hablar',[12,13,14,15,16,17],10,true);

        //

        //play(name, frameRate, loop, killOnComplete)



        //name: Nombre_id de cuando se agrego
        //frameRate: frame por segundo
        //loop
        // kill_on_finished: si loop es false, destruir objeto padre cuando termina

        GuyWalking1.animations.play('frente');
        GuyWalking2.animations.play('costado');
        GuyTalking.animations.play('hablar');




    }



};