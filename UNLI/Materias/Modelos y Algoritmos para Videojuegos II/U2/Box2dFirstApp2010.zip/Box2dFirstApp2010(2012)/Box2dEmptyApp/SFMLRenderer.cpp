#include "StdAfx.h"
#include "SFMLRenderer.h"


SFMLRenderer::SFMLRenderer(RenderWindow *window)
{
	wnd=window;
}


SFMLRenderer::~SFMLRenderer(void)
{
}


void SFMLRenderer::DrawPolygon(const b2Vec2* vertices, int32 vertexCount, const b2Color& color){

	Shape poligono;
	poligono.EnableFill(false);

	for(int i=0;i<vertexCount;++i){
		poligono.AddPoint(vertices[i].x, vertices[i].y,  box2d2SFMLColor(color), box2d2SFMLColor(color));	
	}
	wnd->Draw(poligono);


}

void SFMLRenderer::DrawSolidPolygon(const b2Vec2* vertices, int32 vertexCount, const b2Color& color){

	Shape poligono;
	poligono.EnableFill(true);

	for(int i=0;i<vertexCount;++i){
		poligono.AddPoint(vertices[i].x, vertices[i].y, box2d2SFMLColor(color) ,box2d2SFMLColor(color));	
	}
	wnd->Draw(poligono);

}

void SFMLRenderer::DrawCircle(const b2Vec2& center, float32 radius, const b2Color& color){

	sf::Shape circulo = Shape::Circle(center.x, center.y, radius,  box2d2SFMLColor(color),1.0f,  box2d2SFMLColor(color));
	circulo.EnableFill(false);
	wnd->Draw(circulo);

}

void SFMLRenderer::DrawSolidCircle(const b2Vec2& center, float32 radius, const b2Vec2& axis, const b2Color& color){

	sf::Shape circulo = Shape::Circle(center.x, center.y, radius,  box2d2SFMLColor(color),0.1f, box2d2SFMLColor(color));
	circulo.EnableFill(true);
	wnd->Draw(circulo);

}

void SFMLRenderer::DrawSegment(const b2Vec2& p1, const b2Vec2& p2, const b2Color& color){
	
	sf::Shape Line   = Shape::Line(p1.x, p1.y, p2.x, p2.y, 0.5f,  box2d2SFMLColor(color));
	wnd->Draw(Line);
	
}

void SFMLRenderer::DrawTransform(const b2Transform& xf){

	b2Vec2 p1 = xf.position, p2;
	const float32 k_axisScale = 20.0f;
	p2 = p1 + k_axisScale * xf.R.col1;
	glVertex2f(p2.x, p2.y);
	sf::Shape LineX=Shape::Line(p1.x,p1.y,p2.x,p2.y,0.5f,Color::Red);
	wnd->Draw(LineX);
	p2 = p1 + k_axisScale * xf.R.col2;
	sf::Shape LineY=Shape::Line(p1.x,p1.y,p2.x,p2.y,0.5f,Color::Green);
	wnd->Draw(LineY);
}

Color SFMLRenderer::box2d2SFMLColor(const b2Color& _color){
	
	UINT8 R,G,B;
	R=(UINT8)(_color.r*255);
	G=(UINT8)(_color.g*255);
	B=(UINT8)(_color.b*255);

	return Color(R,G,B);

}