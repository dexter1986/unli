#include "StdAfx.h"
#include "Game.h"
#include "ContactListener.h"
#include "Box2DHelper.h"

Game::Game(int ancho, int alto,std::string titulo)
{
	wnd= new RenderWindow(VideoMode(ancho,alto),titulo);
	wnd->Show(true);
	fps=60;
	wnd->SetFramerateLimit(fps);
	frameTime=1.0f/fps;
	SetZoom();
	InitPhysics();
}


void Game::Loop(){

	
	while(wnd->IsOpened()){
		
		wnd->Clear(clearColor);
		DoEvents();
		CheckCollitions();
		UpdatePhysics();
		DrawGame();
		wnd->Display();
	
	}

}

void Game::UpdatePhysics(){
	
	phyWorld->Step(frameTime,8,8);
	phyWorld->ClearForces();
	phyWorld->DrawDebugData();
}

void Game::DrawGame(){



}
void Game::DoEvents(){

	Event evt;
	while(wnd->GetEvent(evt)){
	
		switch(evt.Type){
			case Event::Closed:
				wnd->Close();
				break;
			case Event::MouseButtonPressed:
				b2Body *body=Box2DHelper::CreateTriangularDynamicBody(phyWorld,b2Vec2(0.0f,0.0f),10.0f,1.0f,4.0f,0.1f);
				//transformamos las coordenadas segun la vista activa
				Vector2f pos=wnd->ConvertCoords(evt.MouseButton.X,evt.MouseButton.Y);
				body->SetTransform(b2Vec2(pos.x,pos.y),0.0f);
				break;
		}

		
	}

	//movemos el cuerpo
	const sf::Input& Input = wnd->GetInput();
	controlBody->SetAwake(true);
	if(Input.IsKeyDown(Key::Left)) 
		controlBody->SetLinearVelocity(b2Vec2 (-50.0f, 0.0f));
	if(Input.IsKeyDown(Key::Right)) 
		controlBody->SetLinearVelocity(b2Vec2 (50.0f, 0.0f));
	if(Input.IsKeyDown(Key::Down)) 
		controlBody->SetLinearVelocity(b2Vec2 (0.0f, 50.0f));
	if(Input.IsKeyDown(Key::Up)) 
		controlBody->SetLinearVelocity(b2Vec2 (0.0f, -50.0f));
		



}

void Game::CheckCollitions(){

	//veremos mas adelante

}

//Definimos el area del mundo que veremos en nuestro juego
//Box2D tiene problemas para simular magnitudes muy grandes
void Game::SetZoom(){

	View &v=wnd->GetDefaultView(); //obtenemos la camara por defecto
	//definimos el area visible
	FloatRect area(0.0f,0.0f,100.0f,100.0f);
	v.SetFromRect(area);
	

}
void Game::InitPhysics(){

	//inicializamos el mundo con la gravedad por defecto
	phyWorld= new b2World(b2Vec2(0.0f,9.8f) ,true);
	
	//MyContactListener* l= new MyContactListener();
	//phyWorld->SetContactListener(l);
	//Creamos el renderer de debug y le seteamos las banderas para que dibuje TODO
	debugRender= new SFMLRenderer(wnd);
	debugRender->SetFlags(MAXUINT32);
	phyWorld->SetDebugDraw(debugRender);


	//creamos un piso y paredes
	b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld,100,10);
	groundBody->SetTransform(b2Vec2(50.0f,100.0f),0.0f);

	b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld,10,100);
	leftWallBody->SetTransform(b2Vec2(0.0f,50.0f),0.0f);

	b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld,10,100);
	rightWallBody->SetTransform(b2Vec2(100.0f,50.0f),0.0f);
	
	//Creamos un c�rculo que controlaremos con el teclado
	controlBody= Box2DHelper::CreateCircularDynamicBody(phyWorld,5,1.0f,0.5,0.1f);
	controlBody->SetTransform(b2Vec2(50.0f,50.0f),0.0f);
		

}


Game::~Game(void)
{
}
