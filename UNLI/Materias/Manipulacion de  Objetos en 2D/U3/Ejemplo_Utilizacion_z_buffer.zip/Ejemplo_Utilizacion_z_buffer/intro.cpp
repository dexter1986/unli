// Ejemplo Tanque
// 

#include <iostream> // cout
#include <cstdlib> // exit
#include <cmath> // fabs
#include <fstream> // file io
#include <list>
#include <GL/glut.h>

#include "Uglyfont.h"

using namespace std;

//------------------------------------------------------------
// variables globales
int
  w=800,h=600; // tama�o inicial de la ventana

int EnemigoX=50,EnemigoY=50,Energia=100;
  
double 
  TanqueX=400, 
  TanqueY=300, 
  TanqueAng=0, 
  ArmaAng=0,
  ArmaTamanio=0;

const double PI=4*atan(1.0);
bool cl_info=true; // informa por la linea de comandos
bool blend=true;      // transparencias
float
  fondo[]={0.4f,0.9f,0.4f,1.f};   // color de fondo

static int AngLineaRadar=0; // angulo de rotacion de linea del radar

// Aqui definimos el valor de z que utilizaremos para dibujar cada parte
// Los valores mayores quedan encima del resto

const double 
  zPISO=-0.5,
  zORUGA=0.2,
  zTANQUE=0.3,
  zFARO=0.4,
  zTORRE=0.5,
  zPROYECTIL=0.6,
  zCANON=0.7,
  zPARED=0.1,
  zTECHO=0.8,
  zRADAR=0.95;

//============================================================
class Bala {
private:
  double x;
  double y;
  double incrementox;
  double incrementoy;
public:
  Bala(double posX, double posY, double incX, double incY) : x(posX), y(posY), incrementox(incX), incrementoy(incY) {}
  bool Update() {
    x+=incrementox;
    y+=incrementoy;
    //Me fijo si hay colision de la bala con una torre enemiga
    if( fabs(x-EnemigoX)+fabs(y-EnemigoY) < 50 ) {
      Energia-=10;
      return true;
    }
    //Si esta fuera de la pantalla, elimino la bala
    return ( x > w || x < 0 || y > h || y < 0 );
  }
  void Draw() {
    glVertex2d(x,y);
  }
};

list<Bala> proyectil;

void print_text_color(string cadena, int x, int y, int espacio=10, float red=0.0, float green=0.0, float blue=0.0) {
  glColor3f(red,green,blue);
  for(unsigned int i=0; i < cadena.size(); i++) {
    glRasterPos2i( x + i*espacio, y );
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10,(int)cadena[i]);//GLUT_BITMAP_9_BY_15//GLUT_BITMAP_TIMES_ROMAN_10
  }
}

// Dibuja el canion
void DibujarArma() {
  glColor3f(0.2f,0.45f,0.0f);
  
  glPushMatrix();
  glTranslated(0,0,zCANON);
  
  glBegin(GL_QUADS);
  glVertex2d(-6.0,0.0);
  glVertex2d(6.0,0.0);
  glVertex2d(6.0,45.0);
  glVertex2d(-6.0,45.0);
  glEnd();
  
  glPopMatrix();
}

// La torre tiene diametro 40
void DibujarTorre() {
  glColor3f(0.2f,0.4f,0.0f);
  
  glPushMatrix();
  glTranslated(0,0,zTORRE);

  GLdouble baseRadius=40;
  int lod=30;
  GLint slices=lod, stacks=lod;  
  GLUquadricObj *q=gluNewQuadric();  
  // GLU_FILL, GLU_LINE, GLU_POINT or GLU_SILHOUETTE
  gluQuadricDrawStyle(q,GLU_FILL);
  gluDisk(q,0,baseRadius,slices,stacks);  
  gluDeleteQuadric(q);
  
  glColor3f(0.0f,0.1f,0.0f); 
  glPointSize(2);
  glBegin(GL_POINTS);
  for(double x=0; x<2*PI; x+=0.4) 
    glVertex2d(40.0*0.8*cos(x),40.0*0.8*sin(x));
  glEnd();
  glPopMatrix();
  
  glPushMatrix();
  glScaled(1.0,2.0+(ArmaTamanio*0.1),1.0);//glScaled(1.0,2.0,1.0);
  DibujarArma();
  glPopMatrix();
}

void DibujarFaro() {
  glColor3f(0.9,0.8,0.05);
  
  glPushMatrix();
  glTranslated(0,0,zFARO);

  glBegin(GL_QUADS);
    glVertex2d(0,0);
    glVertex2d(15,0);
    glVertex2d(15,10);
    glVertex2d(0,10);
    
    glColor4f(0.9,0.8,0.05,0);
    glVertex2d(-20,60);
    glColor4f(0.9,0.8,0.05,0);
    glVertex2d(35,60);
    glColor4f(0.9,0.8,0.05,0.8);
    glVertex2d(15,10);
    glColor4f(0.9,0.8,0.05,0.8);
    glVertex2d(0,10);
  glEnd();
  
  glPushMatrix();
  glTranslatef(7.5f,7.5f, 0.0f);  
  GLdouble baseRadius=7.5;
  int lod=30;
  GLint slices=lod, stacks=lod;  
  GLUquadricObj *q=gluNewQuadric();
  gluQuadricDrawStyle(q,GLU_FILL);
  gluDisk(q,0,baseRadius,slices,stacks);  
  gluDeleteQuadric(q);
  glPopMatrix();
  
  glPopMatrix();
}

// La ogura del tanque mide 10 x 150
void DibujarOruga() {
  glColor3f(0.4f,0.4f,0.4f);
  
  glPushMatrix();
  glTranslated(0,0,zORUGA);
  
  glBegin(GL_QUADS);
  glVertex2d(5,75);
  glVertex2d(-5,75);
  glVertex2d(-5,-75);
  glVertex2d(5,-75);
  glEnd();
  
  glPopMatrix();
  
}

// El cuerpo del tanque mide 80 x 140
void DibujarCuerpo() {
  glColor3f(0.002f,0.29f,0.001f);
  
  glPushMatrix();
  glTranslated(0,0,zTANQUE);
  
  glBegin(GL_QUADS);
  glVertex2d(40,70);
  glVertex2d(-40,70);
  glVertex2d(-40,-70);
  glVertex2d(40,-70);
  glEnd();
  
  glColor3f(0.001f,0.1f,0.001f);
  glLineWidth(3.0);
  glBegin(GL_LINES);
  glVertex2i(30,-55); glVertex2i(15,-55);
  glVertex2i(30,-60); glVertex2i(15,-60);
  glVertex2i(-15,-55); glVertex2i(-30,-55);
  glVertex2i(-15,-60); glVertex2i(-30,-60);
  glVertex2i(40,70); glVertex2i(-40,70);
  glEnd();  
  glLineWidth(1.0);  

  glPopMatrix();
}

void DibujarTanque() {
  glPushMatrix();// inicio push1

  // Posiciona y rota el tanque en el modelo
  glTranslated(TanqueX,TanqueY,0);
  // Se rota el tanque un angulo TanqueAng respecto del eje Z en sentido antihorario
  glRotated(TanqueAng,0,0,1);  

  DibujarCuerpo();

  glPushMatrix();
  // Posiciona la oruga derecha
  glTranslatef(45.0f,0.0f, 0.0f);
  DibujarOruga();
  glPopMatrix();
  
  glPushMatrix();
  // Posiciona la oruga izquierda
  glTranslatef(-45.0f,0.0f, 0.0f);
  DibujarOruga();
  glPopMatrix();

  glPushMatrix();
  // Posiciona y rota la torre 
  //glTranslated(0,-20,0);//Probar de descomentar esta linea para desplazar torre
  glRotated(ArmaAng,0,0,1);
  DibujarTorre();
  glPopMatrix();
  
  glPopMatrix();// fin push1
}

void DibujarPared() {
  glColor3f(0.01f,0.01f,0.01f);
  
  glPushMatrix();
  glTranslated(0,0,zPARED);

  glLineWidth(5.0);
  glBegin(GL_LINES);
  glVertex2i(300,400); glVertex2i(300,200);
  glVertex2i(300,200); glVertex2i(500,200);
  glVertex2i(500,200); glVertex2i(500,400);
  glEnd();
  
  glPopMatrix();
}

void DibujarRadar() {
  
  //Las siguientes dos traslaciones se pueden combinar en una sola linea (ademas la primera no hace nada)
  //pero para que se entienda la idea de usar z para definir el orden de dibujado dejamos las dos lineas
  glPushMatrix();
  glTranslated(0,0,zRADAR);

  glPushMatrix();
  glTranslatef (700, 500, 0.0);
  glColor4f(0.3f,0.3f,0.3f,1.0f);//glColor3f(0.8,0.5,0.1);//(0.0,0.0,0.0);
  glPointSize(1);
  GLUquadricObj *q=gluNewQuadric();
  gluQuadricDrawStyle(q,GLU_FILL);//GLU_POINT//GLU_FILL
  gluDisk(q,85,90,30,30);//gluDisk(q,0,baseRadius,slices,stacks);  
  
  glColor4f(0,0,1,1.0f);
  gluQuadricDrawStyle(q,GLU_FILL);//GLU_POINT//GLU_FILL
  gluDisk(q,0,90,30,30);//gluDisk(q,0,baseRadius,slices,stacks);  
  gluDeleteQuadric(q);
  
  glPopMatrix();
  
  //linea
  glPushMatrix();
  glTranslatef (700, 500, 0.0);
  glRotatef (AngLineaRadar, 0.0, 0.0, -1.0);
  glColor3f(1.0f,0.0f,0.0f);//glColor3ub(1,245,0);
  glLineWidth(3);//glLineWidth(1.0);
  glBegin(GL_LINES);
  glVertex2i(0,0); glVertex2i(85,0);//glVertex2f(0.f,0.f); glVertex2f(0.f,50.f);
  glEnd();
  glPopMatrix();
  
  glPopMatrix();
}

void DibujarPiso() {
  glPushMatrix();
  glTranslated(0,0,zPISO);

  glColor3f(0.23f,0.20f,0.01f); 
  glBegin(GL_QUADS);
  glVertex3f(0,0,0);
  glVertex3f(w,0,0);
  glVertex3f(w,h,0);
  glVertex3f(0,h,0);  
  glEnd();
  
  glPopMatrix();
}

void DibujarEnemigo() {
  glPushMatrix();
  glTranslated(0,0,zTANQUE);
 
  glPushMatrix();
  glTranslated(EnemigoX,EnemigoY, 0 );
  glColor3f(0.1,0.2,0.1);  
  GLdouble baseRadius=40;
  int lod=30;
  GLint slices=lod, stacks=lod;  
  GLUquadricObj *q=gluNewQuadric();
  gluQuadricDrawStyle(q,GLU_FILL);
  gluDisk(q,0,baseRadius,slices,stacks);  
  gluDeleteQuadric(q);  
  glColor3f(0,0.1,0); 
  glPointSize(2);
  glBegin(GL_POINTS);
  for(double x=0; x<2*PI; x+=0.4) 
    glVertex2d(40.0*0.8*cos(x),40.0*0.8*sin(x));
  glEnd();  
  glPopMatrix();
  
  glPopMatrix();
}

void DibujarProyectiles() {
  glPushMatrix();
  glTranslated(0,0,zPROYECTIL);
 
  list<Bala>::iterator p=proyectil.begin();
  glPointSize(8);
  glColor3b(250,250,250);
  glBegin(GL_POINTS);
  while( p != proyectil.end() ) {
    p->Draw();
    p++;
  }
  glEnd();
  
  glPopMatrix();
}
//============================================================
// callbacks

//------------------------------------------------------------

// arma un un nuevo buffer (back) y reemplaza el framebuffer
void Display_cb() {
  // arma el back-buffer
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);// rellena con color de fondo
 
  DibujarTanque(); 
  
  DibujarRadar();
  
  DibujarPared();
  
  DibujarEnemigo();

  DibujarProyectiles();
  
  DibujarPiso();
  
  glutSwapBuffers(); // lo manda al monitor
  
  // chequea errores
  int errornum=glGetError();
  while(errornum!=GL_NO_ERROR){
    if (cl_info){
      if(errornum==GL_INVALID_ENUM)
        cout << "GL_INVALID_ENUM" << endl;
      else if(errornum==GL_INVALID_VALUE)
        cout << "GL_INVALID_VALUE" << endl;
      else if (errornum==GL_INVALID_OPERATION)
        cout << "GL_INVALID_OPERATION" << endl;
      else if (errornum==GL_STACK_OVERFLOW)
        cout << "GL_STACK_OVERFLOW" << endl;
      else if (errornum==GL_STACK_UNDERFLOW)
        cout << "GL_STACK_UNDERFLOW" << endl;
      else if (errornum==GL_OUT_OF_MEMORY)
        cout << "GL_OUT_OF_MEMORY" << endl;
    }
    errornum=glGetError();
  }
}

void Idle_cb() {
  static unsigned int lt=0;
  int dt = glutGet(GLUT_ELAPSED_TIME) - lt;
  if(dt > 60) {
    lt = glutGet(GLUT_ELAPSED_TIME);
    AngLineaRadar=(AngLineaRadar+2)%360;
    
    //Actualizamos las posiciones de los proyectiles
    list<Bala>::iterator p = proyectil.begin();
    while( p != proyectil.end() ) {
      //Si esta fuera del mapa o impacta con el enemigo eliminamos el proyectil
      if( p->Update() )
        p = proyectil.erase(p);
      else
        p++;
    }
    // si hubo 10 impactos al enemigo se sale del juego
    if( Energia<1 ) exit(EXIT_SUCCESS);
    
    glutPostRedisplay();
  }
}

//------------------------------------------------------------
// Maneja cambios de ancho y alto de la ventana
void Reshape_cb(int width, int height){
  // cout << "reshape " << width << "x" << height << endl;
  if (!width||!height) return; // minimizado ==> nada
  w=width; h=height;
  glViewport(0,0,w,h); // regi�n donde se dibuja (toda la ventana)
  // rehace la matriz de proyecci�n (la porcion de espacio visible)
  glMatrixMode(GL_PROJECTION);  glLoadIdentity();
  glOrtho(0,w,0,h,-1,1); // unidades = pixeles
  // las operaciones subsiguientes se aplican a la matriz de modelado GL_MODELVIEW
  glMatrixMode(GL_MODELVIEW);
  glutPostRedisplay(); // avisa que se debe redibujar
}

//------------------------------------------------------------
// Teclado

// Maneja pulsaciones del teclado (ASCII keys)
// x,y posicion del mouse cuando se teclea (aqui no importan)
void Keyboard_cb(unsigned char key,int x,int y) {
  // Convierte TanqueAng de grados a radianes
  double ang=TanqueAng*PI/180.0;  
  double ang3;
  switch(key){
  case 'w':
  case 'W':
    // double sin(double ang); // Calcula el seno de ang medido en radianes
    TanqueX-=5*sin(ang);
    TanqueY+=5*cos(ang);
    glutPostRedisplay();
    break;
  case 's':
  case 'S':
    TanqueX+=5*sin(ang);
    TanqueY-=5*cos(ang);
    glutPostRedisplay();
    break;
  case 'a':
  case 'A':
    TanqueAng+=2;
    glutPostRedisplay();
    break;
  case 'd':
  case 'D':
    TanqueAng-=2;
    glutPostRedisplay();
    break;
  case 'o':
  case 'O':
    ArmaAng+=2;
    glutPostRedisplay();
    break;
  case 'p':
  case 'P':
    ArmaAng-=2;
    glutPostRedisplay();
    break;
  case 'k':
  case 'K':
    if(ArmaTamanio>-3) ArmaTamanio-=1;
    glutPostRedisplay();
    break;
  case 'l':
  case 'L':
    if(ArmaTamanio<5) ArmaTamanio+=1;
    glutPostRedisplay();
    break;
  case 't': case 'T': // transparencia
    blend=!blend;
    if (blend){
      glEnable(GL_BLEND);
      if (cl_info) cout << "Transparencia" << endl;
    }
    else {
      glDisable(GL_BLEND);
      if (cl_info) cout << "Sin Transparencia" << endl;
    }
    break;
  case 'g'://dispara proyectil
  case 'G':
    ang3=(TanqueAng+ArmaAng)*PI/180.0;
    proyectil.push_back( Bala( (TanqueX), (TanqueY), -30*sin(ang3), 30*cos(ang3)) );//la bala sale desde la base del arma
    break;     
  case 27:
    exit(EXIT_SUCCESS);
    break;
  }
}

// Special keys (non-ASCII)
// teclas de funcion, flechas, page up/dn, home/end, insert
void Special_cb(int key,int xm=0,int ym=0) {
  if (key==GLUT_KEY_F4 && glutGetModifiers()==GLUT_ACTIVE_ALT) // alt+f4 => exit
    exit(EXIT_SUCCESS);
}

//------------------------------------------------------------
void inicializa() {
  // GLUT
  glutInitDisplayMode(GLUT_RGBA|GLUT_DOUBLE|GLUT_DEPTH);// pide color RGB y double buffering
  glutInitWindowSize(w,h); glutInitWindowPosition(200,10);
  glutCreateWindow("Ejemplo Tanque"); // crea el main window

  // declara los callbacks, los que (aun) no se usan (aun) no se declaran
  glutDisplayFunc(Display_cb);
  glutReshapeFunc(Reshape_cb);
  glutKeyboardFunc(Keyboard_cb);
  glutSpecialFunc(Special_cb);
  glutIdleFunc(Idle_cb); // registra el callback

  // OpenGL
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  
  // Activamos el z buffer
  glEnable(GL_DEPTH_TEST);
  glDepthFunc( GL_LEQUAL );
  glDepthRange(0.0, 1.0);
  glClearDepth(1.0);
  
  // color de fondo
  glClearColor(fondo[0],fondo[1],fondo[2],fondo[3]);
  // teclas a utilizar
  cout << "Teclas a utilizar:" << endl;
  cout << "w: avanza" << endl;
  cout << "s: retrocede" << endl;
  cout << "d: gira en sentido horario" << endl;
  cout << "a: gira en sentido antihorario" << endl;
  cout << "p: gira arma en sentido horario" << endl;
  cout << "o: gira arma en sentido antihorario" << endl;
  cout << "l: estira arma" << endl;
  cout << "k: contrae arma" << endl;  
  // ========================  
  
  // las operaciones subsiguientes se aplican a la matriz de modelado GL_MODELVIEW
  glMatrixMode(GL_MODELVIEW); glLoadIdentity();
}

//------------------------------------------------------------
// main
int main(int argc,char** argv) {
  glutInit(&argc,argv); // inicializaci�n interna de GLUT
  inicializa(); // define el estado inicial de GLUT y OpenGL
  glutMainLoop(); // entra en loop de reconocimiento de eventos
  return 0; // nunca se llega ac�, es s�lo para evitar un warning
}
