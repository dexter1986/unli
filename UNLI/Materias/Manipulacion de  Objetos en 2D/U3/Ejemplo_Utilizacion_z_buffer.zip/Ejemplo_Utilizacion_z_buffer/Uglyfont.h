#pragma once

#ifndef UGLYFONT_IS_INCLUDED
#define UGLYFONT_IS_INCLUDED

void YsDrawUglyFont(const char str[],int centering,int useDisplayList=1);

#endif