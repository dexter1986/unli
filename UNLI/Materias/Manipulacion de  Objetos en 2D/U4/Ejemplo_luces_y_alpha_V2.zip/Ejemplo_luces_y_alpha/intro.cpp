// Ejemplo Tanque 
// 

#include <iostream> // cout
#include <cstdlib> // exit
#include <cmath> // fabs
#include <GL/glut.h>

using namespace std;

//------------------------------------------------------------
// variables globales
int
  w=800,h=600; // tamanio inicial de la ventana

double 
  TanqueX=400, 
  TanqueY=300, 
  TanqueAng=0, 
  ArmaAng=0,
  ArmaTamanio=0;

const double PI=4*atan(1.0);
bool cl_info=true; // informa por la linea de comandos


float opacidadLuz = 0.0f;
enum EstadoLuz{Prendida,Apagada};
EstadoLuz estadoLuzTanque = Apagada;

unsigned int lt=0;

//============================================================
// Dibuja el canion
void DibujarArma() {
  glColor3f(0.2f,0.45f,0.0f);
  
  glBegin(GL_QUADS);
  glVertex2d(-6.0,0.0);
  glVertex2d(6.0,0.0);
  glVertex2d(6.0,45.0);
  glVertex2d(-6.0,45.0);
  glEnd();
}

// Dibuja luces del tanque
void DibujarLuces() {
	// Dependiendo si se esta prendiendo o apagando la luz se calcula
	// la opacidad que tendra en este momento la luz
	if( estadoLuzTanque == Prendida )
	{
		opacidadLuz += 0.004f;
		if( opacidadLuz > 1.0f )
			opacidadLuz = 1.0f;
	}else
	{
		opacidadLuz -= 0.004f;
		if( opacidadLuz < 0.0f )
			opacidadLuz = 0.0f;
	}

	// la luz propiamente dicha
	glBegin(GL_QUADS);
		glColor4f(1.0f,1.0f,0.5f,opacidadLuz); // la parte cercana de la luz tiene transparencia
		glVertex2d(-2.0,0.0);				   // dependiendo del encendido y apagada de la luz
		glVertex2d(2.0,0.0);
		glColor4f(1.0f,1.0f,0.5f,0.0f);// la parte lejana de la luz es totalmente transparente
		glVertex2d(30.0,100.0);
		glVertex2d(-30.0,100.0);
	glEnd();
	
	// la optica de donde sale la luz
	glColor3f(0.3,0.3,0.3);
	glBegin(GL_QUADS);
		glVertex2d(-2.0,0.0);
		glVertex2d(2.0,0.0);
		glVertex2d(7.0,5.0);
		glVertex2d(-7.0,5.0);
	glEnd();
}

// La torre tiene diametro 40
void DibujarTorre() {
  glColor3f(0.2f,0.4f,0.0f);
  
  GLdouble baseRadius=40;
  int lod=30;
  GLint slices=lod, stacks=lod;  
  GLUquadricObj *q=gluNewQuadric();  
  // GLU_FILL, GLU_LINE, GLU_POINT or GLU_SILHOUETTE
  gluQuadricDrawStyle(q,GLU_FILL);
  gluDisk(q,0,baseRadius,slices,stacks);  
  gluDeleteQuadric(q);
  
  glColor3f(0.0f,0.1f,0.0f); 
  glPointSize(2);
  glBegin(GL_POINTS);
  for(double x=0; x<2*PI; x+=0.4) 
  {
	  // Dibujado de los puntos rojos titilantes sobre la torre del tanque
	  float _x = (glutGet(GLUT_ELAPSED_TIME)%3000)/2999.0f;
	  float opacidadLucesitas = 315/(64*3.1415*pow(0.5,9))*pow((pow(0.5,2)-pow(_x-0.5,2)),3) /12.5335 + 0.1f; 
	  if( opacidadLucesitas > 1.0f )
		  opacidadLucesitas = 1.0f;
	  std::cout<<opacidadLucesitas<<std::endl;
	  glColor4f(1.0f,0.0f,0.0f,opacidadLucesitas);//Establecemos el color y especialmente el alpha de los puntos
	  glVertex2d(40.0*0.8*cos(x),40.0*0.8*sin(x));
  }
  glEnd();
  
  glPushMatrix();
  glScaled(1.0,2.0+(ArmaTamanio*0.1),1.0);//glScaled(1.0,2.0,1.0);
  DibujarArma();
  glPopMatrix();
}

// La ogura del tanque mide 10 x 150
void DibujarOruga() {
  glColor3f(0.4f,0.4f,0.4f);
  glBegin(GL_QUADS);
  glVertex2d(5,75);
  glVertex2d(-5,75);
  glVertex2d(-5,-75);
  glVertex2d(5,-75);
  glEnd();
}

// El cuerpo del tanque mide 80 x 140
void DibujarCuerpo() {
  glColor3f(0.002f,0.29f,0.001f);
  glBegin(GL_QUADS);
  glVertex2d(40,70);
  glVertex2d(-40,70);
  glVertex2d(-40,-70);
  glVertex2d(40,-70);
  glEnd();
  
  glColor3f(0.001f,0.1f,0.001f);
  glLineWidth(3.0);
  glBegin(GL_LINES);
  glVertex2i(30,-55); glVertex2i(15,-55);
  glVertex2i(30,-60); glVertex2i(15,-60);
  glVertex2i(-15,-55); glVertex2i(-30,-55);
  glVertex2i(-15,-60); glVertex2i(-30,-60);
  glVertex2i(40,70); glVertex2i(-40,70);
  glEnd();  
  glLineWidth(1.0);  
}

void DibujarTanque() {
  glPushMatrix();// inicio push1

  // Posiciona y rota el tanque en el modelo
  glTranslated(TanqueX,TanqueY,0);
  glRotated(TanqueAng,0,0,1);  

  DibujarCuerpo();

  //dibujo la luces
  glPushMatrix();
	glTranslatef(-30.0f,70.0f, 0.0f);
    DibujarLuces();
  glPopMatrix();
  glPushMatrix();
    glTranslatef(30.0f,70.0f, 0.0f);
    DibujarLuces();
  glPopMatrix();
  //fin dibujo luces

  glPushMatrix();
  // Posiciona la oruga derecha
  glTranslatef(45.0f,0.0f, 0.0f);
  DibujarOruga();
  glPopMatrix();
  
  glPushMatrix();
  // Posiciona la oruga izquierda
  glTranslatef(-45.0f,0.0f, 0.0f);
  DibujarOruga();
  glPopMatrix();

  glPushMatrix();
  // Posiciona y rota la torre 
  //glTranslated(0,-20,0);//Probar de descomentar esta linea para desplazar torre
  glRotated(ArmaAng,0,0,1);
  DibujarTorre();
  glPopMatrix();
  
  glPopMatrix();// fin push1
}

void DibujarPared() {
  glColor3f(0.01f,0.01f,0.01f);
  glLineWidth(5.0);
  glBegin(GL_LINES);
  glVertex2i(300,400); glVertex2i(300,200);
  glVertex2i(300,200); glVertex2i(500,200);
  glVertex2i(500,200); glVertex2i(500,400);
  glEnd();
}

//============================================================
// callbacks

//------------------------------------------------------------

// arma un un nuevo buffer (back) y reemplaza el framebuffer
void Display_cb() {
  // arma el back-buffer
  glClear(GL_COLOR_BUFFER_BIT);// rellena con color de fondo
 
  
  DibujarPared();

  DibujarTanque();
  
  glutSwapBuffers(); // lo manda al monitor
  
  // chequea errores
  int errornum=glGetError();
  while(errornum!=GL_NO_ERROR){
    if (cl_info){
      if(errornum==GL_INVALID_ENUM)
        cout << "GL_INVALID_ENUM" << endl;
      else if(errornum==GL_INVALID_VALUE)
        cout << "GL_INVALID_VALUE" << endl;
      else if (errornum==GL_INVALID_OPERATION)
        cout << "GL_INVALID_OPERATION" << endl;
      else if (errornum==GL_STACK_OVERFLOW)
        cout << "GL_STACK_OVERFLOW" << endl;
      else if (errornum==GL_STACK_UNDERFLOW)
        cout << "GL_STACK_UNDERFLOW" << endl;
      else if (errornum==GL_OUT_OF_MEMORY)
        cout << "GL_OUT_OF_MEMORY" << endl;
    }
    errornum=glGetError();
  }
}

//------------------------------------------------------------
// Maneja cambios de ancho y alto de la ventana
void Reshape_cb(int width, int height){
  // cout << "reshape " << width << "x" << height << endl;
  if (!width||!height) return; // minimizado ==> nada
  w=width; h=height;
  glViewport(0,0,w,h); // regi�n donde se dibuja (toda la ventana)
  // rehace la matriz de proyecci�n (la porcion de espacio visible)
  glMatrixMode(GL_PROJECTION);  glLoadIdentity();
  glOrtho(0,w,0,h,-1,1); // unidades = pixeles
  // las operaciones subsiguientes se aplican a la matriz de modelado GL_MODELVIEW
  glMatrixMode(GL_MODELVIEW);
  glutPostRedisplay(); // avisa que se debe redibujar
}

//------------------------------------------------------------
// Teclado

// Maneja pulsaciones del teclado (ASCII keys)
// x,y posicion del mouse cuando se teclea (aqui no importan)
void Keyboard_cb(unsigned char key,int x,int y) {
  // Convierte TanqueAng de grados a radianes
  double ang=TanqueAng*PI/180.0;
  switch(key){
  case 'w':
  case 'W':
    // double sin(double ang); // Calcula el seno de ang medido en radianes
    TanqueX-=5*sin(ang);
    TanqueY+=5*cos(ang);
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 's':
  case 'S':
    TanqueX+=5*sin(ang);
    TanqueY-=5*cos(ang);
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 'a':
  case 'A':
    TanqueAng+=2;
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 'd':
  case 'D':
    TanqueAng-=2;
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 'o':
  case 'O':
    ArmaAng+=2;
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 'p':
  case 'P':
    ArmaAng-=2;
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 'k':
  case 'K':
    if(ArmaTamanio>-3) ArmaTamanio-=1;
    //glutPostRedisplay(); ahora se actualiza contantemente
    break;
  case 'l':
  case 'L':
    if(ArmaTamanio<5) ArmaTamanio+=1;
    //glutPostRedisplay();
    break;
  case 'e':
  case 'E':
	if( estadoLuzTanque == Prendida )
		estadoLuzTanque = Apagada;
	else
		estadoLuzTanque = Prendida;
	break;
  case 27:
    exit(EXIT_SUCCESS);
    break;
  }
}

// Special keys (non-ASCII)
// teclas de funcion, flechas, page up/dn, home/end, insert
void Special_cb(int key,int xm=0,int ym=0) {
  if (key==GLUT_KEY_F4 && glutGetModifiers()==GLUT_ACTIVE_ALT) // alt+f4 => exit
    exit(EXIT_SUCCESS);
}

void Idle_cb()
{
	int dt = glutGet(GLUT_ELAPSED_TIME) - lt;

	if( dt > (1000/60.0f) )
	{
		lt = glutGet(GLUT_ELAPSED_TIME);

		glutPostRedisplay();
	}
}

//------------------------------------------------------------
void inicializa() {
  // GLUT
  glutInitDisplayMode(GLUT_RGB|GLUT_DOUBLE);// pide color RGB y double buffering
  glutInitWindowSize(w,h); glutInitWindowPosition(10,10);
  glutCreateWindow("Ejemplo canal alpha"); // crea el main window

  // declara los callbacks, los que (aun) no se usan (aun) no se declaran
  glutDisplayFunc(Display_cb);
  glutReshapeFunc(Reshape_cb);
  glutKeyboardFunc(Keyboard_cb);
  glutSpecialFunc(Special_cb);
  glutIdleFunc(Idle_cb);

  // Configuracion del alpha y su funcion de mezclado (blending)
  glEnable(GL_BLEND);
  glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  // OpenGL
  glClearColor(0.23f,0.20f,0.01f,1.f); // color de fondo
  // las operaciones subsiguientes se aplican a la matriz de modelado GL_MODELVIEW
  glMatrixMode(GL_MODELVIEW); glLoadIdentity();
}

//------------------------------------------------------------
// main
int main(int argc,char** argv) {
  // teclas a utilizar
  cout << "Teclas a utilizar:" << endl;
  cout << "w: avanza" << endl;
  cout << "s: retrocede" << endl;
  cout << "d: gira en sentido horario" << endl;
  cout << "a: gira en sentido antihorario" << endl;
  cout << "p: gira arma en sentido horario" << endl;
  cout << "o: gira arma en sentido antihorario" << endl;
  cout << "l: estira arma" << endl;
  cout << "k: contrae arma" << endl;
  cout << "e: prende/apaga la luz del tanque" << endl;
  
  glutInit(&argc,argv); // inicializaci�n interna de GLUT
  inicializa(); // define el estado inicial de GLUT y OpenGL
  glutMainLoop(); // entra en loop de reconocimiento de eventos
  return 0; // nunca se llega ac�, es s�lo para evitar un warning
}
