// Ejemplo teclas simultaneas
// 

#include <iostream> // cout
#include <list> 
#include <cstdlib> // exit
#include <cmath> // fabs
#include <fstream> // file io
#include <GL/glut.h>

#include <cmath>
#include "Teclado.h"
using namespace std;

//------------------------------------------------------------
// variables globalesint
int w=800,h=600; // tamanio inicial de la ventana

double vel=0, px=w/2, py=h/2, ang=0; //velocidad, posicion y direccion del "personaje"

Teclado teclado(' ', 'w', 's', 'a', 'd', 'o', 'p'); // para manejar la entrada por teclado


//============================================================
// callbacks

//------------------------------------------------------------

// arma un un nuevo buffer (back) y reemplaza el framebuffer
void Display_cb() {
	glClear(GL_COLOR_BUFFER_BIT);
	
	glColor3f(1.0f,1.0f,1.0f);
	glPointSize(5);
	
	glBegin(GL_LINES);
	glVertex2d( px, py );
	glVertex2d( px + 25 * cos(ang), py + 25 * sin(ang) );
	glEnd();
	
	glBegin(GL_POINTS);
	glVertex2d( px, py );
	glEnd();
	
	glutSwapBuffers(); 
	
	// chequea errores
	int errornum=glGetError();
	while(errornum!=GL_NO_ERROR){
		if(errornum==GL_INVALID_ENUM)
			cout << "GL_INVALID_ENUM" << endl;
		else if(errornum==GL_INVALID_VALUE)
			cout << "GL_INVALID_VALUE" << endl;
		else if (errornum==GL_INVALID_OPERATION)
			cout << "GL_INVALID_OPERATION" << endl;
		else if (errornum==GL_STACK_OVERFLOW)
			cout << "GL_STACK_OVERFLOW" << endl;
		else if (errornum==GL_STACK_UNDERFLOW)
			cout << "GL_STACK_UNDERFLOW" << endl;
		else if (errornum==GL_OUT_OF_MEMORY)
			cout << "GL_OUT_OF_MEMORY" << endl;
		errornum=glGetError();
	}
}

void idle_cb() {
	static unsigned int lt=0;
	if( glutGet(GLUT_ELAPSED_TIME) - lt > 60 ) {
		// Primero miramos el estado del teclado y realizamos los cambios en la direccion y la velocidad del 'personaje'
		if( teclado.Salir() )
			exit( EXIT_SUCCESS );
		if( teclado.Adelante() )
			vel += 2;
		if( teclado.Atras() )
			vel -= 2;
		if( teclado.Izquierda() )
			ang += 0.2;
		if( teclado.Derecha() )
			ang -= 0.2;
		
		// Actualizamos la posicion del 'personaje'
		px += vel*cos(ang);
		py += vel*sin(ang);
		// Disminuimos la velocidad 
		vel *= 0.9;
		
		// controlamos que no salga de la pantalla
		if( px < 0) px = 0;
		if( px > w) px = w;
		if( py < 0) py = 0;
		if( py > h) py = h;
		
		lt = glutGet(GLUT_ELAPSED_TIME);
		// Mandamos a dibujar
		glutPostRedisplay();
	}
}

//------------------------------------------------------------
// Maneja cambios de ancho y alto de la ventana
void reshape_cb (int W, int H) {
	w=W; h=H;
	if (w==0||h==0) return;
	glViewport(0,0,w,h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluOrtho2D(0,w,0,h);
	glMatrixMode (GL_MODELVIEW);
  glutPostRedisplay(); // avisa que se debe redibujar
}

//------------------------------------------------------------
// pregunta a OpenGL por el valor de una variable de estado
int integerv(GLenum pname){
	int value;
	glGetIntegerv(pname,&value);
	return value;
}
#define _PRINT_INT_VALUE(pname) #pname << ": " << integerv(pname) <<endl

//------------------------------------------------------------
void inicializa() {
	// GLUT
	// pide color RGB, double buffering y buffer de acumulacion
	glutInitDisplayMode(GLUT_RGB|GLUT_DOUBLE);
	
	glutInitWindowSize(w,h); glutInitWindowPosition(10,10);
	glutCreateWindow("Ejemplo teclas simultaneas");
	
	//permite eliminar el cursor
	//glutSetCursor(GLUT_CURSOR_NONE);
	
	//Pantalla completa
	//glutFullScreen(); 
	
	// declara los callbacks, los que (aun) no se usan (aun) no se declaran
	glutDisplayFunc(Display_cb);
	glutReshapeFunc(reshape_cb);
	glutIdleFunc(idle_cb);
	// declaramos los callbacks de teclado
	teclado.Iniciar();
	
	// OpenGL
	// color de fondo
  glClearColor(0.23f,0.20f,0.01f,1.f);

	// teclas a utilizar
	cout << "Teclas a utilizar:" << endl;
	cout << "w: avanza" << endl;
	cout << "s: retrocede" << endl;
	cout << "d: gira en sentido horario" << endl;
	cout << "a: gira en sentido antihorario" << endl;
	// ========================
}

//------------------------------------------------------------
// main
int main(int argc,char** argv) {
	glutInit(&argc,argv); // inicializaci�n interna de GLUT
	inicializa(); // define el estado inicial de GLUT y OpenGL
	glutMainLoop(); // entra en loop de reconocimiento de eventos
	return 0; // nunca se llega ac�, es s�lo para evitar un warning
}
